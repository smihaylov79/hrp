-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: hrp
-- ------------------------------------------------------
-- Server version	8.0.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add user',6,'add_customuser'),(22,'Can change user',6,'change_customuser'),(23,'Can delete user',6,'delete_customuser'),(24,'Can view user',6,'view_customuser'),(25,'Can add recipe category',7,'add_recipecategory'),(26,'Can change recipe category',7,'change_recipecategory'),(27,'Can delete recipe category',7,'delete_recipecategory'),(28,'Can view recipe category',7,'view_recipecategory'),(29,'Can add recipe',8,'add_recipe'),(30,'Can change recipe',8,'change_recipe'),(31,'Can delete recipe',8,'delete_recipe'),(32,'Can view recipe',8,'view_recipe'),(33,'Can add recipe ingredient',9,'add_recipeingredient'),(34,'Can change recipe ingredient',9,'change_recipeingredient'),(35,'Can delete recipe ingredient',9,'delete_recipeingredient'),(36,'Can view recipe ingredient',9,'view_recipeingredient'),(37,'Can add inventory product',10,'add_inventoryproduct'),(38,'Can change inventory product',10,'change_inventoryproduct'),(39,'Can delete inventory product',10,'delete_inventoryproduct'),(40,'Can view inventory product',10,'view_inventoryproduct'),(41,'Can add user product category',11,'add_userproductcategory'),(42,'Can change user product category',11,'change_userproductcategory'),(43,'Can delete user product category',11,'delete_userproductcategory'),(44,'Can view user product category',11,'view_userproductcategory'),(45,'Can add main category',12,'add_maincategory'),(46,'Can change main category',12,'change_maincategory'),(47,'Can delete main category',12,'delete_maincategory'),(48,'Can view main category',12,'view_maincategory'),(49,'Can add product category',13,'add_productcategory'),(50,'Can change product category',13,'change_productcategory'),(51,'Can delete product category',13,'delete_productcategory'),(52,'Can view product category',13,'view_productcategory'),(53,'Can add product',14,'add_product'),(54,'Can change product',14,'change_product'),(55,'Can delete product',14,'delete_product'),(56,'Can view product',14,'view_product'),(57,'Can add basket',15,'add_basket'),(58,'Can change basket',15,'change_basket'),(59,'Can delete basket',15,'delete_basket'),(60,'Can view basket',15,'view_basket'),(61,'Can add basket item',16,'add_basketitem'),(62,'Can change basket item',16,'change_basketitem'),(63,'Can delete basket item',16,'delete_basketitem'),(64,'Can view basket item',16,'view_basketitem'),(65,'Can add shop',17,'add_shop'),(66,'Can change shop',17,'change_shop'),(67,'Can delete shop',17,'delete_shop'),(68,'Can view shop',17,'view_shop'),(69,'Can add shopping',18,'add_shopping'),(70,'Can change shopping',18,'change_shopping'),(71,'Can delete shopping',18,'delete_shopping'),(72,'Can view shopping',18,'view_shopping'),(73,'Can add shopping product',19,'add_shoppingproduct'),(74,'Can change shopping product',19,'change_shoppingproduct'),(75,'Can delete shopping product',19,'delete_shoppingproduct'),(76,'Can view shopping product',19,'view_shoppingproduct'),(77,'Can add shopping list',20,'add_shoppinglist'),(78,'Can change shopping list',20,'change_shoppinglist'),(79,'Can delete shopping list',20,'delete_shoppinglist'),(80,'Can view shopping list',20,'view_shoppinglist'),(81,'Can add recipe shopping list',21,'add_recipeshoppinglist'),(82,'Can change recipe shopping list',21,'change_recipeshoppinglist'),(83,'Can delete recipe shopping list',21,'delete_recipeshoppinglist'),(84,'Can view recipe shopping list',21,'view_recipeshoppinglist'),(85,'Can add category',22,'add_category'),(86,'Can change category',22,'change_category'),(87,'Can delete category',22,'delete_category'),(88,'Can view category',22,'view_category'),(89,'Can add thread',23,'add_thread'),(90,'Can change thread',23,'change_thread'),(91,'Can delete thread',23,'delete_thread'),(92,'Can view thread',23,'view_thread'),(93,'Can add post',24,'add_post'),(94,'Can change post',24,'change_post'),(95,'Can delete post',24,'delete_post'),(96,'Can view post',24,'view_post'),(97,'Can add recipe times cooked',25,'add_recipetimescooked'),(98,'Can change recipe times cooked',25,'change_recipetimescooked'),(99,'Can delete recipe times cooked',25,'delete_recipetimescooked'),(100,'Can view recipe times cooked',25,'view_recipetimescooked'),(101,'Can add event',26,'add_event'),(102,'Can change event',26,'change_event'),(103,'Can delete event',26,'delete_event'),(104,'Can view event',26,'view_event'),(105,'Can add task',27,'add_task'),(106,'Can change task',27,'change_task'),(107,'Can delete task',27,'delete_task'),(108,'Can view task',27,'view_task'),(109,'Can add house hold',28,'add_household'),(110,'Can change house hold',28,'change_household'),(111,'Can delete house hold',28,'delete_household'),(112,'Can view house hold',28,'view_household'),(113,'Can add household membership',29,'add_householdmembership'),(114,'Can change household membership',29,'change_householdmembership'),(115,'Can delete household membership',29,'delete_householdmembership'),(116,'Can view household membership',29,'view_householdmembership'),(117,'Can add household inventory product',30,'add_householdinventoryproduct'),(118,'Can change household inventory product',30,'change_householdinventoryproduct'),(119,'Can delete household inventory product',30,'delete_householdinventoryproduct'),(120,'Can view household inventory product',30,'view_householdinventoryproduct'),(121,'Can add household product category',31,'add_householdproductcategory'),(122,'Can change household product category',31,'change_householdproductcategory'),(123,'Can delete household product category',31,'delete_householdproductcategory'),(124,'Can view household product category',31,'view_householdproductcategory'),(125,'Can add household recipe shopping list',32,'add_householdrecipeshoppinglist'),(126,'Can change household recipe shopping list',32,'change_householdrecipeshoppinglist'),(127,'Can delete household recipe shopping list',32,'delete_householdrecipeshoppinglist'),(128,'Can view household recipe shopping list',32,'view_householdrecipeshoppinglist'),(129,'Can add household shopping list',33,'add_householdshoppinglist'),(130,'Can change household shopping list',33,'change_householdshoppinglist'),(131,'Can delete household shopping list',33,'delete_householdshoppinglist'),(132,'Can view household shopping list',33,'view_householdshoppinglist'),(133,'Can add household recipe times cooked',34,'add_householdrecipetimescooked'),(134,'Can change household recipe times cooked',34,'change_householdrecipetimescooked'),(135,'Can delete household recipe times cooked',34,'delete_householdrecipetimescooked'),(136,'Can view household recipe times cooked',34,'view_householdrecipetimescooked'),(137,'Can add exchange rate',35,'add_exchangerate'),(138,'Can change exchange rate',35,'change_exchangerate'),(139,'Can delete exchange rate',35,'delete_exchangerate'),(140,'Can view exchange rate',35,'view_exchangerate'),(141,'Can add user inflation basket item',36,'add_userinflationbasketitem'),(142,'Can change user inflation basket item',36,'change_userinflationbasketitem'),(143,'Can delete user inflation basket item',36,'delete_userinflationbasketitem'),(144,'Can view user inflation basket item',36,'view_userinflationbasketitem'),(145,'Can add household inflation basket item',37,'add_householdinflationbasketitem'),(146,'Can change household inflation basket item',37,'change_householdinflationbasketitem'),(147,'Can delete household inflation basket item',37,'delete_householdinflationbasketitem'),(148,'Can view household inflation basket item',37,'view_householdinflationbasketitem'),(149,'Can add user inflation basket',38,'add_userinflationbasket'),(150,'Can change user inflation basket',38,'change_userinflationbasket'),(151,'Can delete user inflation basket',38,'delete_userinflationbasket'),(152,'Can view user inflation basket',38,'view_userinflationbasket'),(153,'Can add household inflation basket',39,'add_householdinflationbasket'),(154,'Can change household inflation basket',39,'change_householdinflationbasket'),(155,'Can delete household inflation basket',39,'delete_householdinflationbasket'),(156,'Can view household inflation basket',39,'view_householdinflationbasket'),(157,'Can add thread request',40,'add_threadrequest'),(158,'Can change thread request',40,'change_threadrequest'),(159,'Can delete thread request',40,'delete_threadrequest'),(160,'Can view thread request',40,'view_threadrequest');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cooking_householdrecipetimescooked`
--

DROP TABLE IF EXISTS `cooking_householdrecipetimescooked`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cooking_householdrecipetimescooked` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` datetime(6) NOT NULL,
  `household_id` bigint NOT NULL,
  `recipe_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cooking_householdrec_household_id_119efde6_fk_users_hou` (`household_id`),
  KEY `cooking_householdrec_recipe_id_d66218eb_fk_cooking_r` (`recipe_id`),
  CONSTRAINT `cooking_householdrec_household_id_119efde6_fk_users_hou` FOREIGN KEY (`household_id`) REFERENCES `users_household` (`id`),
  CONSTRAINT `cooking_householdrec_recipe_id_d66218eb_fk_cooking_r` FOREIGN KEY (`recipe_id`) REFERENCES `cooking_recipe` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cooking_householdrecipetimescooked`
--

LOCK TABLES `cooking_householdrecipetimescooked` WRITE;
/*!40000 ALTER TABLE `cooking_householdrecipetimescooked` DISABLE KEYS */;
INSERT INTO `cooking_householdrecipetimescooked` VALUES (1,'2025-07-22 21:22:35.814922',1,27),(2,'2025-07-25 14:31:15.441716',1,19),(3,'2025-07-25 14:32:53.648888',1,24),(4,'2025-07-26 06:55:44.051576',1,30);
/*!40000 ALTER TABLE `cooking_householdrecipetimescooked` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cooking_recipe`
--

DROP TABLE IF EXISTS `cooking_recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cooking_recipe` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `time_to_prepare` int DEFAULT NULL,
  `instructions` longtext,
  `url_link` varchar(200) DEFAULT NULL,
  `category_id` bigint NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cooking_recipe_category_id_3ab4357c_fk_cooking_recipecategory_id` (`category_id`),
  CONSTRAINT `cooking_recipe_category_id_3ab4357c_fk_cooking_recipecategory_id` FOREIGN KEY (`category_id`) REFERENCES `cooking_recipecategory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cooking_recipe`
--

LOCK TABLES `cooking_recipe` WRITE;
/*!40000 ALTER TABLE `cooking_recipe` DISABLE KEYS */;
INSERT INTO `cooking_recipe` VALUES (1,'Салата със спанак и синьо сирене',15,'Балсамовият оцет, зехтинът и медът се смесват до хомогенност и с тази смес се заливат спанакът и микса от салатите, нарязани на дребно.\r\nСиньото сирене се натрошава и се добавя към салатата със спанак.\r\nОставя се салата със спанак и синьо сирене в хладилник за 1 час и преди сервиране се слагат слънчогледови семки.\r\n0,03 мл = 1 с.л.','',1,''),(2,'Попска яхния',15,'Месото се запържва с лук и няколко скилидки чесън. Като се запържи се добавят червения пипер и брашното, разбърква се и се сипва доматеното пюре, дафиновия лист и черен пипер.\r\nГотви се на слаб, умерен огън като и се долива топла вода. След като поври малко се слагат и главите лук 5-7.',NULL,2,''),(3,'Месо с готов къри сос',15,'Запържва се  месото с лук и моркови. Може да се добавят и малко други зеленцчуци.\r\nКато е почти готово се добавя сос и къкри 10-ина минути на слаб котлон.\r\nСервира се със сварен ориз.','',2,''),(4,'Ориз гарнитура',15,'Запържва се лука нарязан на лунички, след това се добавя оризаз .\r\nДобавя се сол, къри и куркума и гореща вода. 3 към 1.\r\nПолзва се за добавка към винен кебап, сосове.','',3,''),(5,'Салата с киноа и грозде',15,'Изплакнете добре киноата с вода. Така ще се премахне естественият й външен слой - сапонин, който има горчив и леко сапунен вкус. Сложете я в тенджерка с 1 ч.ч. вода и оставете да заври. Щом заври, изключете котлона и оставете да се свари сама в горещата вода за 10 минути. Oставете я да изстине.\r\nВ чиния или купа смесете изстиналата киноа с останалите съставки - грозде, червен лук, авокадо и манголд (снак или салата). Отгоре поръсете с кашу и пресен босилек.\r\nВ малко бурканче смесете съставките за дресинга и разклатете добре. Залейте салатата с дресинга преди сервиране.','https://www.kulinarenblog.bg/%D1%81%D0%B0%D0%BB%D0%B0%D1%82%D0%B8/%D1%81%D0%B0%D0%BB%D0%B0%D1%82%D0%B0-%D1%81-%D0%BA%D0%B8%D0%BD%D0%BE%D0%B0-%D0%B8-%D0%B3%D1%80%D0%BE%D0%B7%D0%B4%D0%B5/',1,'recipe_images/salata-s-kinoa-i-grozde.jpg'),(6,'Пържоли на фурна',15,'Пържолите се овкусяват с подправки по вкус.\r\nПекат се в затоплена фурна, като им се добавя малко вино или бира.','',2,''),(7,'Ливанска салата',15,'3 ч.ч. микс от зеленолистни по-твърди зеленчуци, като айсберг, романа, радичио, накъсани на парчета\r\n3 ч.ч. маруля, накъсана на парчета\r\n1 червена и 1 жълта чушка\r\n12 чери домата, разполовени на две.\r\nВ купа за сервиране смесете накъсаните салати, двата вида чушки, краставица и домати. Поръсете щедро със семена от нар. За дресинга разбъркайте лимоновия сок с малко сол, сумак и пресована скилидка чесън. Залейте салатата и объркайте внимателно.','https://www.kulinarenblog.bg/%D1%81%D0%B0%D0%BB%D0%B0%D1%82%D0%B8/%D0%BB%D0%B8%D0%B2%D0%B0%D0%BD%D1%81%D0%BA%D0%B0-%D1%81%D0%B0%D0%BB%D0%B0%D1%82%D0%B0/',1,'recipe_images/livanska-salata.jpg'),(8,'Ориз с праз и маслини',15,'Необходими продукти за 4 порции:\r\n3 стръка праз\r\n1 к. ч. олио\r\n1 стрък целина\r\n200 г ориз\r\n1 кубче зеленчуков бульон\r\n3 ч. л. доматено пюре\r\n100 г черни маслини\r\nНачин на приготвяне:\r\n1. Празът се нарязва на колелца и се запържва в сгорещеното олио. Прибавя се ситно нарязаната целина и се наливат 4–5 с. л. топла вода. Зеленчуците се задушават 5–6 минути на слаб огън под капак.\r\n2. Прибавя се оризът, сипва се разтвореният в 700 мл вода бульон и се добавя доматеното пюре.\r\n3. Щом сместа кипне, се прехвърля в тава, прибавят се почистените от костилките маслини и се разбърква. Пече се в умерено загрята фурна на 160–170 градуса, докато оризът стане готов.','https://www.edna.bg/vkusno/vegetarianstvo/posten-oriz-s-praz-i-maslini-4636355',2,'recipe_images/oriz-s-praz-i-maslini.jpg'),(9,'Панирана гъба кладница',15,'гъби кладница / една тарелка или колкото имате /\r\nедна чаена чаша брашно\r\n250 милилитра газирана вода – задължително студена – от хладилник - бира\r\nедно яйце – студено – от хладилник\r\nполовин чаена лъжичка сол\r\nолио за пържене\r\nНачин на приготвяне на вкусната, панирана гъба:\r\nИзчистете гъбите. Накъсайте ги  на парченца. Не ги режете с нож. Тези гъби са много крехки.\r\nНаправете панировка, като разбиете яйцето и към него прибавите газираната вода, брашното и солта. Разбъркайте до еднородна смес. Дори и да остане някое топченце брашно, не е фатално.\r\nЗагрейте олиото. Потапяйте гъбите в панировката и изпържете. Задължително ги изваждайте върху салфетка, за да се попие излишната мазнина. Това е всичко.\r\nhttps://cookathouse.com/panirana-gaba-kladnitza/','https://cookathouse.com/panirana-gaba-kladnitza/',3,'recipe_images/panirani-gabi-kladnica.jpg'),(10,'Сандвичи с авокадо',15,'Филийките се намазват с нещо за мазане.\r\nАвокадото се обелва, намачква с вилица. добавя му се сол, черен пипер и зехтин. после се намазва върху филийките\r\nБекона се запържва до златисто.\r\nЯйцата се пошират, но в краен случай може и да са пържени, като жълтъка задължително трябва да е рохък.','https://www.marica.bg/gurme/neustoima-zakuska-sandvich-s-avokado-i-qyce-recepta',4,'recipe_images/sandvich-s-avokado.webp'),(11,'Киноа с пъстри зеленчуци',15,'1. Киноата се измива и сварява, след това се отцежда. Лукът, морковът, чушките и тиквичката се почистват и режат на ивички, чесънът и джинджифилът се наситняват.\r\n2. В уок се загрява олиото и в него се запържват чесънът и джинджифилът, малко след тях се слагат лукът, морковът, двата вида чушки и тиквичките. Готвят се за кратко на висока температура, трябва да останат хрупкави.\r\n3. Към зеленчуците се прибавя и грахът, сипва се сварената киноа, подправя се със соев сос. По желание може да се гарнира с пресен кориандър, запечен сусам и лют сос.','https://www.billa.bg/recepti/kinoa-s-p-stri-zelenchutsi',3,'recipe_images/kinoa-s-pustri-zelenchuci.webp'),(12,'Друсан кебап',15,'1. Месото се нарязва на дребни парчета. Слага се в голям съд със сгорещеното олио и се оставя да се пържи, като се разбърква от време на време. Вместо в олио можете да изпържите месото в същото количество мас.\r\n2. Лукът се почиства и се нарязва на дебели полумесеци. Слага се, щом се карамелизира месото, и се подправя със сол и черен пипер.\r\n3. Покрива се с капак. Оставя се на огъня, като съдът се подрусва от време на време, без да се отваря.\r\n4. Щом лукът се карамелизира леко, се поръсва с лют пипер на люспи, разбърква се и се поднася.','https://www.billa.bg/recepti/drusan-kebap',2,'recipe_images/drusan-kebap.webp'),(13,'Супа зеленчуци',15,'','',5,''),(14,'Каша с коприва',15,'Копривата накиснах за 15-ина минути, след което я измих и отцедих. В тенджера загрях 1 литър вода с 1 ч.л. сол. Във врящата вода добавих копривата и я варих около 8 минути или докато омекна. След това я отцедих и запазих отварата й. Копривата накълцах на дребно.\r\nВ тенджера загрях маслото и няколко капки олио и сложих брашното, като леко посолих. Разбърквах с кухненска бъркалка и когато доби златист цвят, прибавих червения пипер, разбърках и веднага отстраних съда от котлона. Налях 350 мл. от отварата и не спирах да разбърквам до получаване на гладка каша. Наложи се добавя още 50 мл. от течността и така цялото нужно количество бе 400 мл. Прибавих копривата, разбърках и върнах на котлона да поври 1-2 минути на ниска степен( 3 от 6 на моята печка). Кашата бълбука и пръска и затова степента на котлона трябва да бъде ниска. В купичка смесих натрошеното на дребно сирене и яйцата и ги добавих в кашата. Разбърках и готвих още 2-3 минути или докато яйцата се сготвиха. След това окончателно отстраних кашата от котлона.\r\nВ метално канче загрях маслото, джоджена и червения пипер и с тях полях кашата, след което разбърках. Сервирах я топла, поръсена с леко запечени в сух тиган и накълцани орехови ядки.','https://www.supichka.com/%D1%80%D0%B5%D1%86%D0%B5%D0%BF%D1%82%D0%B0/450/%D0%BA%D0%B0%D1%88%D0%B0-%D0%BE%D1%82-%D0%BA%D0%BE%D0%BF%D1%80%D0%B8%D0%B2%D0%B0',3,'recipe_images/kasha-ot-kopriva.jpg'),(15,'Мусака с тиквички и патладжан',15,'','',2,''),(16,'Бъркана баница с тиквички на тиган',50,'1 средно голяма тиквичка (380 г)\r\n?2 яйца (М размер)\r\n?1 с.л. кисело мляко (35 г)\r\n?60 грама сирене\r\n?90 грама брашно (¾ ч.ч.) (1 ч.ч. = 250 мл.) любимото ми от българска пшеница смляна на каменна мелница https://shop.znt.bg/bg-product-details-190.html?utm_source=menub&utm_medium=1&utm_campaign=190\r\n?2 ч.л. бакпулвер (8 г)\r\n?1 голяма скилидка чесън (пресована)\r\n?Сол (фино смляна морска)\r\n?Млян пипер меланж\r\n?Масло','https://inthebeniskitchen.com/2025/05/30',4,'recipe_images/barkana-banica-s-tikvichki.webp'),(18,'Хумус',40,'100 г суров белен нахут (показвам го в края на рецептата)\r\n?1/4 ч.л. сода за хляб\r\n?50 мл. прясно изцеден лимонов сок (3 с.л.)\r\n?50 мл. сусамов тахан (1 и ½ с.л.) (използвах пълнозърнест)\r\n?1 малка скилидка чесън\r\n?30 мл. зехтин (2 с.л. и още за сервиране)\r\n?1/2 ч.л. млян кимион\r\n?1/2 ч.л сол или вкус (фино смляна морска)\r\n?2 -3 с.л. ледено студена вода (30 -40 мл.)\r\n?Щипка червен пипер за сервиране','https://inthebeniskitchen.com/2025/02/25/%d0%bd%d0%b0%d0%b9-%d0%b2%d0%ba%d1%83%d1%81%d0%bd%d0%b8%d1%8f%d1%82-%d1%85%d1%83%d0%bc%d1%83%d1%81/',1,'recipe_images/humus.webp'),(19,'Миш маш',25,'Първата стъпка от рецептата за миш-маш е подготовката на зеленчуците. Измивате чушките, почиствате ги от семките и ги нарязвате на едри парчета. Обелвате доматите и ги настъргвате на едро ренде.\r\nВ тенджера, или в дълбок тиган сгорещявате олиото и добавяте нарязаните чушки. Запържвате ги при непрекъснато бъркане докато омекнат. След като чушките омекнат добавяте и настърганите домати, оставяте сместа да ври на слаб огън, докато водата на доматите изври.\r\nСлед това добавете разбитите яйца и натрошеното сирене, а в случай, че сиренето не е достатъчно солено може да добавите и сол. Миш-машът трябва да поври още няколко минути, като го разбърквате от време на време.\r\nПреди сервиране може да поръсите миш-маша със ситно нарязан магданоз.','https://www.supichka.com/%D1%80%D0%B5%D1%86%D0%B5%D0%BF%D1%82%D0%B0/188/%D0%BC%D0%B8%D1%88-%D0%BC%D0%B0%D1%88',2,'recipe_images/mish-mash.jpg'),(20,'Таратор',10,'Първата стъпка от рецептата за таратор е подготовката на краставиците. Измивате краставицата и я обелвате. Ако сте успели да се сдобиете с пресни краставици, произведени от някоя баба на село няма нужда да ги белите. Нарязвате я на много малки парченца / кубчета. Много домакини настъргват краставицата, за да спестят време. Така краставицата омеква повече и тараторът става като каша. Но в случай, че сте наистина жадни и не можете  да чакате дълго, можете да ползвате и този метод.\r\nИзсипвате краставицата в голяма купа и прибавяте към нея ситно нарязания копър (може да ползвате и сух копър), смлените орехи и чесъна, който сте счукали, или нарязали на много дребно. За разлика от французите обаче много българи не обичат чесън, затова можете да не добавяте чесъна към таратора, а да го оставите в отделна чинийка, така всички ще са доволни: любителите на чесън ще си добавят в последствие, а противниците няма да се мръщят.\r\nСлед като сте прибавили чесъна, орехите и копъра поселете, добавете и олиото/зехтина и разбъркайте добре. След това разбийте една кофичка мляко с една кофичка студена вода, добавете към сместа с краставиците и пак разбъркайте. Тараторът е вече готов.\r\nСъвет: Ако ви се стори, че тараторът не е достатъчно студен, може да добавите и няколко кубчета лед.','https://www.supichka.com/%D1%80%D0%B5%D1%86%D0%B5%D0%BF%D1%82%D0%B0/423/%D1%82%D0%B0%D1%80%D0%B0%D1%82%D0%BE%D1%80-%D0%BF%D1%8A%D0%BB%D0%BD%D0%B0%D1%82%D0%B0-%D1%80%D0%B5%D1%86%D0%B5%D0%BF%D1%82%D0%B0',5,'recipe_images/tarator.jpg'),(21,'Печени картофи',40,'','',3,''),(22,'Плато колбаси',5,'',NULL,6,'recipe_images/plato-kolbasi.jpg'),(23,'Плато сирена',5,'Нарежете кашкавала на триъгълници, останалите сирена направете на парченца по избор и подредете според въображението си в голямо плато, за предпочитане плоско и с тъмен цвят, за да се открояват сирената и да е по-красиво.',NULL,6,'recipe_images/plato-sirena-plodove.webp'),(24,'Варени яйца с майонеза',10,'Сварените яйца нарязваме на кръгчета, нареждаме керемидообразно и в кръг в салатна чинийка, по 1 яйце за порция.\r\n\r\nПоръсваме отгоре с 1/2 с.л. краставички - нарязани на кубчета. Заливаме ги с по 1 с.л. от соса приготвен от майонезата, киселото мляко, горчицата и черния пипер.\r\n\r\nУкрасяваме със ситно нарязан копър.','https://recepti.gotvach.bg/r-3746-%D0%AF%D0%B9%D1%86%D0%B0_%D1%81_%D0%BC%D0%B0%D0%B9%D0%BE%D0%BD%D0%B5%D0%B7%D0%B0',6,'recipe_images/qica-ordiovar.webp'),(25,'Крокети с тиквички',40,'1️⃣. Подготовка на зеленчуците\r\nНастържете тиквичката, моркова и картофа. Използвайте ренде с големи дупки.\r\nПоставете настърганите зеленчуци в гевгир и ги посолете. Оставете ги да се отцеждат за около 15-20 минути, за да се премахне излишната влага.\r\n2️⃣. Приготвяне на сместа\r\nВ голяма купа комбинирайте отцедените зеленчуци, нарязаните на ситно скилидки чесън, нарязан магданоз, яйца, натрошеното сирене, овесените ядки и брашното.\r\nПодправете със сол, черен пипер, италиански билки и червен пипер на вкус. Разбъркайте добре, докато се получи хомогенна смес.\r\n3️⃣. Формиране на крокетите\r\nС мокри ръце оформете малки крокети или топчета от сместа.\r\nМожете да ги направите в желаната форма – овални или плоски. Оваляйте ги в брашно.\r\n4️⃣. Пържене\r\nЗагрейте зехтин в тиган на средна температура.\r\nПържете крокетите за около 3-4 минути от всяка страна или докато станат златисти и хрупкави.\r\n5️⃣. Сервиране\r\nИзвадете крокетите от тигана и ги поставете върху кухненска хартия, за да се отцеди излишната мазнина.\r\nСервирайте топли с любимия си сос или салата.','https://domashnakunyasdani.com/2025/03/15/%D1%80%D0%B5%D1%86%D0%B5%D0%BF%D1%82%D0%B0-%D0%B7%D0%B0-%D0%BA%D1%80%D0%BE%D0%BA%D0%B5%D1%82%D0%B8-%D1%81-%D1%82%D0%B8%D0%BA%D0%B2%D0%B8%D1%87%D0%BA%D0%B8/',2,'recipe_images/kroketi-tikvichki-1.jpg'),(26,'Крем супа от тиквички с крема сирене',15,'Тиквичките измих добре и нарязах на едро. Картофа обелих, измих и нарязах на едро. Обелените моркови настъргах на едро ренде. В каната загрях 1,5 л. вода.\r\nВ дълбока тенджера загрях олиото и 1 с.л. масло. Прибавих моркова, посолих го и готвих, докато отдели красивия си цвят. След това прибавих картофите и тиквичките, посолих ги и разбърках. След 1-2 минути полях с врящата вода. Варих на средна степен на котлона под леко открехнат капак, докато зеленчуците омекнаха напълно. Тогава добавих пресованите скилидки чесън и варих още 2-3 минути. Последно прибавих ситно нарязания копър и варих още 5-6 минути. Тук е моментът да проверим дали супата се нуждае от още сол и да добавим. Оставих я леко да изстине за 10 минути, след което добавих крема сиренето и пасирах с пасатор до желаната гладкост. Към готовата супа добавих двете лъжици масло, разбърках и когато се разтопиха, сервирах с крутони, които приготвих от нарязан на дребно хляб, който запържих в масло.\r\nСупата може да се консумира и топла и охладена.','https://inthebeniskitchen.com/2025/07/01/%d0%ba%d1%80%d0%b5%d0%bc-%d1%81%d1%83%d0%bf%d0%b0-%d0%be%d1%82-%d1%82%d0%b8%d0%ba%d0%b2%d0%b8%d1%87%d0%ba%d0%b8-%d1%81-%d0%ba%d1%80%d0%b5%d0%bc%d0%b0-%d1%81%d0',5,'recipe_images/krem-supa-tikvichki_J82af4S.jpg'),(27,'Шопска салата',10,'1. Сладките чушки се почистват от семките и дръжките, нарязват се на малки парченца и се смесват с нарязаните на кубчета домати и краставици.\r\n2. Добавя се нарязаният на тънки шайби лук и всичко се овкусява с олио, оцет и сол.\r\n3. Салатата се разпределя в чинии, отгоре се настъргва сирене и се слага стръкче магданоз.\r\n4. Отстрани на всяка чиния се слага по една люта чушка.','https://www.billa.bg/recepti/shopska-salata',1,'recipe_images/shopska-salata.webp'),(28,'Салата от печени чушки и боб',20,'1. Чушките се цепват по дължина от едната страна, разтварят се и се почистват от семките.\r\n2. Бобът се отцежда и се слага в купа. Добавят се накълцаните сушени домати, чесън и магданоз.\r\n3. Овкусява се с оцета, маслиновото масло и сол. Разбърква се.\r\n4. Бобената смес се сипва върху чушките и те се прихлупват. Поръсват се с натрошеното сирене и нарязаните на едро сварени яйца.','https://www.billa.bg/recepti/salata-ot-pecheni-chushki-i-bob',1,'recipe_images/pecheni-chushki-bob.webp'),(29,'Яхния от червена леща с кюфтенца',45,'1. За кюфтенцата към каймата се прибавят нарязаните лук и половината скилидки чесън, яйцето, галетата, солта, черният пипер и млякото. Омесва се добре и се оформят кюфтенца, които се пържат в загрято маслиново масло, докато се зачервят приятно от всички страни – приблизително за 7–8 минути.\r\n2. Мазнината за яхнията се загрява в тенджера, слага се нарязаният лук и се запържва няколко минути, докато омекне.\r\n3. Прибавят се накълцаният чесън, лютият пипер и пушеният червен пипер. Веднага щом подправките пуснат аромата си, се слагат лещата, 400 мл вода и доматеното пюре.\r\n4. Готви се 10 минути, поръсва се със сол, пускат се приготвените кюфтенца и ястието се готви още 10 минути. Накрая се прибавят куркумата и спанакът.','https://www.billa.bg/recepti/yahniya-ot-chervena-lescha-s-kyuftentsa',2,'recipe_images/chervena-leshta-kufteta.webp'),(30,'Пържени тиквички с млечен сос',30,'','https://www.supichka.com/%D1%80%D0%B5%D1%86%D0%B5%D0%BF%D1%82%D0%B0/78/%D0%BF%D1%8A%D1%80%D0%B6%D0%B5%D0%BD%D0%B8-%D1%82%D0%B8%D0%BA%D0%B2%D0%B8%D1%87%D0%BA%D0%B8-%D1%81-%D0%BC%D0%BB%D0%B5%D1%87%D0%B5',3,'recipe_images/тиквички.jpg'),(31,'Мързеливки от Ани Бокова',40,'пълнозърнесто брашно!\r\n1. Брашното се пресява. Отделно смесваме киселото мляко и содата бикарбонат. Добавяме млякото към брашното и разбъркваме на ръка с вилица или бъркалка. Добавяме олиото и накрая сиренето.\r\n2. При желание добавяме семена или зелени подправки като мащерка, босилек и омесваме лепкаво тесто. За оформянето намазняваме ръцете си с олио и оформяме малки топчета с диаметър около 5 см.\r\n3. Нареждаме в тава, покрита с хартия за печене и печем на 180 градуса с вентилатор до готовност. Да ви е сладко!','https://sofiamel.bg/bg/recipes/mrzelivki-1',4,'recipe_images/мързеливки.jpg');
/*!40000 ALTER TABLE `cooking_recipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cooking_recipecategory`
--

DROP TABLE IF EXISTS `cooking_recipecategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cooking_recipecategory` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cooking_recipecategory`
--

LOCK TABLES `cooking_recipecategory` WRITE;
/*!40000 ALTER TABLE `cooking_recipecategory` DISABLE KEYS */;
INSERT INTO `cooking_recipecategory` VALUES (1,'Салата'),(2,'Основни ястия'),(3,'Гарнитури'),(4,'Закуска'),(5,'Супи'),(6,'Ордьоври');
/*!40000 ALTER TABLE `cooking_recipecategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cooking_recipeingredient`
--

DROP TABLE IF EXISTS `cooking_recipeingredient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cooking_recipeingredient` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` decimal(6,3) NOT NULL,
  `product_id` bigint NOT NULL,
  `recipe_id` bigint NOT NULL,
  `unit` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cooking_recipeingred_product_id_f3c01889_fk_shopping_` (`product_id`),
  KEY `cooking_recipeingredient_recipe_id_4aa87ef8_fk_cooking_recipe_id` (`recipe_id`),
  CONSTRAINT `cooking_recipeingred_product_id_f3c01889_fk_shopping_` FOREIGN KEY (`product_id`) REFERENCES `shopping_product` (`id`),
  CONSTRAINT `cooking_recipeingredient_recipe_id_4aa87ef8_fk_cooking_recipe_id` FOREIGN KEY (`recipe_id`) REFERENCES `cooking_recipe` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cooking_recipeingredient`
--

LOCK TABLES `cooking_recipeingredient` WRITE;
/*!40000 ALTER TABLE `cooking_recipeingredient` DISABLE KEYS */;
INSERT INTO `cooking_recipeingredient` VALUES (1,0.200,69,1,''),(2,0.200,70,1,''),(3,0.050,35,1,''),(4,0.050,27,1,''),(5,0.030,71,1,''),(6,0.030,24,1,''),(7,0.030,72,1,''),(8,0.400,5,2,''),(9,0.300,11,2,''),(10,0.010,74,2,''),(11,0.050,75,2,''),(12,0.020,58,2,''),(13,0.200,40,2,''),(14,0.400,5,3,''),(15,0.010,11,3,''),(16,0.010,10,3,''),(17,1.000,65,3,''),(18,0.250,77,4,''),(19,0.010,11,4,''),(20,0.010,78,4,''),(21,0.200,33,5,''),(22,0.200,7,5,''),(23,0.010,28,5,''),(24,0.010,11,5,''),(25,0.500,61,5,''),(26,0.010,79,5,''),(27,0.010,24,5,''),(28,0.010,76,5,''),(29,0.200,69,5,''),(30,0.500,5,6,''),(31,0.010,24,6,''),(32,0.300,19,7,''),(33,0.200,80,7,''),(34,0.300,81,7,''),(35,0.300,6,7,''),(36,0.300,82,7,''),(37,3.000,83,8,''),(38,0.500,24,8,''),(39,0.200,77,8,''),(40,0.080,40,8,''),(41,0.100,8,8,''),(42,0.250,84,9,''),(43,0.050,75,9,''),(44,0.500,48,9,''),(45,2.000,103,9,''),(46,0.100,24,9,''),(47,0.010,85,9,''),(48,4.000,103,10,''),(49,0.500,37,10,''),(50,1.000,61,10,''),(51,0.030,49,10,''),(52,0.100,24,10,''),(53,0.010,85,10,''),(54,0.200,12,10,''),(55,0.300,33,11,''),(56,0.150,11,11,''),(57,0.010,74,11,''),(58,0.100,10,11,''),(59,0.300,81,11,''),(60,0.100,95,11,''),(61,0.100,96,11,''),(62,0.010,85,11,''),(63,0.010,24,11,''),(64,0.010,97,11,''),(65,0.010,98,11,''),(66,0.500,5,12,''),(67,0.250,11,12,''),(68,0.040,24,12,''),(69,0.010,85,12,''),(70,0.010,99,12,''),(71,0.100,11,13,''),(72,0.100,10,13,''),(73,0.100,81,13,''),(74,0.250,100,13,''),(75,0.200,101,13,''),(76,0.050,102,13,''),(77,1.000,103,13,''),(78,0.500,44,13,''),(79,0.050,24,13,''),(80,0.010,85,13,''),(81,0.200,92,14,''),(82,0.010,85,14,''),(83,0.050,24,14,''),(84,0.050,75,14,''),(85,0.020,58,14,''),(86,3.000,103,14,''),(87,0.170,47,14,''),(88,0.080,11,15,''),(89,0.010,10,15,''),(90,0.500,104,15,''),(91,0.500,100,15,''),(92,0.300,95,15,''),(93,0.300,105,15,''),(94,0.020,40,15,''),(95,0.010,74,15,''),(96,0.010,58,15,''),(97,0.010,85,15,''),(98,1.000,103,15,''),(99,0.300,44,15,''),(100,0.380,95,16,''),(101,2.000,103,16,''),(102,0.035,44,16,''),(103,0.060,47,16,''),(104,0.090,75,16,''),(105,0.010,74,16,''),(106,0.010,85,16,''),(107,0.050,46,16,''),(109,0.100,53,18,''),(110,0.010,128,18,''),(111,0.050,76,18,''),(112,0.050,129,18,''),(113,0.010,74,18,''),(114,0.010,131,18,''),(115,0.030,130,18,''),(116,0.010,85,18,''),(117,0.700,81,19,'кг'),(118,4.000,103,19,'бр'),(119,0.100,47,19,'кг'),(120,0.050,24,19,'л'),(121,0.500,6,19,'кг'),(122,0.050,11,19,'кг'),(123,0.200,80,20,'кг'),(124,0.020,24,20,'л'),(125,0.020,201,20,'кг'),(126,0.500,115,20,'вр.'),(127,0.400,44,20,'кг'),(128,0.015,74,20,'кг'),(129,0.300,39,20,'л'),(130,0.010,203,21,''),(131,0.010,78,21,''),(132,0.700,100,21,''),(133,0.050,24,21,''),(134,0.010,85,21,''),(135,0.010,99,21,''),(136,0.200,45,22,'кг'),(137,0.200,35,23,'кг'),(138,6.000,103,24,'бр.'),(139,0.150,34,23,'кг'),(140,0.250,95,25,'кг'),(141,0.100,10,25,'кг'),(142,0.100,100,25,'кг'),(143,2.000,103,25,'бр.'),(144,0.100,47,25,'кг'),(145,0.010,74,25,'кг'),(146,0.010,85,25,'кг'),(147,0.010,99,25,'кг'),(148,0.010,58,25,'кг'),(149,0.050,75,25,'кг'),(150,0.010,130,25,'l'),(151,0.010,206,25,NULL),(152,0.700,95,26,''),(153,0.170,10,26,''),(154,0.250,100,26,''),(155,0.010,74,26,''),(156,0.010,24,26,''),(157,0.015,46,26,''),(158,0.010,85,26,''),(159,0.010,115,26,''),(160,0.170,49,26,''),(161,0.200,50,24,NULL),(162,0.100,172,24,NULL),(163,0.050,44,24,NULL),(164,0.005,99,24,NULL),(165,0.010,115,24,NULL),(166,0.150,7,23,NULL),(167,0.200,6,27,''),(168,0.200,80,27,''),(169,0.100,81,27,''),(170,0.050,11,27,''),(171,0.200,47,27,''),(172,0.050,93,27,''),(173,0.010,206,27,''),(174,0.150,51,28,''),(175,0.400,197,28,''),(176,0.150,47,28,''),(177,0.050,217,28,''),(178,0.010,74,28,''),(179,0.500,206,28,''),(180,2.000,103,28,''),(181,0.075,130,28,''),(182,0.030,71,28,''),(183,0.350,218,29,''),(184,0.075,219,29,''),(185,0.250,11,29,''),(186,0.050,74,29,''),(187,0.200,40,29,''),(188,0.200,69,29,''),(189,0.050,130,29,''),(190,0.010,203,29,''),(191,0.010,58,29,''),(192,0.010,85,29,''),(193,0.250,104,29,''),(194,1.000,103,29,''),(195,0.100,87,29,''),(196,0.250,95,30,''),(197,0.010,24,30,''),(198,0.010,85,30,''),(199,0.100,75,30,NULL),(200,0.400,44,30,NULL),(201,0.010,74,30,NULL),(202,0.010,115,30,NULL),(203,0.300,75,31,''),(204,0.200,44,31,''),(205,0.080,128,31,''),(206,0.060,47,31,''),(207,0.050,34,31,''),(208,0.100,138,31,''),(209,0.060,24,31,'');
/*!40000 ALTER TABLE `cooking_recipeingredient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cooking_recipetimescooked`
--

DROP TABLE IF EXISTS `cooking_recipetimescooked`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cooking_recipetimescooked` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `recipe_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `date` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cooking_recipetimesc_recipe_id_f7cb2e9d_fk_cooking_r` (`recipe_id`),
  KEY `cooking_recipetimesc_user_id_faeacf59_fk_users_cus` (`user_id`),
  CONSTRAINT `cooking_recipetimesc_recipe_id_f7cb2e9d_fk_cooking_r` FOREIGN KEY (`recipe_id`) REFERENCES `cooking_recipe` (`id`),
  CONSTRAINT `cooking_recipetimesc_user_id_faeacf59_fk_users_cus` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cooking_recipetimescooked`
--

LOCK TABLES `cooking_recipetimescooked` WRITE;
/*!40000 ALTER TABLE `cooking_recipetimescooked` DISABLE KEYS */;
INSERT INTO `cooking_recipetimescooked` VALUES (1,22,2,'2025-07-13 15:58:35.096332'),(2,27,2,'2025-07-14 16:19:23.652260'),(3,6,2,'2025-07-14 16:20:06.093295'),(4,20,2,'2025-07-16 18:18:56.378916'),(5,20,2,'2025-07-16 18:19:23.573421'),(6,19,2,'2025-07-16 18:20:10.974856'),(7,22,2,'2025-07-16 18:20:47.755283');
/*!40000 ALTER TABLE `cooking_recipetimescooked` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_users_customuser_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_users_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2025-05-28 08:11:28.858064','1','Хранителни стоки',1,'[{\"added\": {}}]',12,1),(2,'2025-05-28 08:11:30.911816','1','Безалкохолни напитки (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(3,'2025-05-28 08:11:42.902591','1','Кока Кола - Безалкохолни напитки (Хранителни стоки)',1,'[{\"added\": {}}]',14,1),(4,'2025-05-28 08:12:31.876051','2','Яйца и Млечни продукти (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(5,'2025-05-28 08:12:39.953259','2','Сирене - Яйца и Млечни продукти (Хранителни стоки)',1,'[{\"added\": {}}]',14,1),(6,'2025-05-28 08:12:54.667824','1','B',1,'[{\"added\": {}}]',17,1),(7,'2025-05-28 08:13:04.858297','1','BILLA',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',17,1),(8,'2025-05-28 08:13:13.932880','2','LIDL',1,'[{\"added\": {}}]',17,1),(9,'2025-05-28 08:13:22.674740','3','Fantastico',1,'[{\"added\": {}}]',17,1),(10,'2025-05-28 08:16:32.086117','3','Бира (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(11,'2025-06-01 08:24:25.905780','2','Добашни потреби',1,'[{\"added\": {}}]',12,1),(12,'2025-06-01 08:24:37.146842','3','Луксозни',1,'[{\"added\": {}}]',12,1),(13,'2025-06-01 08:24:42.772132','4','Козметика',1,'[{\"added\": {}}]',12,1),(14,'2025-06-01 08:24:49.814306','5','Други',1,'[{\"added\": {}}]',12,1),(15,'2025-06-01 08:24:56.013681','6','Пътуване',1,'[{\"added\": {}}]',12,1),(16,'2025-06-01 08:25:02.693874','7','Уреди за дома',1,'[{\"added\": {}}]',12,1),(17,'2025-06-01 08:25:13.423112','8','Транспорт',1,'[{\"added\": {}}]',12,1),(18,'2025-06-01 08:25:19.988198','9','Здраве',1,'[{\"added\": {}}]',12,1),(19,'2025-06-01 08:25:26.179933','10','Дрехи',1,'[{\"added\": {}}]',12,1),(20,'2025-06-01 08:26:23.446603','4','Месо (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(21,'2025-06-01 08:26:31.290538','5','Зеленчуци (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(22,'2025-06-01 08:26:39.241222','6','Плодове (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(23,'2025-06-01 08:26:54.088993','7','Алкохол (Луксозни)',1,'[{\"added\": {}}]',13,1),(24,'2025-06-01 08:27:09.479156','8','Почистващи препарати (Добашни потреби)',1,'[{\"added\": {}}]',13,1),(25,'2025-06-01 08:27:29.590432','9','Козметика (Козметика)',1,'[{\"added\": {}}]',13,1),(26,'2025-06-01 08:27:43.064061','10','Тестени изделия (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(27,'2025-06-01 08:28:22.575161','11','Кафе (Луксозни)',1,'[{\"added\": {}}]',13,1),(28,'2025-06-01 08:28:35.262791','12','Цигари (Луксозни)',1,'[{\"added\": {}}]',13,1),(29,'2025-06-01 08:28:53.743624','13','Глезотии (Луксозни)',1,'[{\"added\": {}}]',13,1),(30,'2025-06-01 08:29:02.988948','14','Други (Други)',1,'[{\"added\": {}}]',13,1),(31,'2025-06-01 08:29:13.271592','15','Десерти (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(32,'2025-06-01 08:29:27.772386','16','Продукти за готвене (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(33,'2025-06-01 08:29:48.999224','17','Електроуреди (Уреди за дома)',1,'[{\"added\": {}}]',13,1),(34,'2025-06-01 08:30:10.729310','18','Колбаси (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(35,'2025-06-01 08:30:45.686754','19','Консерви (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(36,'2025-06-01 08:30:56.506121','20','Подправки (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(37,'2025-06-01 08:31:10.679721','21','Храна от ресторант (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(38,'2025-06-01 08:31:37.462397','22','Автомобил (Транспорт)',1,'[{\"added\": {}}]',13,1),(39,'2025-06-01 08:31:45.007877','23','Лекарства (Здраве)',1,'[{\"added\": {}}]',13,1),(40,'2025-06-01 08:31:54.712074','24','Вода (Хранителни стоки)',1,'[{\"added\": {}}]',13,1),(41,'2025-06-01 08:32:06.890801','25','Дрехи (Дрехи)',1,'[{\"added\": {}}]',13,1),(42,'2025-06-01 08:32:27.742099','14','Други (Хранителни стоки)',2,'[{\"changed\": {\"fields\": [\"Main category\"]}}]',13,1),(43,'2025-06-14 17:45:48.637911','127','Нахут - Продукти за готвене (Хранителни стоки)',1,'[{\"added\": {}}]',14,2),(44,'2025-06-14 17:46:13.360466','128','Сода за хляб - Продукти за готвене (Хранителни стоки)',1,'[{\"added\": {}}]',14,2),(45,'2025-06-14 17:46:44.008626','129','Тахан сусамов - Продукти за готвене (Хранителни стоки)',1,'[{\"added\": {}}]',14,2),(46,'2025-06-14 17:47:07.794743','130','Зехтин - Продукти за готвене (Хранителни стоки)',1,'[{\"added\": {}}]',14,2),(47,'2025-06-14 17:47:32.254961','131','Кимион - Подправки (Хранителни стоки)',1,'[{\"added\": {}}]',14,2),(48,'2025-06-14 17:50:42.810211','108','0.010 of Чесън in Хумус',3,'',9,2),(49,'2025-06-14 17:58:35.140568','17','Хумус',3,'',8,2),(50,'2025-06-15 01:07:30.702338','16','SHELL',1,'[{\"added\": {}}]',17,2),(51,'2025-06-15 01:24:09.819073','28','Градина (Дом)',1,'[{\"added\": {}}]',13,2),(52,'2025-06-15 01:37:13.880104','17','Автосервиз Колос',1,'[{\"added\": {}}]',17,2),(53,'2025-06-15 01:38:37.007650','29','Наем (Дом)',1,'[{\"added\": {}}]',13,2),(54,'2025-06-15 01:39:40.569772','12','Битови сметки',1,'[{\"added\": {}}]',12,2),(55,'2025-06-15 01:40:14.906634','12','Битови сметки',3,'',12,2),(56,'2025-06-15 01:40:34.150285','30','Битови сметки (Дом)',1,'[{\"added\": {}}]',13,2),(57,'2025-06-15 01:44:26.363556','18','Хазяин Люлин',1,'[{\"added\": {}}]',17,2),(58,'2025-06-15 01:44:39.813877','19','Хазяин Надежда',1,'[{\"added\": {}}]',17,2),(59,'2025-06-16 15:01:54.537275','20','IKEA',1,'[{\"added\": {}}]',17,2),(60,'2025-06-22 13:12:14.196100','166','Аспержи - Зеленчуци (Хранителни стоки)',3,'',14,2),(61,'2025-06-22 13:12:32.560129','165','Аспержи - Зеленчуци (Хранителни стоки)',3,'',14,2),(62,'2025-06-23 15:26:49.320827','21','TERRANOVA',1,'[{\"added\": {}}]',17,2),(63,'2025-06-23 15:30:28.394456','22','Mr.Bricolage',1,'[{\"added\": {}}]',17,2),(64,'2025-06-23 15:31:44.185444','23','Класико - В.Търново',1,'[{\"added\": {}}]',17,2),(65,'2025-06-23 15:33:00.461157','24','Аванти',1,'[{\"added\": {}}]',17,2),(66,'2025-06-23 16:22:43.943612','189','Зехтин - Продукти за готвене (Хранителни стоки)',3,'',14,2),(67,'2025-06-26 20:10:07.482498','25','Kaufland',1,'[{\"added\": {}}]',17,2),(68,'2025-06-26 20:10:42.107395','26','EO-DENT',1,'[{\"added\": {}}]',17,2),(69,'2025-06-26 20:19:36.393113','31','Зъболекар (Здраве)',1,'[{\"added\": {}}]',13,2),(70,'2025-06-29 06:45:34.994069','32','Нощувка (Пътуване)',1,'[{\"added\": {}}]',13,2),(71,'2025-06-29 06:46:22.159380','32','Хотел (Пътуване)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',13,2),(72,'2025-06-29 06:47:02.399245','27','Хотел - други',1,'[{\"added\": {}}]',17,2),(73,'2025-06-30 14:58:43.029681','28','ProMarket',1,'[{\"added\": {}}]',17,2),(74,'2025-06-30 15:01:01.647569','199','Диня - Плодове (Хранителни стоки)',1,'[{\"added\": {}}]',14,2),(75,'2025-07-04 16:33:27.118072','6','Мезе',1,'[{\"added\": {}}]',7,2),(76,'2025-07-04 16:38:35.259286','23','Сет сирена',2,'[{\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.15 of \\u041a\\u0430\\u0448\\u043a\\u0430\\u0432\\u0430\\u043b in \\u0421\\u0435\\u0442 \\u0441\\u0438\\u0440\\u0435\\u043d\\u0430\"}}]',8,2),(77,'2025-07-04 17:10:05.612726','176','Сапун - Почистващи препарати (Добашни потреби)',3,'',14,2),(78,'2025-07-04 17:27:01.138659','29','Зъболекар - други',1,'[{\"added\": {}}]',17,2),(79,'2025-07-05 08:44:51.076820','206','Магданоз - Продукти за готвене (Хранителни стоки)',1,'[{\"added\": {}}]',14,2),(80,'2025-07-05 08:45:35.827179','206','Магданоз - Подправки (Хранителни стоки)',2,'[{\"changed\": {\"fields\": [\"Category\"]}}]',14,2),(81,'2025-07-05 08:47:22.161215','25','Крокети с тиквички',2,'[{\"changed\": {\"fields\": [\"Image\"]}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.01 of \\u041c\\u0430\\u0433\\u0434\\u0430\\u043d\\u043e\\u0437 in \\u041a\\u0440\\u043e\\u043a\\u0435\\u0442\\u0438 \\u0441 \\u0442\\u0438\\u043a\\u0432\\u0438\\u0447\\u043a\\u0438\"}}]',8,2),(82,'2025-07-05 08:49:51.918132','19','Миш маш',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(83,'2025-07-05 08:55:43.290175','26','Крем супа от тиквички с крема сирене',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(84,'2025-07-05 08:57:18.626817','26','Крем супа от тиквички с крема сирене',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(85,'2025-07-13 08:10:26.237971','13','Благотворителност',1,'[{\"added\": {}}]',12,2),(86,'2025-07-13 08:10:36.799526','33','Дарения (Благотворителност)',1,'[{\"added\": {}}]',13,2),(87,'2025-07-13 08:11:02.031073','215','Дарения - Дарения (Благотворителност)',1,'[{\"added\": {}}]',14,2),(88,'2025-07-13 08:12:18.442828','30','Благоторителност - други',1,'[{\"added\": {}}]',17,2),(89,'2025-07-13 08:51:47.258730','200','Чесън на прах - Продукти за готвене (Хранителни стоки)',2,'[{\"changed\": {\"fields\": [\"Name\", \"Category\"]}}]',14,2),(90,'2025-07-13 08:53:36.412876','74','Чесън - скилидки - Продукти за готвене (Хранителни стоки)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(91,'2025-07-13 08:54:46.723669','134','Чесън - зелен/пресен - Зеленчуци (Хранителни стоки)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(92,'2025-07-13 09:00:37.243555','147','Студена вода - Битови сметки (Дом)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(93,'2025-07-13 09:01:16.013401','39','Минерална вода - Вода (Хранителни стоки)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(94,'2025-07-13 09:05:27.866382','176','Течен сапун - Почистващи препарати (Добашни потреби)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(95,'2025-07-13 09:18:39.611799','53','Нахут - консерва - Консерви (Хранителни стоки)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(96,'2025-07-13 09:37:35.503297','207','Люти чушки - консерва - Консерви (Хранителни стоки)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(97,'2025-07-13 09:38:17.022872','93','Люти чушки - зелени - Глезотии (Луксозни)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(98,'2025-07-13 15:52:27.151619','26','Крем супа от тиквички с крема сирене',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(99,'2025-07-13 15:52:56.812793','25','Крокети с тиквички',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(100,'2025-07-13 15:53:26.886785','19','Миш маш',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(101,'2025-07-13 15:55:26.668286','8','Ориз с праз и маслини',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(102,'2025-07-13 15:57:46.964106','9','Панирана гъба кладница',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(103,'2025-07-13 16:02:26.833716','26','Крем супа от тиквички с крема сирене',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(104,'2025-07-13 16:02:51.672074','26','Крем супа от тиквички с крема сирене',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(105,'2025-07-13 16:05:04.278907','9','Панирана гъба кладница',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(106,'2025-07-13 16:07:11.256563','26','Крем супа от тиквички с крема сирене',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(107,'2025-07-13 16:17:35.991101','24','Варени яйца с майонеза',2,'[{\"changed\": {\"fields\": [\"Name\", \"Instructions\", \"Url link\", \"Image\"]}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.2 of \\u041a\\u0438\\u0441\\u0435\\u043b\\u0438 \\u043a\\u0440\\u0430\\u0441\\u0442\\u0430\\u0432\\u0438\\u0446\\u0438 in \\u0412\\u0430\\u0440\\u0435\\u043d\\u0438 \\u044f\\u0439\\u0446\\u0430 \\u0441 \\u043c\\u0430\\u0439\\u043e\\u043d\\u0435\\u0437\\u0430\"}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.1 of \\u041c\\u0430\\u0439\\u043e\\u043d\\u0435\\u0437\\u0430 in \\u0412\\u0430\\u0440\\u0435\\u043d\\u0438 \\u044f\\u0439\\u0446\\u0430 \\u0441 \\u043c\\u0430\\u0439\\u043e\\u043d\\u0435\\u0437\\u0430\"}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.05 of \\u041a\\u0438\\u0441\\u0435\\u043b\\u043e \\u043c\\u043b\\u044f\\u043a\\u043e in \\u0412\\u0430\\u0440\\u0435\\u043d\\u0438 \\u044f\\u0439\\u0446\\u0430 \\u0441 \\u043c\\u0430\\u0439\\u043e\\u043d\\u0435\\u0437\\u0430\"}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.005 of \\u0427\\u0435\\u0440\\u0435\\u043d \\u043f\\u0438\\u043f\\u0435\\u0440 in \\u0412\\u0430\\u0440\\u0435\\u043d\\u0438 \\u044f\\u0439\\u0446\\u0430 \\u0441 \\u043c\\u0430\\u0439\\u043e\\u043d\\u0435\\u0437\\u0430\"}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.01 of \\u041a\\u043e\\u043f\\u044a\\u0440 in \\u0412\\u0430\\u0440\\u0435\\u043d\\u0438 \\u044f\\u0439\\u0446\\u0430 \\u0441 \\u043c\\u0430\\u0439\\u043e\\u043d\\u0435\\u0437\\u0430\"}}]',8,2),(108,'2025-07-13 16:18:53.180127','6','Ордьоври',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',7,2),(109,'2025-07-13 16:23:17.927781','23','Плато сирена',2,'[{\"changed\": {\"fields\": [\"Name\", \"Instructions\", \"Image\"]}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.150 of \\u0413\\u0440\\u043e\\u0437\\u0434\\u0435 in \\u041f\\u043b\\u0430\\u0442\\u043e \\u0441\\u0438\\u0440\\u0435\\u043d\\u0430\"}}]',8,2),(110,'2025-07-13 16:25:55.277285','10','Сандвичи с авокадо',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(111,'2025-07-13 16:27:36.398589','20','Таратор',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(112,'2025-07-13 16:31:08.219703','22','Плато колбаси',2,'[{\"changed\": {\"fields\": [\"Name\", \"Image\"]}}]',8,2),(113,'2025-07-13 16:33:36.595844','16','Бъркана баница с тиквички на тиган',2,'[{\"changed\": {\"fields\": [\"Url link\", \"Image\"]}}]',8,2),(114,'2025-07-13 16:35:15.941617','16','Бъркана баница с тиквички на тиган',2,'[{\"changed\": {\"fields\": [\"Url link\"]}}]',8,2),(115,'2025-07-13 16:36:46.403872','18','Хумус',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(116,'2025-07-13 16:39:25.072296','14','Каша с коприва',2,'[{\"changed\": {\"fields\": [\"Url link\", \"Image\"]}}]',8,2),(117,'2025-07-13 16:40:28.145329','12','Друсан кебап',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(118,'2025-07-13 16:41:40.547945','11','Киноа с пъстри зеленчуци',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(119,'2025-07-13 16:42:45.367374','7','Ливанска салата',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(120,'2025-07-13 16:49:44.377881','2','Попска яхния',2,'[{\"changed\": {\"fields\": [\"Instructions\"]}}]',8,2),(121,'2025-07-13 16:51:36.015442','5','Салата с киноа и грозде',2,'[{\"changed\": {\"fields\": [\"Url link\", \"Image\"]}}]',8,2),(122,'2025-07-13 18:26:28.468708','152','Люлин - наем - Наем (Дом)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(123,'2025-07-13 18:26:43.557265','151','Надежда - наем - Наем (Дом)',2,'[{\"changed\": {\"fields\": [\"Name\"]}}]',14,2),(124,'2025-07-13 18:40:01.903321','216','Комуникационни услуги - Битови сметки (Дом)',1,'[{\"added\": {}}]',14,2),(125,'2025-07-13 18:40:51.860765','214','Телевизия - Битови сметки (Дом)',3,'',14,2),(126,'2025-07-13 18:40:51.860818','213','Интернет - Битови сметки (Дом)',3,'',14,2),(127,'2025-07-13 18:41:09.913985','148','Телефон - Битови сметки (Дом)',3,'',14,2),(128,'2025-07-13 18:42:40.127386','31','Електрохолд',1,'[{\"added\": {}}]',17,2),(129,'2025-07-13 18:42:51.610897','32','Софийска вода',1,'[{\"added\": {}}]',17,2),(130,'2025-07-13 18:43:02.923227','33','Топлофикация - София',1,'[{\"added\": {}}]',17,2),(131,'2025-07-13 18:43:42.414035','34','Yettel',1,'[{\"added\": {}}]',17,2),(132,'2025-07-13 18:43:47.989873','35','A1',1,'[{\"added\": {}}]',17,2),(133,'2025-07-13 21:43:56.594537','35','A1',2,'[{\"changed\": {\"fields\": [\"Utility supplier\"]}}]',17,2),(134,'2025-07-13 21:44:02.479678','34','Yettel',2,'[{\"changed\": {\"fields\": [\"Utility supplier\"]}}]',17,2),(135,'2025-07-13 21:44:07.138525','33','Топлофикация - София',2,'[{\"changed\": {\"fields\": [\"Utility supplier\"]}}]',17,2),(136,'2025-07-13 21:44:12.208755','32','Софийска вода',2,'[{\"changed\": {\"fields\": [\"Utility supplier\"]}}]',17,2),(137,'2025-07-13 21:44:16.333203','31','Електрохолд',2,'[{\"changed\": {\"fields\": [\"Utility supplier\"]}}]',17,2),(138,'2025-07-13 21:44:34.086601','19','Хазяин Надежда',2,'[{\"changed\": {\"fields\": [\"Utility supplier\"]}}]',17,2),(139,'2025-07-13 21:44:43.553345','18','Хазяин Люлин',2,'[{\"changed\": {\"fields\": [\"Utility supplier\"]}}]',17,2),(140,'2025-07-14 15:31:28.987484','27','Шопска салата',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(141,'2025-07-14 15:37:33.322942','28','Салата от печени чушки и боб',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(142,'2025-07-14 16:17:59.554192','29','Яхния от червена леща с кюфтенца',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(143,'2025-07-17 20:42:51.274152','36','Енерго Про',1,'[{\"added\": {}}]',17,1),(144,'2025-07-17 21:32:58.417105','37','Вътрешен разход',1,'[{\"added\": {}}]',17,1),(145,'2025-07-26 08:51:13.344254','30','Пържени тиквички с млечен сос',2,'[{\"changed\": {\"fields\": [\"Name\", \"Url link\", \"Image\"]}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.1 of \\u0411\\u0440\\u0430\\u0448\\u043d\\u043e in \\u041f\\u044a\\u0440\\u0436\\u0435\\u043d\\u0438 \\u0442\\u0438\\u043a\\u0432\\u0438\\u0447\\u043a\\u0438 \\u0441 \\u043c\\u043b\\u0435\\u0447\\u0435\\u043d \\u0441\\u043e\\u0441\"}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.4 of \\u041a\\u0438\\u0441\\u0435\\u043b\\u043e \\u043c\\u043b\\u044f\\u043a\\u043e in \\u041f\\u044a\\u0440\\u0436\\u0435\\u043d\\u0438 \\u0442\\u0438\\u043a\\u0432\\u0438\\u0447\\u043a\\u0438 \\u0441 \\u043c\\u043b\\u0435\\u0447\\u0435\\u043d \\u0441\\u043e\\u0441\"}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.01 of \\u0427\\u0435\\u0441\\u044a\\u043d - \\u0441\\u043a\\u0438\\u043b\\u0438\\u0434\\u043a\\u0438 in \\u041f\\u044a\\u0440\\u0436\\u0435\\u043d\\u0438 \\u0442\\u0438\\u043a\\u0432\\u0438\\u0447\\u043a\\u0438 \\u0441 \\u043c\\u043b\\u0435\\u0447\\u0435\\u043d \\u0441\\u043e\\u0441\"}}, {\"added\": {\"name\": \"recipe ingredient\", \"object\": \"0.01 of \\u041a\\u043e\\u043f\\u044a\\u0440 in \\u041f\\u044a\\u0440\\u0436\\u0435\\u043d\\u0438 \\u0442\\u0438\\u043a\\u0432\\u0438\\u0447\\u043a\\u0438 \\u0441 \\u043c\\u043b\\u0435\\u0447\\u0435\\u043d \\u0441\\u043e\\u0441\"}}]',8,2),(146,'2025-07-26 09:12:56.395958','31','Мързеливки от Ани Бокова',2,'[{\"changed\": {\"fields\": [\"Image\"]}}]',8,2),(147,'2025-07-26 17:18:56.947275','1','Forum Rights',1,'[{\"added\": {}}]',3,1),(148,'2025-07-26 17:22:10.549943','1','Forum Rights',3,'',3,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'contenttypes','contenttype'),(34,'cooking','householdrecipetimescooked'),(8,'cooking','recipe'),(7,'cooking','recipecategory'),(9,'cooking','recipeingredient'),(25,'cooking','recipetimescooked'),(22,'forum','category'),(24,'forum','post'),(23,'forum','thread'),(40,'forum','threadrequest'),(30,'inventory','householdinventoryproduct'),(31,'inventory','householdproductcategory'),(10,'inventory','inventoryproduct'),(11,'inventory','userproductcategory'),(35,'reports','exchangerate'),(39,'reports','householdinflationbasket'),(37,'reports','householdinflationbasketitem'),(38,'reports','userinflationbasket'),(36,'reports','userinflationbasketitem'),(5,'sessions','session'),(15,'shopping','basket'),(16,'shopping','basketitem'),(32,'shopping','householdrecipeshoppinglist'),(33,'shopping','householdshoppinglist'),(12,'shopping','maincategory'),(14,'shopping','product'),(13,'shopping','productcategory'),(21,'shopping','recipeshoppinglist'),(17,'shopping','shop'),(18,'shopping','shopping'),(20,'shopping','shoppinglist'),(19,'shopping','shoppingproduct'),(26,'taskmanager','event'),(27,'taskmanager','task'),(6,'users','customuser'),(28,'users','household'),(29,'users','householdmembership');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-05-28 07:53:30.173316'),(2,'contenttypes','0002_remove_content_type_name','2025-05-28 07:53:30.319878'),(3,'auth','0001_initial','2025-05-28 07:53:30.696547'),(4,'auth','0002_alter_permission_name_max_length','2025-05-28 07:53:30.783016'),(5,'auth','0003_alter_user_email_max_length','2025-05-28 07:53:30.807989'),(6,'auth','0004_alter_user_username_opts','2025-05-28 07:53:30.852354'),(7,'auth','0005_alter_user_last_login_null','2025-05-28 07:53:30.892868'),(8,'auth','0006_require_contenttypes_0002','2025-05-28 07:53:30.900628'),(9,'auth','0007_alter_validators_add_error_messages','2025-05-28 07:53:30.931235'),(10,'auth','0008_alter_user_username_max_length','2025-05-28 07:53:30.972981'),(11,'auth','0009_alter_user_last_name_max_length','2025-05-28 07:53:31.006055'),(12,'auth','0010_alter_group_name_max_length','2025-05-28 07:53:31.088588'),(13,'auth','0011_update_proxy_permissions','2025-05-28 07:53:31.128444'),(14,'auth','0012_alter_user_first_name_max_length','2025-05-28 07:53:31.166643'),(15,'users','0001_initial','2025-05-28 07:53:31.816698'),(16,'admin','0001_initial','2025-05-28 07:53:32.140611'),(17,'admin','0002_logentry_remove_auto_add','2025-05-28 07:53:32.188359'),(18,'admin','0003_logentry_add_action_flag_choices','2025-05-28 07:53:32.220735'),(19,'shopping','0001_initial','2025-05-28 07:53:32.596329'),(20,'shopping','0002_basket_basketitem_basket_products','2025-05-28 07:53:33.244643'),(21,'shopping','0003_alter_basketitem_quantity','2025-05-28 07:53:33.396734'),(22,'shopping','0004_shop_shopping_shoppingproduct','2025-05-28 07:53:34.671695'),(23,'shopping','0005_shoppinglist','2025-05-28 07:53:34.899550'),(24,'shopping','0006_product_calories','2025-05-28 07:53:35.039742'),(25,'cooking','0001_initial','2025-05-28 07:53:35.584936'),(26,'cooking','0002_recipeingredient_unit','2025-05-28 07:53:35.652682'),(27,'cooking','0003_recipe_image','2025-05-28 07:53:35.788780'),(28,'inventory','0001_initial','2025-05-28 07:53:36.195308'),(29,'inventory','0002_inventoryproduct_category_userproductcategory','2025-05-28 07:53:36.672600'),(30,'inventory','0003_alter_inventoryproduct_category','2025-05-28 07:53:36.900704'),(31,'inventory','0004_remove_inventoryproduct_category','2025-05-28 07:53:37.100567'),(32,'inventory','0005_inventoryproduct_category_inventoryproduct_product_and_more','2025-05-28 07:53:37.758858'),(33,'inventory','0006_remove_inventoryproduct_name','2025-05-28 07:53:37.932640'),(34,'inventory','0007_remove_userproductcategory_name','2025-05-28 07:53:38.040591'),(35,'sessions','0001_initial','2025-05-28 07:53:38.139474'),(36,'shopping','0007_recipeshoppinglist','2025-05-28 07:53:38.527636'),(37,'shopping','0008_recipeshoppinglist_sent','2025-05-28 07:53:38.700687'),(38,'users','0002_remove_customuser_username_alter_customuser_email_and_more','2025-05-28 07:53:39.718190'),(39,'users','0003_customuser_phone_number','2025-06-05 19:14:08.402560'),(40,'forum','0001_initial','2025-06-10 22:34:22.972032'),(41,'forum','0002_thread_last_activity_thread_views','2025-06-10 22:34:23.126825'),(42,'shopping','0009_rename_sent_shoppinglist_executed','2025-07-12 00:40:55.122257'),(43,'shopping','0010_rename_sent_recipeshoppinglist_executed','2025-07-12 00:40:55.178287'),(44,'cooking','0004_recipetimescooked','2025-07-13 15:50:17.877841'),(45,'cooking','0005_recipetimescooked_date','2025-07-13 15:50:17.933186'),(46,'shopping','0011_alter_product_name_alter_productcategory_name','2025-07-13 15:50:18.201093'),(47,'shopping','0012_shop_utility_supplier','2025-07-13 21:40:57.528766'),(48,'shopping','0013_remove_basketitem_basket_remove_basketitem_product_and_more','2025-07-14 22:44:40.740948'),(49,'taskmanager','0001_initial','2025-07-14 22:44:40.981258'),(50,'taskmanager','0002_alter_task_priority','2025-07-14 22:44:41.003318'),(51,'users','0004_household_customuser_household_householdmembership','2025-07-17 20:09:59.084777'),(52,'users','0005_alter_customuser_household','2025-07-17 20:09:59.115149'),(53,'inventory','0008_householdinventoryproduct','2025-07-17 20:09:59.403282'),(54,'inventory','0009_householdproductcategory','2025-07-17 20:09:59.606410'),(55,'inventory','0010_householdproductcategory_inventory_related_and_more','2025-07-17 20:09:59.709558'),(56,'inventory','0011_remove_householdproductcategory_inventory_related_and_more','2025-07-17 20:09:59.865567'),(57,'shopping','0014_householdrecipeshoppinglist_householdshoppinglist','2025-07-17 20:10:00.453723'),(58,'shopping','0015_shoppingproduct_not_for_household','2025-07-17 20:10:00.574317'),(59,'cooking','0006_householdrecipetimescooked','2025-07-19 18:15:10.070381'),(60,'shopping','0016_remove_product_available_stock_remove_product_price_and_more','2025-07-19 18:15:10.299510'),(61,'reports','0001_initial','2025-07-22 21:02:30.531467'),(62,'shopping','0017_shopping_currency','2025-07-22 21:02:30.798244'),(63,'shopping','0018_alter_shopping_currency','2025-07-22 21:02:30.856399'),(64,'reports','0002_householdinflationbasket_and_more','2025-07-26 20:19:04.165801'),(65,'reports','0003_alter_householdinflationbasket_name_and_more','2025-07-26 21:24:46.203843'),(66,'forum','0003_alter_category_name_alter_thread_title_threadrequest','2025-07-28 11:59:32.167533'),(67,'forum','0004_threadrequest_approved','2025-07-28 12:32:07.755755'),(68,'forum','0005_remove_threadrequest_approved_threadrequest_staus','2025-07-28 13:19:51.385091'),(69,'forum','0006_rename_staus_threadrequest_status','2025-07-28 13:21:56.616557'),(70,'taskmanager','0003_alter_task_due_date','2025-07-28 13:24:53.993007');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('44do9d795j9m5ciflah8l5igtr3emcnv','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uKEJV:axamkzQOCvTz58AB1OTnQOicph8zwIAtJUksQZSnM48','2025-06-11 10:47:13.266739'),('58ob9hmqo9er2lhh9o11za9binwmh1wl','.eJxVjDsOwjAQBe_iGlk2_iRLSZ8zWOvdDQkgW4qTCnF3iJQC2jcz76USbuuUtiZLmlldlFWn3y0jPaTsgO9YblVTLesyZ70r-qBND5XleT3cv4MJ2_StZQwA4kkoeI_GEHReXOyd63PoydiRQ5ROODAAjyBRMnVnbwN6cAjq_QHwFjgq:1uKdbU:PlQhNYapn4CdVT4SM0qz2viNgdxQcNKU7jH57o4NR9c','2025-06-12 13:47:28.345970'),('60ya2uyztgos89viba2lzlt8nmzhii4n','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uRB16:v-GOQat8K8xvpplpo_tzy6mXg7Hje3kXDAfipGvFh4M','2025-06-30 14:40:56.420557'),('8r86nwf18asaoomznj579i0z64c2bg7d','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uRB17:os0qcS-bElxYX3lIC2rUk0a9gT5sX1PMlVspMLdmFVY','2025-06-30 14:40:57.311880'),('a4qovnwzhlej75frpmpxy8kozzpgkqvv','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uc35g:tVLXzAj09pMZ-LKothq5kQ1cfnx0mU1nZqw9ZYJpDy4','2025-07-30 14:26:36.875685'),('a9tdytwqjbtmoqdwcw7g69ueduou7x85','.eJxVjDsOwjAQBe_iGlmON_Y6lPQ5g7XedUgA2VI-FeLuJFIKaN_MvLeKtK1j3JY8x0nUVYG6_G6J-JnLAeRB5V4117LOU9KHok-66L5Kft1O9-9gpGXca3KIDbjOJOcGksaIsckH55FDEwbuAFrfAiMagQGZwaLYsAuMNidSny--Ezce:1ubZvp:fBCp8w5xJAzSLeB1_APg7Mc7qb5MwLoEkDJtklXd2Nw','2025-07-29 07:18:29.310881'),('a9y49x865iwlfwnbn7dlhrvy0qbzlsl7','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uPQwR:0jcFTznLocotlVxIszw3gijGnHfTDcyHv1L6g0CBzTs','2025-06-25 19:16:55.518235'),('bgtb07ujovj1uhyunj3hzkyhots45y2o','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uQU4i:VHrhZYuwA-ZoLImrjzI3SO9RCuBXdSz-VrUqatejVSc','2025-06-28 16:49:48.136678'),('cno40wbvjmdxdpi80l5wsrtv0hfri6n9','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uKELO:z-jnpBVqt926cBQRzzTWdQzuF06t2-boTOG5xGndzuY','2025-06-11 10:49:10.209305'),('exsd35ty0s9aoyzdvr7ivd7gm4epoa0n','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uWMBc:WNVSQx5K6vyp-BRzixAj3HSmwxYrqBm-don8glUW0EI','2025-07-14 21:37:12.143796'),('gghcyg805smstpe6xm2oph7x2jzq7mjh','.eJxVjMsOwiAQRf-FtSEMb1y69xsIMINUDU1KuzL-uzbpQrf3nHNfLKZtbXEbtMQJ2ZlJdvrdcioP6jvAe-q3mZe5r8uU-a7wgw5-nZGel8P9O2hptG8dAJ3X2QiNVllXhFNZqZBTkqgN1Oo8gilEggKoanKpVnpjQcsAugJ7fwDPEjdH:1ugPQ2:X6jvJoMl1Rvkg21r42vUagKKjqJyuQg1eONMUaRR7l8','2025-08-11 15:05:38.319799'),('gx86vyyc6osfnlciz0xfdh93b5psknos','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uQUIm:Z4EtA-CJs_luQLw3VXSNs0qvUl3fk_Y19Z6Cd8TC4MY','2025-06-28 17:04:20.083818'),('hvw6yr3es8t905quhszb6e49woafdsjp','.eJxVjDsOwjAQBe_iGlmON_Y6lPQ5g7XedUgA2VI-FeLuJFIKaN_MvLeKtK1j3JY8x0nUVYG6_G6J-JnLAeRB5V4117LOU9KHok-66L5Kft1O9-9gpGXca3KIDbjOJOcGksaIsckH55FDEwbuAFrfAiMagQGZwaLYsAuMNidSny--Ezce:1uUpA7:AKHD0k533s8lnH535--o6E9HdIBBWKn-GIDjWUxGqME','2025-07-10 16:09:19.768113'),('k1aia3ntijeqqjfdw0y6v4no1g1438vw','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uRDtw:LmSrJGpBNW8f8RXbQcvREfGE04k1fZJ4DxMpnh683-I','2025-06-30 17:45:44.317668'),('l1ovbb1moz4snumsrd6s34wfod939t65','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1ueKEz:4qR1a5_d8Tv7yqpIj2RcF7bCBp7SL-kUouyrnVr1gJI','2025-08-05 21:09:37.647499'),('mng4ys5hsjd6pcu87hxt23pc8n60ih2g','.eJxVjskOwiAQht-FsyFsBfHo3TcwITMsbbWBpKUn47tbag96-TL5t8yLOFjr4NYlzm4M5EIEOf1qCP4ZczPCA3JfqC-5ziPSFqGHu9BbCXG6Htm_gQGWYWvzwDBJHXgKXgtvPBceQCBwphJoQIlGWX7WqLqEVjAjRASbrLQawbSv-ljcVDzUseRt8b4yxbtGiTu_d9jJyPsD_H9GkQ:1ubuAb:RpzycwmzqJ99C4-GOY_1_0eKtDKd_iVumcinQf3GPCk','2025-07-30 04:55:05.945002'),('o1i1j1xunzg6q7ici2eb5gop7jykecd9','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uWjCy:7LQy_8IoXRoWjmgbXidc4QEIm44QPPRxoBtt1kM4fCI','2025-07-15 22:12:08.928509'),('o5s3btla5bjv07ai2kyc0sdptblfnxjp','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uXxtP:LMiz56xBOWq3dDwdP8Ar4Sa7B_WIfrjlYMKcJspKV-A','2025-07-19 08:05:03.181616'),('q9zohtffijp1dtk9t9lvdaiqbi1l9tgb','.eJxVjDsOwjAQBe_iGlk2_iRLSZ8zWOvdDQkgW4qTCnF3iJQC2jcz76USbuuUtiZLmlldlFWn3y0jPaTsgO9YblVTLesyZ70r-qBND5XleT3cv4MJ2_StZQwA4kkoeI_GEHReXOyd63PoydiRQ5ROODAAjyBRMnVnbwN6cAjq_QHwFjgq:1udC6D:WwhE6_rVf9t0TsLGIp8CvpRHvsfTj_m9_p4x3DzecGs','2025-08-02 18:15:53.062533'),('tegmuhqyghxup2bysbnsobxojsc90d2y','.eJxVjDsOgzAQBe_iOrIgtoFNmZ4qB7DWu2twgmyJTxXl7gGJImnfzJu38rito98WmX1idVO1uvxuAekl-QD8xDwUTSWvcwr6UPRJF90Xlul-un-BEZdxf0t0AGJJyFmLVUXQWjFNZ0wXXEdVHdk10go7BuAI0kig9mprhxYMwh4dpPipEK6p5L34KDGh-nwBV8w__Q:1uciVE:mcDOMRZZdofyImvG8Qt815i_JFdFdTlIxU6ywpew8Tk','2025-08-01 10:39:44.408916'),('vhcld8v7vdgyhiy0zdce5hmdig46it6w','.eJxVjDEOAiEQRe9CbQgMCGJp7xnIDAOyaiBZdivj3XWTLbT9773_EhHXpcZ15DlOLM4CxOF3I0yP3DbAd2y3LlNvyzyR3BS50yGvnfPzsrt_BxVH_daaFRXjWBdODpJPGhIiEGplCzokQ94GfXJkj4UCKA-QMZRggiP0IN4fAo84Sg:1uWych:S4ygjli9BWooRgZEn-3s_kKXmGfUh3EA5W2Jhy5vVpk','2025-07-16 14:39:43.016958'),('xb6qw7l4qvys3hbp2aefpftr6c2f1p5j','.eJxVjDsOwjAQBe_iGlk2_iRLSZ8zWOvdDQkgW4qTCnF3iJQC2jcz76USbuuUtiZLmlldlFWn3y0jPaTsgO9YblVTLesyZ70r-qBND5XleT3cv4MJ2_StZQwA4kkoeI_GEHReXOyd63PoydiRQ5ROODAAjyBRMnVnbwN6cAjq_QHwFjgq:1uKdbV:26kytzX50zey2w_7kbVQdFMrov5WxVToz8wZ3DJqx9c','2025-06-12 13:47:29.217643');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_category`
--

DROP TABLE IF EXISTS `forum_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_category_name_9f308696_uniq` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_category`
--

LOCK TABLES `forum_category` WRITE;
/*!40000 ALTER TABLE `forum_category` DISABLE KEYS */;
INSERT INTO `forum_category` VALUES (1,'Пари',''),(2,'Общи','');
/*!40000 ALTER TABLE `forum_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_post`
--

DROP TABLE IF EXISTS `forum_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_post` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `author_id` bigint NOT NULL,
  `thread_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forum_post_author_id_609b7963_fk_users_customuser_id` (`author_id`),
  KEY `forum_post_thread_id_f9fa0a56_fk_forum_thread_id` (`thread_id`),
  CONSTRAINT `forum_post_author_id_609b7963_fk_users_customuser_id` FOREIGN KEY (`author_id`) REFERENCES `users_customuser` (`id`),
  CONSTRAINT `forum_post_thread_id_f9fa0a56_fk_forum_thread_id` FOREIGN KEY (`thread_id`) REFERENCES `forum_thread` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_post`
--

LOCK TABLES `forum_post` WRITE;
/*!40000 ALTER TABLE `forum_post` DISABLE KEYS */;
INSERT INTO `forum_post` VALUES (1,'Здравей, Краси','2025-06-11 19:17:41.629221',1,1),(2,'Здр.копеле','2025-06-11 19:18:09.379906',2,1),(3,'Хей','2025-06-12 06:27:36.250481',1,1),(4,'@Краси\r\nХей','2025-06-13 07:05:10.086882',1,1),(5,'Хей','2025-06-23 13:24:42.070322',2,1),(6,'Не ми отваря рецептите. \r\nСекция пътуване е празнааа.Докога така?','2025-07-05 08:02:14.960060',2,2),(7,'Заемам се','2025-07-05 12:46:22.809045',2,2);
/*!40000 ALTER TABLE `forum_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_thread`
--

DROP TABLE IF EXISTS `forum_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_thread` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `category_id` bigint NOT NULL,
  `created_by_id` bigint NOT NULL,
  `last_activity` datetime(6) NOT NULL,
  `views` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_thread_title_463d745a_uniq` (`title`),
  KEY `forum_thread_category_id_dcc73d52_fk_forum_category_id` (`category_id`),
  KEY `forum_thread_created_by_id_42e50e23_fk_users_customuser_id` (`created_by_id`),
  CONSTRAINT `forum_thread_category_id_dcc73d52_fk_forum_category_id` FOREIGN KEY (`category_id`) REFERENCES `forum_category` (`id`),
  CONSTRAINT `forum_thread_created_by_id_42e50e23_fk_users_customuser_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_thread`
--

LOCK TABLES `forum_thread` WRITE;
/*!40000 ALTER TABLE `forum_thread` DISABLE KEYS */;
INSERT INTO `forum_thread` VALUES (1,'Краси и Стоян','2025-06-11 19:15:43.100709',2,1,'2025-07-28 13:53:46.853745',27),(2,'Забележки','2025-07-05 08:01:25.366140',2,2,'2025-07-28 13:55:52.814026',5),(3,'Тест тема 1','2025-07-28 11:29:58.836866',2,4,'2025-07-28 13:40:37.118317',1);
/*!40000 ALTER TABLE `forum_thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_threadrequest`
--

DROP TABLE IF EXISTS `forum_threadrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_threadrequest` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `category_id` bigint NOT NULL,
  `requested_by_id` bigint NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `forum_threadrequest_category_id_fe41a1c6_fk_forum_category_id` (`category_id`),
  KEY `forum_threadrequest_requested_by_id_4378c0ff_fk_users_cus` (`requested_by_id`),
  CONSTRAINT `forum_threadrequest_category_id_fe41a1c6_fk_forum_category_id` FOREIGN KEY (`category_id`) REFERENCES `forum_category` (`id`),
  CONSTRAINT `forum_threadrequest_requested_by_id_4378c0ff_fk_users_cus` FOREIGN KEY (`requested_by_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_threadrequest`
--

LOCK TABLES `forum_threadrequest` WRITE;
/*!40000 ALTER TABLE `forum_threadrequest` DISABLE KEYS */;
INSERT INTO `forum_threadrequest` VALUES (1,'Тест тема 3','Искане за Тема 3','2025-07-28 12:20:18.026327',2,4,'pending'),(2,'Тест тема 4','Тест тема 4 във форума','2025-07-28 12:39:59.422710',2,4,'rejected'),(3,'Фондови борси','Информация за фондовите борси','2025-07-28 13:58:39.733955',1,4,'approved');
/*!40000 ALTER TABLE `forum_threadrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_householdinventoryproduct`
--

DROP TABLE IF EXISTS `inventory_householdinventoryproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_householdinventoryproduct` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` decimal(10,3) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `average_price` decimal(10,2) NOT NULL,
  `daily_consumption` decimal(10,2) NOT NULL,
  `minimum_quantity` decimal(10,2) NOT NULL,
  `category_id` bigint DEFAULT NULL,
  `household_id` bigint NOT NULL,
  `product_id` bigint DEFAULT NULL,
  `inventory_related` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_householdi_category_id_cd85b7e2_fk_shopping_` (`category_id`),
  KEY `inventory_householdi_household_id_68d95390_fk_users_hou` (`household_id`),
  KEY `inventory_householdi_product_id_19075b36_fk_shopping_` (`product_id`),
  CONSTRAINT `inventory_householdi_category_id_cd85b7e2_fk_shopping_` FOREIGN KEY (`category_id`) REFERENCES `shopping_productcategory` (`id`),
  CONSTRAINT `inventory_householdi_household_id_68d95390_fk_users_hou` FOREIGN KEY (`household_id`) REFERENCES `users_household` (`id`),
  CONSTRAINT `inventory_householdi_product_id_19075b36_fk_shopping_` FOREIGN KEY (`product_id`) REFERENCES `shopping_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_householdinventoryproduct`
--

LOCK TABLES `inventory_householdinventoryproduct` WRITE;
/*!40000 ALTER TABLE `inventory_householdinventoryproduct` DISABLE KEYS */;
INSERT INTO `inventory_householdinventoryproduct` VALUES (1,0.000,0.00,0.00,0.00,0.00,22,1,67,0),(2,0.000,0.00,0.00,0.00,0.00,27,1,29,0),(3,0.000,0.00,0.00,0.00,0.00,15,1,72,1),(4,0.000,0.00,0.00,0.00,0.00,27,1,30,0),(5,0.000,0.00,0.00,0.00,0.00,13,1,41,1),(6,0.000,0.00,0.00,0.00,0.00,17,1,25,0),(7,0.000,0.00,0.00,0.04,0.40,9,1,22,1),(8,0.000,0.00,0.00,0.00,0.00,6,1,9,1),(9,0.000,0.00,0.00,0.00,0.00,6,1,59,1),(10,0.000,0.00,0.00,0.00,0.00,1,1,1,1),(11,0.850,1.45,1.71,0.01,0.50,20,1,85,1),(12,0.604,12.31,20.38,0.00,0.10,2,1,34,1),(13,0.000,0.00,0.00,0.00,0.00,16,1,40,1),(14,0.000,0.00,0.00,0.05,0.20,2,1,4,1),(15,0.160,0.43,2.69,0.00,1.00,16,1,75,1),(16,0.000,0.00,0.00,0.00,0.00,6,1,61,1),(17,0.000,0.00,0.00,0.00,0.00,6,1,76,1),(18,1.280,8.16,6.38,0.00,0.00,18,1,45,1),(19,0.200,1.00,5.00,0.00,0.02,16,1,71,1),(20,0.000,0.00,0.00,0.00,0.00,9,1,43,1),(21,1.000,2.00,2.00,0.00,0.00,16,1,65,1),(22,1.090,3.97,3.64,0.05,0.00,16,1,24,1),(23,0.000,0.00,0.00,0.14,1.00,9,1,52,1),(24,3.000,3.99,1.33,0.00,0.00,3,1,48,1),(25,0.000,0.00,0.00,0.00,0.00,6,1,82,1),(26,0.000,0.00,0.00,0.00,0.00,16,1,54,1),(27,0.000,0.00,0.00,0.02,0.04,9,1,73,1),(28,0.000,0.00,0.00,0.00,0.00,22,1,66,0),(29,1.000,1.79,1.79,0.00,1.00,10,1,13,1),(30,0.000,0.00,0.00,0.00,0.00,20,1,55,1),(31,0.000,0.00,0.00,0.00,0.00,20,1,78,1),(32,0.000,0.00,0.00,0.00,0.00,5,1,70,1),(33,0.000,0.00,0.00,0.00,0.00,16,1,42,1),(34,0.000,0.00,0.00,0.00,0.00,19,1,51,1),(35,0.000,0.00,0.00,0.00,0.00,5,1,36,1),(36,0.000,0.00,0.00,0.00,0.00,5,1,33,1),(37,1.000,19.99,19.99,0.00,0.00,7,1,2,1),(38,0.000,0.00,0.00,0.00,0.00,26,1,38,0),(39,2.000,5.21,2.60,0.00,1.00,16,1,64,1),(40,0.000,0.00,0.00,0.00,0.00,18,1,37,1),(41,0.000,0.00,0.00,0.00,0.10,5,1,101,1),(42,0.000,0.00,0.00,0.00,0.00,5,1,96,1),(43,0.000,0.00,0.00,0.00,0.00,13,1,97,1),(44,0.000,0.00,0.00,0.00,0.00,2,1,87,1),(45,0.000,0.00,0.00,0.00,0.00,14,1,91,0),(46,0.160,1.99,12.44,0.05,0.10,5,1,8,1),(47,0.000,0.00,0.00,0.00,0.00,6,1,60,1),(48,0.000,0.00,0.00,0.00,0.00,5,1,84,1),(49,0.000,0.00,0.00,0.00,0.00,5,1,83,1),(50,0.000,0.00,0.00,0.00,0.00,23,1,68,0),(51,0.000,0.00,0.00,0.00,0.00,3,1,106,1),(52,0.000,0.00,0.00,0.00,0.00,15,1,56,1),(53,0.000,0.00,0.00,0.00,0.00,3,1,62,1),(54,0.000,0.00,0.00,0.00,0.00,3,1,3,1),(55,0.000,0.00,0.00,0.05,0.25,13,1,28,1),(56,0.000,0.00,0.00,0.00,0.00,6,1,7,1),(57,0.000,0.00,0.00,0.00,0.00,20,1,98,1),(58,0.000,0.00,0.00,0.00,0.00,26,1,108,0),(59,0.000,0.00,0.00,0.00,0.00,11,1,90,1),(60,0.000,0.00,0.00,0.25,0.00,10,1,107,1),(61,0.000,0.00,0.00,0.00,0.00,20,1,89,1),(62,0.500,1.00,2.00,0.00,0.00,20,1,58,1),(63,0.150,0.50,3.33,0.00,0.10,20,1,79,1),(64,0.000,0.00,0.00,0.00,0.00,19,1,50,1),(65,0.100,0.00,0.00,0.00,0.05,16,1,102,1),(66,0.000,0.00,0.00,0.00,0.00,13,1,86,1),(67,0.000,0.00,0.00,0.00,0.00,13,1,88,1),(68,0.000,0.00,0.00,0.07,0.20,13,1,93,1),(69,0.000,0.00,0.00,0.00,0.00,3,1,31,1),(70,0.995,1.90,1.91,0.00,0.00,20,1,99,1),(71,0.950,5.69,5.99,0.00,0.25,2,1,46,1),(72,16.000,7.50,0.47,0.00,4.00,2,1,103,1),(73,0.000,0.00,0.00,0.00,0.00,5,1,19,1),(74,0.216,0.21,0.97,0.00,0.00,5,1,11,1),(75,5.550,32.99,5.94,0.15,1.00,7,1,16,1),(76,0.000,0.00,0.00,0.00,0.00,20,1,111,1),(77,0.000,0.00,0.00,0.00,0.00,5,1,113,1),(78,1.000,5.45,5.45,0.00,0.10,9,1,112,1),(79,0.000,0.00,0.00,0.00,0.00,5,1,69,1),(80,0.000,0.00,0.00,0.05,0.20,2,1,35,1),(81,0.350,2.90,8.29,0.03,0.30,16,1,17,1),(82,0.000,0.00,0.00,0.00,0.00,12,1,23,0),(83,0.100,2.00,20.00,0.00,0.00,7,1,114,1),(84,0.000,0.00,0.00,0.00,0.00,21,1,57,0),(85,3.300,12.21,3.70,0.00,0.00,5,1,6,1),(86,0.000,0.00,0.00,2.00,2.00,12,1,21,1),(87,0.948,1.09,1.15,0.00,0.50,5,1,100,1),(88,0.236,3.19,13.52,0.00,0.00,4,1,5,1),(89,0.856,2.30,2.69,0.00,0.00,5,1,81,1),(90,2.000,6.88,3.44,0.00,0.05,16,1,77,1),(91,0.010,0.10,10.00,0.00,0.00,5,1,94,1),(92,0.000,0.00,0.00,0.00,0.00,5,1,92,1),(93,1.236,4.34,3.51,0.00,0.00,5,1,80,1),(94,0.000,0.00,0.00,0.00,0.00,5,1,95,1),(95,0.000,0.00,0.00,0.00,0.00,20,1,115,1),(96,0.000,0.00,0.00,0.00,0.00,4,1,109,1),(97,0.020,1.79,89.50,0.00,0.00,20,1,110,1),(98,1.700,2.19,1.29,0.30,0.60,13,1,20,1),(99,0.600,2.69,4.48,0.10,0.50,2,1,49,1),(100,0.000,0.00,0.00,0.00,0.00,5,1,116,1),(101,0.000,0.00,0.00,0.00,0.00,21,1,117,0),(102,4.750,11.68,2.46,0.15,0.50,10,1,18,1),(103,0.000,0.00,0.00,0.00,0.00,3,1,118,1),(104,0.250,0.57,2.28,0.25,0.30,10,1,12,1),(105,0.000,0.00,0.00,0.50,2.00,24,1,39,1),(106,0.000,0.00,0.00,1.00,2.00,10,1,15,1),(107,0.000,0.00,0.00,0.08,0.50,9,1,14,1),(108,1.680,23.28,13.86,0.00,0.20,2,1,47,1),(109,0.000,0.00,0.00,0.10,1.00,2,1,44,1),(110,0.250,0.73,2.92,0.00,0.00,1,1,32,1),(111,0.000,0.00,0.00,0.00,0.00,4,1,104,1),(112,0.750,22.61,30.15,0.00,0.00,11,1,63,1),(113,0.000,0.00,0.00,0.00,0.00,5,1,119,1),(114,0.000,0.00,0.00,0.00,0.00,5,1,105,1),(115,0.000,0.00,0.00,0.00,0.00,6,1,26,1),(116,0.000,0.00,0.00,0.00,0.00,5,1,10,1),(117,1.055,2.07,1.96,0.00,0.00,16,1,74,1),(118,0.900,1.22,1.36,0.10,0.50,13,1,27,1),(119,0.000,0.00,0.00,0.00,0.00,26,1,120,0),(120,0.000,0.00,0.00,0.00,0.00,26,1,121,1),(121,0.320,0.43,1.35,0.02,0.00,14,1,122,1),(122,1.390,4.53,3.26,0.07,0.10,15,1,123,1),(123,0.000,0.00,0.00,0.00,0.00,25,1,124,1),(124,0.000,0.00,0.00,0.00,0.00,26,1,125,0),(125,6.600,41.78,6.33,0.80,2.00,12,1,126,1),(126,0.000,0.00,0.00,0.00,0.00,6,1,132,1),(127,0.550,18.33,33.33,0.05,0.20,7,1,133,1),(128,0.294,2.06,7.01,0.00,0.00,5,1,134,1),(129,0.000,0.00,0.00,0.00,0.00,6,1,135,1),(130,0.000,0.00,0.00,0.00,0.00,6,1,136,1),(131,0.450,0.00,0.00,0.01,0.20,8,1,137,1),(132,0.000,0.00,0.00,0.05,0.20,28,1,138,1),(133,0.000,0.00,0.00,0.00,0.00,28,1,139,0),(134,1.000,12.10,12.10,0.00,0.00,8,1,140,1),(135,23.560,4.36,0.19,0.28,5.00,26,1,141,1),(136,0.000,0.00,0.00,0.00,0.00,26,1,142,0),(137,0.000,0.00,0.00,0.00,0.00,28,1,143,0),(138,1.000,18.00,18.00,0.00,0.00,8,1,144,1),(139,0.000,0.00,0.00,0.00,0.00,26,1,145,0),(140,0.000,0.00,0.00,0.00,0.00,29,1,152,0),(141,0.000,0.00,0.00,0.00,0.00,27,1,153,0),(142,0.000,0.00,0.00,0.00,0.00,26,1,154,0),(143,0.000,0.00,0.00,0.00,0.00,26,1,155,0),(144,0.000,0.00,0.00,0.00,0.00,4,1,156,1),(145,0.200,1.79,8.95,0.00,0.00,16,1,157,1),(146,0.000,0.00,0.00,0.00,0.00,26,1,158,0),(147,0.000,0.00,0.00,0.00,0.00,6,1,159,1),(148,0.000,0.00,0.00,0.00,0.00,6,1,161,1),(149,1.000,20.90,20.90,0.00,0.00,8,1,162,1),(150,0.290,1.15,3.97,0.02,0.50,8,1,163,1),(151,0.000,0.00,0.00,0.00,0.00,4,1,164,1),(152,0.000,0.00,0.00,0.00,0.00,6,1,167,1),(153,0.500,0.30,0.60,0.50,5.00,14,1,168,1),(154,0.000,0.00,0.00,0.00,0.00,7,1,169,1),(155,0.000,0.00,0.00,0.00,0.00,1,1,170,1),(156,1.000,2.29,2.29,0.00,0.00,16,1,53,1),(157,0.000,0.00,0.00,0.00,0.00,13,1,171,1),(158,0.350,2.09,5.98,0.05,0.20,2,1,172,1),(159,0.000,0.00,0.00,0.00,0.00,2,1,173,1),(160,0.000,0.00,0.00,0.00,0.00,3,1,174,1),(161,0.770,6.93,9.00,0.01,0.20,9,1,175,1),(162,0.000,0.00,0.00,0.00,0.00,8,1,176,1),(163,0.000,0.00,0.00,0.00,0.00,6,1,177,1),(164,0.000,0.00,0.00,1.00,0.00,4,1,178,1),(165,0.000,0.00,0.00,0.00,0.00,25,1,179,0),(166,0.000,0.00,0.00,0.00,0.00,22,1,180,0),(167,1.000,34.49,34.49,0.00,0.00,7,1,181,1),(168,0.000,0.00,0.00,0.00,0.00,21,1,182,0),(169,0.000,0.00,0.00,0.00,0.00,15,1,183,1),(170,0.000,0.00,0.00,0.00,0.00,5,1,184,1),(171,0.000,0.00,0.00,0.00,0.00,6,1,185,1),(172,0.000,0.00,0.00,0.00,0.00,4,1,186,1),(173,0.000,0.00,0.00,0.00,0.00,10,1,187,1),(174,1.000,2.39,2.39,0.00,0.00,16,1,188,1),(175,1.000,9.99,9.99,0.00,0.00,16,1,130,1),(176,0.000,0.00,0.00,0.00,0.00,31,1,192,0),(177,0.000,0.00,0.00,0.00,0.00,31,1,193,0),(178,0.000,0.00,0.00,0.00,0.00,31,1,194,0),(179,0.000,0.00,0.00,4.00,0.00,11,1,195,1),(180,0.000,0.00,0.00,0.00,0.00,32,1,196,0),(181,1.500,12.00,8.00,0.00,0.00,16,1,197,1),(182,0.310,2.48,8.00,0.03,0.10,15,1,198,1),(183,0.500,0.70,1.40,0.00,0.00,6,1,199,1),(184,0.000,0.00,0.00,0.00,0.00,13,1,201,1),(185,1.000,1.49,1.49,0.00,0.00,3,1,204,1),(186,0.000,0.00,0.00,0.00,0.00,31,1,205,0),(187,1.000,2.93,2.93,0.00,0.00,19,1,207,1),(188,0.000,0.00,0.00,0.00,0.00,9,1,208,0),(189,0.000,0.00,0.00,0.00,0.00,25,1,209,0),(190,1.000,5.49,5.49,0.00,0.00,9,1,210,1),(191,1.000,10.99,10.99,0.00,0.00,4,1,211,1),(192,0.100,1.38,13.80,0.00,0.00,6,1,212,1),(193,0.000,0.00,0.00,0.00,0.00,29,1,151,0),(194,0.000,0.00,0.00,0.00,0.00,33,1,215,0),(195,0.000,0.00,0.00,0.00,0.00,22,1,220,0),(196,0.000,0.00,0.00,0.00,0.00,27,1,221,0),(197,2.000,4.00,2.00,0.00,0.00,3,1,222,1),(198,0.000,0.00,0.00,0.00,0.00,1,1,223,1),(199,1.000,4.70,4.70,0.00,0.00,4,1,224,1),(200,6.000,10850.00,1808.33,0.00,0.00,5,1,225,1);
/*!40000 ALTER TABLE `inventory_householdinventoryproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_householdproductcategory`
--

DROP TABLE IF EXISTS `inventory_householdproductcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_householdproductcategory` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `direct_planning` tinyint(1) NOT NULL,
  `daily_consumption` decimal(10,3) NOT NULL,
  `minimum_quantity` decimal(10,3) NOT NULL,
  `household_id` bigint NOT NULL,
  `product_category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_householdp_household_id_8976a998_fk_users_hou` (`household_id`),
  KEY `inventory_householdp_product_category_id_0174653e_fk_shopping_` (`product_category_id`),
  CONSTRAINT `inventory_householdp_household_id_8976a998_fk_users_hou` FOREIGN KEY (`household_id`) REFERENCES `users_household` (`id`),
  CONSTRAINT `inventory_householdp_product_category_id_0174653e_fk_shopping_` FOREIGN KEY (`product_category_id`) REFERENCES `shopping_productcategory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_householdproductcategory`
--

LOCK TABLES `inventory_householdproductcategory` WRITE;
/*!40000 ALTER TABLE `inventory_householdproductcategory` DISABLE KEYS */;
INSERT INTO `inventory_householdproductcategory` VALUES (1,0,0.000,0.000,1,22),(2,0,0.000,0.000,1,27),(3,1,0.000,0.500,1,5),(4,1,3.000,4.000,1,3),(5,1,0.500,0.500,1,1),(6,0,0.000,0.000,1,13),(7,0,0.000,0.000,1,18),(8,0,0.000,0.000,1,10),(9,0,0.000,0.000,1,12),(10,0,0.000,0.000,1,2),(11,0,0.000,0.000,1,4),(12,1,0.500,0.500,1,6),(13,0,0.000,0.000,1,7),(14,0,0.000,0.000,1,8),(15,0,0.000,0.000,1,9),(16,1,0.050,0.200,1,11),(17,0,0.000,0.000,1,14),(18,0,0.000,0.000,1,15),(19,0,0.000,0.000,1,16),(20,0,0.000,0.000,1,17),(21,0,0.000,0.000,1,19),(22,0,0.000,0.000,1,20),(23,0,0.000,0.000,1,21),(24,0,0.000,0.000,1,23),(25,1,1.000,3.000,1,24),(26,0,0.000,0.000,1,25),(27,0,0.000,0.000,1,26),(35,0,0.000,0.000,1,28),(36,0,0.000,0.000,1,29),(37,0,0.000,0.000,1,30),(38,0,0.000,0.000,1,31),(39,0,0.000,0.000,1,32),(40,0,0.000,0.000,1,33);
/*!40000 ALTER TABLE `inventory_householdproductcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_inventoryproduct`
--

DROP TABLE IF EXISTS `inventory_inventoryproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_inventoryproduct` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` decimal(10,3) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `average_price` decimal(10,2) NOT NULL,
  `daily_consumption` decimal(10,2) NOT NULL,
  `minimum_quantity` decimal(10,2) NOT NULL,
  `user_id` bigint NOT NULL,
  `category_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `inventory_related` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_inventoryp_user_id_01f00f78_fk_users_cus` (`user_id`),
  KEY `inventory_inventoryp_category_id_70f2936c_fk_shopping_` (`category_id`),
  KEY `inventory_inventoryp_product_id_8e8c9cf3_fk_shopping_` (`product_id`),
  CONSTRAINT `inventory_inventoryp_category_id_70f2936c_fk_shopping_` FOREIGN KEY (`category_id`) REFERENCES `shopping_productcategory` (`id`),
  CONSTRAINT `inventory_inventoryp_product_id_8e8c9cf3_fk_shopping_` FOREIGN KEY (`product_id`) REFERENCES `shopping_product` (`id`),
  CONSTRAINT `inventory_inventoryp_user_id_01f00f78_fk_users_cus` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=202 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_inventoryproduct`
--

LOCK TABLES `inventory_inventoryproduct` WRITE;
/*!40000 ALTER TABLE `inventory_inventoryproduct` DISABLE KEYS */;
INSERT INTO `inventory_inventoryproduct` VALUES (1,0.000,0.00,0.00,0.00,0.00,2,27,29,1),(2,0.000,0.00,0.00,0.00,0.00,2,15,72,1),(3,0.000,0.00,0.00,0.00,0.00,2,27,30,1),(4,0.000,0.00,0.00,0.00,0.00,2,13,41,1),(5,0.000,0.00,0.00,0.00,0.00,2,17,25,1),(6,0.020,0.18,9.00,0.04,0.40,2,9,22,1),(7,0.000,0.00,0.00,0.00,0.00,2,6,9,1),(8,0.000,0.00,0.00,0.00,0.00,2,6,59,1),(9,0.000,0.00,0.00,0.00,0.00,2,1,1,1),(10,0.970,1.66,1.71,0.01,0.50,2,20,85,1),(11,0.604,12.31,20.38,0.00,0.10,2,2,34,1),(12,0.000,0.00,0.00,0.00,0.00,2,16,40,1),(13,0.000,0.00,0.00,0.05,0.20,2,2,4,1),(14,0.160,0.43,2.69,0.00,1.00,2,16,75,1),(15,94.550,229.71,2.43,0.00,0.00,2,22,67,1),(16,0.000,0.00,0.00,0.00,0.00,2,6,61,1),(17,0.000,0.00,0.00,0.00,0.00,2,6,76,1),(18,0.280,3.21,11.47,0.00,0.00,2,18,45,1),(19,0.200,1.00,5.00,0.00,0.02,2,16,71,1),(20,0.000,0.00,0.00,0.00,0.00,2,9,43,1),(21,1.000,2.00,2.00,0.00,0.00,2,16,65,1),(22,1.700,6.19,3.64,0.05,0.00,2,16,24,1),(23,1.320,3.52,2.67,0.14,1.00,2,9,52,1),(24,0.000,0.00,0.00,0.00,0.00,2,3,48,1),(25,0.000,0.00,0.00,0.00,0.00,2,6,82,1),(26,0.000,0.00,0.00,0.00,0.00,2,16,54,1),(27,0.000,0.00,0.00,0.02,0.04,2,9,73,1),(28,0.000,0.00,0.00,0.00,0.00,2,22,66,1),(29,1.000,1.79,1.79,0.00,1.00,2,10,13,1),(30,0.000,0.00,0.00,0.00,0.00,2,20,55,1),(31,0.000,0.00,0.00,0.00,0.00,2,20,78,1),(32,0.000,0.00,0.00,0.00,0.00,2,5,70,1),(33,0.000,0.00,0.00,0.00,0.00,2,16,42,1),(34,0.000,0.00,0.00,0.00,0.00,2,19,51,1),(35,0.000,0.00,0.00,0.00,0.00,2,5,36,1),(36,0.000,0.00,0.00,0.00,0.00,2,5,33,1),(37,1.000,19.99,19.99,0.00,0.00,2,7,2,1),(39,0.000,0.00,0.00,0.00,0.00,2,26,38,1),(40,2.000,5.21,2.60,0.00,1.00,2,16,64,1),(41,0.000,0.00,0.00,0.00,0.00,2,18,37,1),(42,0.000,0.00,0.00,0.00,0.10,2,5,101,1),(43,0.000,0.00,0.00,0.00,0.00,2,5,96,1),(44,0.000,0.00,0.00,0.00,0.00,2,13,97,1),(45,0.000,0.00,0.00,0.00,0.00,2,2,87,1),(46,0.000,0.00,0.00,0.00,0.00,2,14,91,1),(47,0.160,1.99,12.46,0.05,0.10,2,5,8,1),(48,0.000,0.00,0.00,0.00,0.00,2,6,60,1),(49,0.000,0.00,0.00,0.00,0.00,2,5,84,1),(50,0.000,0.00,0.00,0.00,0.00,2,5,83,1),(51,1.000,9.45,9.45,0.00,0.00,2,23,68,1),(52,0.000,0.00,0.00,0.00,0.00,2,3,106,1),(53,0.000,0.00,0.00,0.00,0.00,2,15,56,1),(54,0.000,0.00,0.00,0.00,0.00,2,3,62,1),(55,2.000,3.58,1.79,0.00,0.00,2,3,3,1),(56,0.400,4.39,10.97,0.05,0.25,2,13,28,1),(57,0.000,0.00,0.00,0.00,0.00,2,6,7,1),(58,0.000,0.00,0.00,0.00,0.00,2,20,98,1),(59,0.000,0.00,0.00,0.00,0.00,2,26,108,1),(60,0.000,0.00,0.00,0.00,0.00,2,11,90,1),(61,0.000,0.00,0.00,0.25,0.00,2,10,107,1),(62,0.000,0.00,0.00,0.00,0.00,2,20,89,1),(63,0.500,1.00,2.00,0.00,0.00,2,20,58,1),(64,0.010,0.50,50.00,0.00,0.10,2,20,79,1),(65,0.000,0.00,0.00,0.00,0.00,2,19,50,1),(66,0.100,0.00,0.00,0.00,0.05,2,16,102,1),(67,0.000,0.00,0.00,0.00,0.00,2,13,86,1),(68,0.000,0.00,0.00,0.00,0.00,2,13,88,1),(69,0.000,0.00,0.00,0.07,0.20,2,13,93,1),(70,0.000,0.00,0.00,0.00,0.00,2,3,31,1),(71,1.000,1.91,1.91,0.00,0.00,2,20,99,1),(72,0.950,5.69,5.99,0.00,0.25,2,2,46,1),(73,16.000,8.24,0.52,0.00,4.00,2,2,103,1),(74,0.000,0.00,0.00,0.00,0.00,2,5,19,1),(75,0.316,0.31,0.98,0.00,0.00,2,5,11,1),(76,7.200,42.80,5.94,0.15,1.00,2,7,16,1),(77,0.000,0.00,0.00,0.00,0.00,2,20,111,1),(78,0.000,0.00,0.00,0.00,0.00,2,5,113,1),(79,1.000,5.45,5.45,0.00,0.10,2,9,112,1),(80,0.000,0.00,0.00,0.00,0.00,2,5,69,1),(81,0.000,0.00,0.00,0.05,0.20,2,2,35,1),(82,0.680,5.62,8.27,0.03,0.30,2,16,17,1),(83,0.000,0.00,0.00,0.00,0.00,2,12,23,1),(84,0.100,2.00,20.00,0.00,0.00,2,7,114,1),(85,0.000,0.00,0.00,1.00,0.00,2,21,57,1),(86,1.700,4.68,2.75,0.00,0.00,2,5,6,1),(87,3.000,18.60,6.20,2.00,2.00,2,12,21,1),(88,0.948,1.09,1.15,0.00,0.50,2,5,100,1),(89,0.236,3.19,13.52,0.00,0.00,2,4,5,1),(90,1.062,3.07,2.89,0.00,0.00,2,5,81,1),(91,2.000,6.88,3.44,0.00,0.05,2,16,77,1),(92,0.010,0.10,10.00,0.00,0.00,2,5,94,1),(93,0.000,0.00,0.00,0.00,0.00,2,5,92,1),(94,0.766,2.26,2.95,0.00,0.00,2,5,80,1),(95,0.120,0.48,4.00,0.00,0.00,2,5,95,1),(96,0.000,0.00,0.00,0.00,0.00,2,20,115,1),(97,0.000,0.00,0.00,0.00,0.00,2,4,109,1),(98,0.020,1.79,89.50,0.00,0.00,2,20,110,1),(99,1.000,1.39,1.39,0.30,0.60,2,13,20,1),(100,0.000,0.00,0.00,0.10,0.50,2,2,49,1),(101,0.000,0.00,0.00,0.00,0.00,2,5,116,1),(102,0.000,0.00,0.00,1.00,0.00,2,21,117,1),(103,4.400,9.76,2.22,0.15,0.50,2,10,18,1),(104,0.000,0.00,0.00,0.00,0.00,2,3,118,1),(105,1.000,1.69,1.69,0.25,0.30,2,10,12,1),(106,9.900,4.81,0.49,0.50,2.00,2,24,39,1),(107,4.000,3.56,0.89,1.00,2.00,2,10,15,1),(108,0.000,0.00,0.00,0.08,0.50,2,9,14,1),(109,1.040,15.64,15.03,0.00,0.20,2,2,47,1),(110,0.165,0.55,3.32,0.10,1.00,2,2,44,1),(111,1.350,3.25,2.41,0.00,0.00,2,1,32,1),(112,0.000,0.00,0.00,0.00,0.00,2,4,104,1),(113,1.300,39.19,30.15,0.00,0.00,2,11,63,1),(114,0.000,0.00,0.00,0.00,0.00,2,5,119,1),(115,0.000,0.00,0.00,0.00,0.00,2,5,105,1),(116,0.000,0.00,0.00,0.00,0.00,2,6,26,1),(117,0.000,0.00,0.00,0.00,0.00,2,5,10,1),(118,1.055,2.07,1.96,0.00,0.00,2,16,74,1),(119,1.000,1.75,1.75,0.10,0.50,2,13,27,1),(120,1.000,4.99,4.99,0.00,0.00,2,26,120,1),(121,0.000,0.00,0.00,0.00,0.00,2,26,121,1),(122,0.540,0.73,1.36,0.02,0.00,2,14,122,1),(123,2.160,7.05,3.26,0.07,0.10,2,15,123,1),(124,1.000,4.50,4.50,0.00,0.00,2,25,124,1),(125,2.000,11.50,5.75,0.00,0.00,2,26,125,1),(126,5.400,33.48,6.20,0.80,2.00,2,12,126,1),(127,0.000,0.00,0.00,0.00,0.00,2,6,132,1),(128,0.450,11.92,26.49,0.05,0.20,2,7,133,1),(129,0.294,2.06,7.01,0.00,0.00,2,5,134,1),(130,0.000,0.00,0.00,0.00,0.00,2,6,135,1),(131,0.000,0.00,0.00,0.00,0.00,2,6,136,1),(132,0.560,0.00,0.00,0.01,0.20,2,8,137,1),(133,0.100,2.00,20.00,0.05,0.20,2,28,138,1),(134,1.000,9.95,9.95,0.00,0.00,2,28,139,1),(135,1.000,12.10,12.10,0.00,0.00,2,8,140,1),(136,26.640,4.93,0.18,0.28,5.00,2,26,141,1),(137,1.000,9.70,9.70,0.00,0.00,2,26,142,1),(138,1.000,15.95,15.95,0.00,0.00,2,28,143,1),(139,1.000,18.00,18.00,0.00,0.00,2,8,144,1),(140,4.000,14.88,3.72,0.00,0.00,2,26,145,1),(141,5.000,3450.00,690.00,0.00,0.00,2,29,152,1),(142,3.000,109.88,36.63,0.00,0.00,2,27,153,1),(143,1.000,5.99,5.99,0.00,0.00,2,26,154,1),(144,1.000,12.99,12.99,0.00,0.00,2,26,155,1),(145,0.000,0.00,0.00,0.00,0.00,2,4,156,1),(146,0.200,1.79,8.95,0.00,0.00,2,16,157,1),(147,0.000,0.00,0.00,0.00,0.00,2,26,158,1),(148,0.000,0.00,0.00,0.00,0.00,2,6,159,1),(150,0.000,0.00,0.00,0.00,0.00,2,6,161,1),(151,1.000,20.90,20.90,0.00,0.00,2,8,162,1),(152,0.510,2.03,3.98,0.02,0.50,2,8,163,1),(153,0.000,0.00,0.00,0.00,0.00,2,4,164,1),(154,0.000,0.00,0.00,0.00,0.00,2,6,167,1),(155,6.000,3.60,0.60,0.50,5.00,2,14,168,1),(156,0.000,0.00,0.00,0.00,0.00,2,7,169,1),(157,0.000,0.00,0.00,0.00,0.00,2,1,170,1),(158,1.000,2.29,2.29,0.00,0.00,2,16,53,1),(159,0.000,0.00,0.00,0.00,0.00,2,13,171,1),(160,1.000,5.99,5.99,0.05,0.20,2,2,172,1),(161,0.000,0.00,0.00,0.00,0.00,2,2,173,1),(162,0.000,0.00,0.00,0.00,0.00,2,3,174,1),(163,0.880,7.92,9.00,0.01,0.20,2,9,175,1),(164,0.000,0.00,0.00,0.00,0.00,2,8,176,1),(165,0.460,3.00,6.51,0.00,0.00,2,6,177,1),(166,0.000,0.00,0.00,1.00,0.00,2,4,178,1),(167,1.000,14.99,14.99,0.00,0.00,2,25,179,1),(168,2.640,3.51,1.33,0.03,1.00,2,22,180,1),(169,1.000,34.49,34.49,0.00,0.00,2,7,181,1),(170,0.000,0.00,0.00,1.00,0.00,2,21,182,1),(171,0.000,0.00,0.00,0.00,0.00,2,15,183,1),(172,0.000,0.00,0.00,0.00,0.00,2,5,184,1),(173,0.000,0.00,0.00,0.00,0.00,2,6,185,1),(174,0.000,0.00,0.00,0.00,0.00,2,4,186,1),(175,0.000,0.00,0.00,0.00,0.00,2,10,187,1),(176,1.000,2.39,2.39,0.00,0.00,2,16,188,1),(177,1.000,9.99,9.99,0.00,0.00,2,16,130,1),(182,1.000,200.00,200.00,0.00,0.00,2,31,192,1),(183,2.000,55.00,27.50,0.00,0.00,2,31,193,1),(184,1.000,96.00,96.00,0.00,0.00,2,31,194,1),(185,0.000,0.00,0.00,4.00,0.00,2,11,195,1),(186,2.000,184.38,92.19,0.00,0.00,2,32,196,1),(187,1.500,12.00,8.00,0.00,0.00,2,16,197,1),(188,0.640,5.12,8.00,0.03,0.10,2,15,198,1),(189,6.708,7.34,1.09,0.00,0.00,2,6,199,1),(190,0.000,0.00,0.00,0.00,0.00,2,13,201,1),(191,7.000,10.43,1.49,0.00,0.00,2,3,204,1),(192,1.000,70.00,70.00,0.00,0.00,2,31,205,1),(193,1.000,2.93,2.93,0.00,0.00,2,19,207,1),(194,3.000,7.49,2.50,0.00,0.00,2,9,208,1),(195,2.000,4.99,2.50,0.00,0.00,2,25,209,1),(196,1.000,5.49,5.49,0.00,0.00,2,9,210,1),(197,1.000,10.99,10.99,0.00,0.00,2,4,211,1),(198,2.000,1.38,0.69,0.00,0.00,2,6,212,1),(199,1.000,950.00,950.00,0.00,0.00,2,29,151,1),(200,1.000,84.88,84.88,0.00,0.00,2,33,215,1),(201,49.341,121.38,2.46,0.00,0.00,1,22,67,1);
/*!40000 ALTER TABLE `inventory_inventoryproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_userproductcategory`
--

DROP TABLE IF EXISTS `inventory_userproductcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_userproductcategory` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `direct_planning` tinyint(1) NOT NULL,
  `daily_consumption` decimal(10,3) NOT NULL,
  `minimum_quantity` decimal(10,3) NOT NULL,
  `user_id` bigint NOT NULL,
  `product_category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_userproduc_user_id_a4a95f4f_fk_users_cus` (`user_id`),
  KEY `inventory_userproduc_product_category_id_e30f5cb9_fk_shopping_` (`product_category_id`),
  CONSTRAINT `inventory_userproduc_product_category_id_e30f5cb9_fk_shopping_` FOREIGN KEY (`product_category_id`) REFERENCES `shopping_productcategory` (`id`),
  CONSTRAINT `inventory_userproduc_user_id_a4a95f4f_fk_users_cus` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_userproductcategory`
--

LOCK TABLES `inventory_userproductcategory` WRITE;
/*!40000 ALTER TABLE `inventory_userproductcategory` DISABLE KEYS */;
INSERT INTO `inventory_userproductcategory` VALUES (1,1,0.200,0.400,2,1),(2,0,0.000,0.000,2,2),(3,1,3.000,4.000,2,3),(4,0,0.000,0.000,2,4),(5,1,0.000,0.500,2,5),(6,1,0.500,0.400,2,6),(7,0,0.000,0.000,2,7),(8,0,0.000,0.000,2,8),(9,0,0.000,0.000,2,9),(10,0,0.000,0.000,2,10),(11,1,0.050,0.200,2,11),(12,0,0.000,0.000,2,12),(13,0,0.000,0.000,2,13),(14,0,0.000,0.000,2,14),(15,0,0.000,0.000,2,15),(16,0,0.000,0.000,2,16),(17,0,0.000,0.000,2,17),(18,1,0.080,0.200,2,18),(19,0,0.000,0.000,2,19),(20,0,0.000,0.000,2,20),(21,0,0.000,0.000,2,21),(22,0,0.000,0.000,2,22),(23,0,0.000,0.000,2,23),(24,1,0.500,2.000,2,24),(25,0,0.000,0.000,2,25),(26,0,0.000,0.000,2,26),(27,0,0.000,0.000,2,27),(31,0,0.000,0.000,2,31),(32,0,0.000,0.000,2,32),(33,0,0.000,0.000,2,29),(34,0,0.000,0.000,2,33),(35,0,0.000,0.000,1,22);
/*!40000 ALTER TABLE `inventory_userproductcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports_exchangerate`
--

DROP TABLE IF EXISTS `reports_exchangerate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports_exchangerate` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `base_currency` varchar(3) NOT NULL,
  `target_currency` varchar(3) NOT NULL,
  `rate` decimal(12,7) NOT NULL,
  `date_extracted` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reports_exchangerate_base_currency_target_cur_aa70c038_uniq` (`base_currency`,`target_currency`,`date_extracted`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports_exchangerate`
--

LOCK TABLES `reports_exchangerate` WRITE;
/*!40000 ALTER TABLE `reports_exchangerate` DISABLE KEYS */;
INSERT INTO `reports_exchangerate` VALUES (1,'BGN','EUR',0.5117620,'2025-07-23'),(2,'BGN','USD',0.6007440,'2025-07-23'),(3,'BGN','BGN',1.0000000,'2025-07-23'),(4,'BGN','EUR',0.5120630,'2025-07-24'),(5,'BGN','USD',0.6025400,'2025-07-24'),(6,'BGN','EUR',0.5103620,'2025-07-26'),(7,'BGN','USD',0.5995060,'2025-07-26'),(8,'EUR','BGN',1.9561700,'2025-07-28'),(9,'EUR','USD',1.0855820,'2025-07-28');
/*!40000 ALTER TABLE `reports_exchangerate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports_householdinflationbasket`
--

DROP TABLE IF EXISTS `reports_householdinflationbasket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports_householdinflationbasket` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `household_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reports_householdinflationbasket_name_f62b2cf9_uniq` (`name`),
  KEY `reports_householdinf_household_id_6a619d5d_fk_users_hou` (`household_id`),
  CONSTRAINT `reports_householdinf_household_id_6a619d5d_fk_users_hou` FOREIGN KEY (`household_id`) REFERENCES `users_household` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports_householdinflationbasket`
--

LOCK TABLES `reports_householdinflationbasket` WRITE;
/*!40000 ALTER TABLE `reports_householdinflationbasket` DISABLE KEYS */;
INSERT INTO `reports_householdinflationbasket` VALUES (4,'Основна',1),(5,'Втора',1);
/*!40000 ALTER TABLE `reports_householdinflationbasket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports_householdinflationbasketitem`
--

DROP TABLE IF EXISTS `reports_householdinflationbasketitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports_householdinflationbasketitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `basket_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_householdinf_basket_id_5c12a828_fk_reports_h` (`basket_id`),
  KEY `reports_householdinf_product_id_0fa490fa_fk_inventory` (`product_id`),
  CONSTRAINT `reports_householdinf_basket_id_5c12a828_fk_reports_h` FOREIGN KEY (`basket_id`) REFERENCES `reports_householdinflationbasket` (`id`),
  CONSTRAINT `reports_householdinf_product_id_0fa490fa_fk_inventory` FOREIGN KEY (`product_id`) REFERENCES `inventory_householdinventoryproduct` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports_householdinflationbasketitem`
--

LOCK TABLES `reports_householdinflationbasketitem` WRITE;
/*!40000 ALTER TABLE `reports_householdinflationbasketitem` DISABLE KEYS */;
INSERT INTO `reports_householdinflationbasketitem` VALUES (27,4,106),(28,4,1),(29,4,104),(30,4,85),(31,4,93),(32,4,109),(33,5,127),(34,5,51),(35,5,69),(36,5,185),(37,5,75),(38,5,110);
/*!40000 ALTER TABLE `reports_householdinflationbasketitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports_userinflationbasket`
--

DROP TABLE IF EXISTS `reports_userinflationbasket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports_userinflationbasket` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reports_userinflationbasket_name_7f105d4c_uniq` (`name`),
  KEY `reports_userinflatio_user_id_b3465d4b_fk_users_cus` (`user_id`),
  CONSTRAINT `reports_userinflatio_user_id_b3465d4b_fk_users_cus` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports_userinflationbasket`
--

LOCK TABLES `reports_userinflationbasket` WRITE;
/*!40000 ALTER TABLE `reports_userinflationbasket` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports_userinflationbasket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports_userinflationbasketitem`
--

DROP TABLE IF EXISTS `reports_userinflationbasketitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports_userinflationbasketitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `basket_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_userinflatio_basket_id_9148f48c_fk_reports_u` (`basket_id`),
  KEY `reports_userinflatio_product_id_9a3bbbf2_fk_inventory` (`product_id`),
  CONSTRAINT `reports_userinflatio_basket_id_9148f48c_fk_reports_u` FOREIGN KEY (`basket_id`) REFERENCES `reports_userinflationbasket` (`id`),
  CONSTRAINT `reports_userinflatio_product_id_9a3bbbf2_fk_inventory` FOREIGN KEY (`product_id`) REFERENCES `inventory_inventoryproduct` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports_userinflationbasketitem`
--

LOCK TABLES `reports_userinflationbasketitem` WRITE;
/*!40000 ALTER TABLE `reports_userinflationbasketitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports_userinflationbasketitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_householdrecipeshoppinglist`
--

DROP TABLE IF EXISTS `shopping_householdrecipeshoppinglist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_householdrecipeshoppinglist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `executed` tinyint(1) NOT NULL,
  `items` json NOT NULL,
  `recipe_name` varchar(150) NOT NULL,
  `household_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopping_householdre_household_id_e4bdf0bc_fk_users_hou` (`household_id`),
  CONSTRAINT `shopping_householdre_household_id_e4bdf0bc_fk_users_hou` FOREIGN KEY (`household_id`) REFERENCES `users_household` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_householdrecipeshoppinglist`
--

LOCK TABLES `shopping_householdrecipeshoppinglist` WRITE;
/*!40000 ALTER TABLE `shopping_householdrecipeshoppinglist` DISABLE KEYS */;
INSERT INTO `shopping_householdrecipeshoppinglist` VALUES (1,0,'[\"Чушки\"]','Миш маш',1);
/*!40000 ALTER TABLE `shopping_householdrecipeshoppinglist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_householdshoppinglist`
--

DROP TABLE IF EXISTS `shopping_householdshoppinglist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_householdshoppinglist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `executed` tinyint(1) NOT NULL,
  `items` json NOT NULL,
  `date_generated` date NOT NULL,
  `household_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopping_householdsh_household_id_3bd82aca_fk_users_hou` (`household_id`),
  CONSTRAINT `shopping_householdsh_household_id_3bd82aca_fk_users_hou` FOREIGN KEY (`household_id`) REFERENCES `users_household` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_householdshoppinglist`
--

LOCK TABLES `shopping_householdshoppinglist` WRITE;
/*!40000 ALTER TABLE `shopping_householdshoppinglist` DISABLE KEYS */;
INSERT INTO `shopping_householdshoppinglist` VALUES (1,1,'[\"Бира\", \"Люти чушки - зелени\", \"Хляб\", \"Кроасан\", \"Крема сирене\", \"Бисквити/солети\", \"Краставици\", \"Диня\", \"Банани\", \"Загорка\"]','2025-07-22',1),(2,1,'[\"Бира\", \"Дъвки\", \"Кроасан\", \"Кока Кола\", \"Чушки\", \"Яйца\", \"Шуменско\"]','2025-07-25',1),(3,0,'[\"Безалкохолни напитки\", \"Вода\", \"Фъстъци\", \"Люти чушки - зелени\", \"Хляб\", \"Кроасан\", \"Тереа Ръсет\", \"Краве мляко\", \"Фр. сирена\", \"Кисело мляко\", \"Препарат за тоалетна\", \"шампоан\", \"Сапун\", \"Боя за коса\", \"Паста за зъби\", \"Тоалетна хартия\", \"Брашно\", \"Семена\"]','2025-07-26',1);
/*!40000 ALTER TABLE `shopping_householdshoppinglist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_maincategory`
--

DROP TABLE IF EXISTS `shopping_maincategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_maincategory` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_maincategory`
--

LOCK TABLES `shopping_maincategory` WRITE;
/*!40000 ALTER TABLE `shopping_maincategory` DISABLE KEYS */;
INSERT INTO `shopping_maincategory` VALUES (13,'Благотворителност'),(2,'Добашни потреби'),(11,'Дом'),(10,'Дрехи'),(5,'Други'),(9,'Здраве'),(4,'Козметика'),(3,'Луксозни'),(6,'Пътуване'),(8,'Транспорт'),(7,'Уреди за дома'),(1,'Хранителни стоки');
/*!40000 ALTER TABLE `shopping_maincategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_product`
--

DROP TABLE IF EXISTS `shopping_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `category_id` bigint DEFAULT NULL,
  `calories` int unsigned DEFAULT NULL,
  `suitable_for_cooking` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shopping_product_name_5b82338b_uniq` (`name`),
  KEY `shopping_product_category_id_d4eb3dc9_fk_shopping_` (`category_id`),
  CONSTRAINT `shopping_product_category_id_d4eb3dc9_fk_shopping_` FOREIGN KEY (`category_id`) REFERENCES `shopping_productcategory` (`id`),
  CONSTRAINT `shopping_product_chk_1` CHECK ((`calories` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=226 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_product`
--

LOCK TABLES `shopping_product` WRITE;
/*!40000 ALTER TABLE `shopping_product` DISABLE KEYS */;
INSERT INTO `shopping_product` VALUES (1,'Пепси','',1,45,0),(2,'Бакарди','',7,231,1),(3,'Пиринско КЕН','',3,34,0),(4,'Краве мляко','',2,60,1),(5,'Свинско месо','',4,269,1),(6,'Домати','',5,17,1),(7,'Грозде','',6,60,1),(8,'Маслини','',5,115,1),(9,'Мандарини','',6,35,1),(10,'Моркови','',5,41,1),(11,'Лук','',5,36,1),(12,'Хляб','',10,265,1),(13,'Спагети','',10,158,1),(14,'Паста за зъби','',9,0,0),(15,'Кроасан','',10,406,0),(16,'Вино','',7,65,1),(17,'Захар','',16,387,1),(18,'Бисквити/солети','',10,353,1),(19,'Салата','',5,15,1),(20,'Дъвки','',13,0,0),(21,'Тереа Ръсет','',12,0,0),(22,'шампоан','',9,0,0),(23,'Heets','',12,0,0),(24,'Олио','',16,884,1),(25,'Електрическа кана','',17,0,0),(26,'Ябълки','',6,52,1),(27,'Семки','',13,584,1),(28,'Фъстъци','',13,567,1),(29,'фуга','',27,0,0),(30,'лайсни','',27,0,0),(31,'Загорка','',3,34,1),(32,'Кока Кола','',1,45,0),(33,'Киноа','',5,120,1),(34,'Кашкавал','',2,384,1),(35,'Фр. сирена','',2,350,1),(36,'Царевица','',5,88,1),(37,'Бекон','',18,414,1),(38,'Други','',26,0,0),(39,'Минерална вода','',24,0,1),(40,'Доматено пюре','',16,38,1),(41,'Каперси','',13,23,1),(42,'Песто','',16,176,1),(43,'Душ гел','',9,0,0),(44,'Кисело мляко','',2,60,1),(45,'Салами','',18,460,1),(46,'Краве масло','',2,717,1),(47,'Сирене','',2,300,1),(48,'Шуменско','',3,34,0),(49,'Крема сирене','',2,297,1),(50,'Кисели краставици','',19,11,1),(51,'Печени чушки','',19,36,1),(52,'Сапун','',9,0,0),(53,'Нахут - консерва','',19,364,1),(54,'Какао','',16,0,0),(55,'Джоджен','',20,0,0),(56,'Торти','',15,0,0),(57,'Пица','',21,0,0),(58,'Червен пипер','',20,0,0),(59,'Грейпфрут','',6,0,0),(60,'Круши','',6,0,0),(61,'Авокадо','',6,190,1),(62,'Хайнекен','',3,34,0),(63,'Лаваца','',11,1,0),(64,'Кори за баница','',16,299,1),(65,'Сос други','',16,0,1),(66,'Двигателно масло','',22,0,0),(67,'Бензин','',22,0,0),(68,'Лекарства други','',23,0,0),(69,'Спанак','',5,7,1),(70,'Зелена салата','',5,15,1),(71,'Оцет','',16,18,1),(72,'Мед','',15,304,1),(73,'Боя за коса','',9,0,0),(74,'Чесън - скилидки','',16,149,1),(75,'Брашно','',16,364,1),(76,'Лимон','',6,29,1),(77,'Ориз','',16,130,1),(78,'Къри','',20,325,1),(79,'Босилек','',20,23,1),(80,'Краставици','',5,12,1),(81,'Чушки','',5,20,1),(82,'Нар','',6,83,1),(83,'Праз','',5,22,1),(84,'Гъби','',5,80,1),(85,'Сол','',20,0,1),(86,'Чай','',13,0,0),(87,'Прясно мляко','',2,60,1),(88,'Енергийна напитка','',13,0,0),(89,'Индийско орехче','',20,0,0),(90,'Нова Бразилия','',11,1,0),(91,'отстъпка','',14,0,0),(92,'Коприва','',5,42,1),(93,'Люти чушки - зелени','',13,20,1),(94,'Зелен лук','',5,23,1),(95,'Тиквичка','',5,21,1),(96,'Грах','',5,81,1),(97,'Соев сос','',13,53,1),(98,'Джинджифил','',20,80,1),(99,'Черен пипер','',20,17,1),(100,'Картофи','',5,136,1),(101,'Броколи','',5,34,1),(102,'Фиде','',16,330,1),(103,'Яйца','',2,155,1),(104,'Кайма','',4,240,1),(105,'Патладжан','',5,25,1),(106,'Бургаско','',3,34,0),(107,'Козунак','',10,367,0),(108,'Декорация Кокошка','',26,0,0),(109,'Агнешко месо','',4,380,1),(110,'Розмарин','',20,93,1),(111,'Див лук','',20,30,1),(112,'Дамски превръзки','',9,0,0),(113,'Репички','',5,16,1),(114,'Ракия','',7,230,1),(115,'Копър','',20,43,1),(116,'Аспержи','',5,20,1),(117,'Храна ресторант - други','',21,0,0),(118,'Каменица','',3,34,0),(119,'Червено цвекло','',5,43,1),(120,'Гевгир','',26,0,0),(121,'Касерола','',26,0,0),(122,'Салфетки','',14,0,0),(123,'Сладолед','',15,208,1),(124,'Дамски потник','',25,0,0),(125,'Чадър','',26,0,0),(126,'Тереа Тийк','',12,0,0),(128,'Сода за хляб','',16,0,1),(129,'Тахан сусамов','',16,595,1),(130,'Зехтин','',16,884,1),(131,'Кимион','',20,375,1),(132,'Сливи','',6,45,1),(133,'Captain Morgan','',7,231,1),(134,'Чесън - зелен/пресен','',5,149,1),(135,'Боровинки','',6,57,1),(136,'Банани','',6,89,1),(137,'Веро','',8,0,0),(138,'Семена','',28,0,0),(139,'Шайба за набъбване на семена','',28,0,0),(140,'Препарат за почистване на миялна и пералня','',8,0,0),(141,'Торби за смет','',26,0,0),(142,'Четка','',26,0,0),(143,'Дозатор за поливане','',28,0,0),(144,'Препарат за стъклокерамични плотове','',8,0,0),(145,'Подложка за сервиране','',26,0,0),(146,'Ток','',30,0,0),(147,'Студена вода','',30,0,0),(149,'Топла вода','',30,0,0),(150,'Парно','',30,0,0),(151,'Надежда - наем','',29,0,0),(152,'Люлин - наем','',29,0,0),(153,'Завеси','',27,0,0),(154,'Нож','',26,0,0),(155,'Одеало','',26,0,0),(156,'Кюфтета','',4,197,1),(157,'Сметана','',16,196,1),(158,'Батерии','',26,0,0),(159,'Кайсии','',6,48,1),(161,'Ягоди','',6,32,1),(162,'Прах за пране','',8,0,0),(163,'Препарат за тоалетна','',8,0,0),(164,'Пилешко месо','',4,239,1),(167,'Пъпеш','',6,34,1),(168,'Тоалетна хартия','',14,0,0),(169,'Джин','',7,231,1),(170,'Швепс','',1,45,0),(171,'Разядка','',13,0,0),(172,'Майонеза','',2,680,1),(173,'Моцарела','',2,280,1),(174,'Морети','',3,34,0),(175,'Вода за уста','',9,0,0),(176,'Течен сапун','',8,0,0),(177,'Нектарини','',6,44,1),(178,'Печено пиле','',21,0,0),(179,'Тениска','',25,0,0),(180,'Течност за чистачки','',22,0,0),(181,'Jameson','',7,250,1),(182,'Топла витрина','',21,0,0),(183,'Шоколадов десерт','',15,0,0),(184,'Пипер','',5,20,1),(185,'Праскови','',6,39,1),(186,'Риба','',4,206,1),(187,'Франзела','',10,289,1),(188,'Лютеница','',16,154,1),(190,'Чипс','',13,0,0),(191,'Сок Куинс','',1,47,0),(192,'Профилактика','',31,0,0),(193,'Снимка','',31,0,0),(194,'Коронка','',31,0,0),(195,'3-1','',11,0,0),(196,'Нощувка','',32,0,0),(197,'Боб','',16,142,1),(198,'Сладко','',15,278,1),(199,'Диня','',6,30,1),(200,'Чесън на прах','',16,331,1),(201,'Орехи','',13,607,1),(202,'Картоф','',5,136,0),(203,'Куркума','',20,312,1),(204,'Гролш','',3,34,0),(205,'Пломба','',31,0,0),(206,'Магданоз','',20,36,1),(207,'Люти чушки - консерва','',19,40,1),(208,'Самобръсначка','',9,0,0),(209,'Чорапи','',25,0,0),(210,'Интимен гел','',9,0,0),(211,'Шницел','',4,357,1),(212,'Лайм','',6,30,1),(215,'Дарения','',33,0,0),(216,'Комуникационни услуги','',30,0,0),(217,'Сушени домати','',16,258,1),(218,'Червена леща','',16,358,1),(219,'Галета','',16,395,1),(220,'Ремонт двигател','',22,0,0),(221,'Ремонтни дейности','',27,0,0),(222,'Съмърсби','',3,55,0),(223,'Студен чай','',1,35,0),(224,'Наденица','',4,300,1),(225,'Test for 2024','',5,20,1);
/*!40000 ALTER TABLE `shopping_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_productcategory`
--

DROP TABLE IF EXISTS `shopping_productcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_productcategory` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `main_category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shopping_productcategory_name_665c18a5_uniq` (`name`),
  KEY `shopping_productcate_main_category_id_816bdb5e_fk_shopping_` (`main_category_id`),
  CONSTRAINT `shopping_productcate_main_category_id_816bdb5e_fk_shopping_` FOREIGN KEY (`main_category_id`) REFERENCES `shopping_maincategory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_productcategory`
--

LOCK TABLES `shopping_productcategory` WRITE;
/*!40000 ALTER TABLE `shopping_productcategory` DISABLE KEYS */;
INSERT INTO `shopping_productcategory` VALUES (1,'Безалкохолни напитки',1),(2,'Яйца и Млечни продукти',1),(3,'Бира',1),(4,'Месо',1),(5,'Зеленчуци',1),(6,'Плодове',1),(7,'Алкохол',3),(8,'Почистващи препарати',2),(9,'Козметика',4),(10,'Тестени изделия',1),(11,'Кафе',3),(12,'Цигари',3),(13,'Глезотии',3),(14,'Други',1),(15,'Десерти',1),(16,'Продукти за готвене',1),(17,'Електроуреди',7),(18,'Колбаси',1),(19,'Консерви',1),(20,'Подправки',1),(21,'Храна от ресторант',1),(22,'Автомобил',8),(23,'Лекарства',9),(24,'Вода',1),(25,'Дрехи',10),(26,'Домашни потреби',5),(27,'Домашен ремонт',11),(28,'Градина',11),(29,'Наем',11),(30,'Битови сметки',11),(31,'Зъболекар',9),(32,'Хотел',6),(33,'Дарения',13);
/*!40000 ALTER TABLE `shopping_productcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_recipeshoppinglist`
--

DROP TABLE IF EXISTS `shopping_recipeshoppinglist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_recipeshoppinglist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `recipe_name` varchar(150) NOT NULL,
  `items` json NOT NULL,
  `user_id` bigint NOT NULL,
  `executed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopping_recipeshopp_user_id_0865f9c1_fk_users_cus` (`user_id`),
  CONSTRAINT `shopping_recipeshopp_user_id_0865f9c1_fk_users_cus` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_recipeshoppinglist`
--

LOCK TABLES `shopping_recipeshoppinglist` WRITE;
/*!40000 ALTER TABLE `shopping_recipeshoppinglist` DISABLE KEYS */;
INSERT INTO `shopping_recipeshoppinglist` VALUES (1,'Попска яхния','[\"Брашно\", \"Червен пипер\", \"Доматено пюре\"]',2,1),(2,'Панирана гъба кладница','[\"Брашно\", \"Олио\", \"Сол\"]',2,1),(3,'Салата с киноа и грозде','[\"Киноа\", \"Грозде\", \"Босилек\", \"Олио\"]',2,1),(5,'Крокети с тиквички','[\"Тиквичка\", \"Моркови\", \"Картофи\", \"Яйца\", \"Черен пипер\", \"Магданоз\"]',2,1),(6,'Ливанска салата','[\"Салата\", \"Нар\"]',2,0);
/*!40000 ALTER TABLE `shopping_recipeshoppinglist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_shop`
--

DROP TABLE IF EXISTS `shopping_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_shop` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(75) NOT NULL,
  `utility_supplier` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_shop`
--

LOCK TABLES `shopping_shop` WRITE;
/*!40000 ALTER TABLE `shopping_shop` DISABLE KEYS */;
INSERT INTO `shopping_shop` VALUES (1,'BILLA',0),(2,'Fantastico',0),(3,'LIDL',0),(4,'Бурлекс',0),(5,'Баухаус',0),(6,'ВИА Тракия',0),(7,'Би Си Си Хандел',0),(8,'Доминос',0),(9,'Пепко',0),(10,'Интеркарс',0),(11,'ОМВ',0),(12,'Аптека',0),(13,'DM',0),(14,'Квартален магазин',0),(15,'Ресторант - други',0),(16,'SHELL',0),(17,'Автосервиз Колос',0),(18,'Хазяин Люлин',1),(19,'Хазяин Надежда',1),(20,'IKEA',0),(21,'TERRANOVA',0),(22,'Mr.Bricolage',0),(23,'Класико - В.Търново',0),(24,'Аванти',0),(25,'Kaufland',0),(26,'EO-DENT',0),(27,'Хотел - други',0),(28,'ProMarket',0),(29,'Зъболекар - други',0),(30,'Благоторителност - други',0),(31,'Електрохолд',1),(32,'Софийска вода',1),(33,'Топлофикация - София',1),(34,'Yettel',1),(35,'A1',1),(36,'Енерго Про',1),(37,'Вътрешен разход',0);
/*!40000 ALTER TABLE `shopping_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_shopping`
--

DROP TABLE IF EXISTS `shopping_shopping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_shopping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `shop_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `currency` varchar(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopping_shopping_shop_id_c32893b6_fk_shopping_shop_id` (`shop_id`),
  KEY `shopping_shopping_user_id_ec6ba9ec_fk_users_customuser_id` (`user_id`),
  CONSTRAINT `shopping_shopping_shop_id_c32893b6_fk_shopping_shop_id` FOREIGN KEY (`shop_id`) REFERENCES `shopping_shop` (`id`),
  CONSTRAINT `shopping_shopping_user_id_ec6ba9ec_fk_users_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_shopping`
--

LOCK TABLES `shopping_shopping` WRITE;
/*!40000 ALTER TABLE `shopping_shopping` DISABLE KEYS */;
INSERT INTO `shopping_shopping` VALUES (1,'2025-04-19',2,2,'BGN'),(2,'2025-04-17',2,2,'BGN'),(9,'2025-03-04',2,2,'BGN'),(10,'2025-03-18',2,2,'BGN'),(11,'2025-03-02',4,2,'BGN'),(12,'2025-03-15',5,2,'BGN'),(13,'2025-03-22',1,2,'BGN'),(14,'2025-03-02',6,2,'BGN'),(15,'2025-03-16',7,2,'BGN'),(16,'2025-03-30',1,2,'BGN'),(17,'2025-03-13',2,2,'BGN'),(18,'2025-03-11',8,2,'BGN'),(19,'2025-03-09',2,2,'BGN'),(20,'2025-03-29',1,2,'BGN'),(21,'2025-03-27',2,2,'BGN'),(22,'2025-03-08',1,2,'BGN'),(23,'2025-03-22',9,2,'BGN'),(24,'2025-03-05',2,2,'BGN'),(25,'2025-03-25',10,2,'BGN'),(26,'2025-03-15',11,2,'BGN'),(27,'2025-03-25',12,2,'BGN'),(28,'2025-03-30',1,2,'BGN'),(29,'2025-03-31',13,2,'BGN'),(30,'2025-04-01',8,2,'BGN'),(31,'2025-04-01',14,2,'BGN'),(32,'2025-04-05',14,2,'BGN'),(33,'2025-04-06',14,2,'BGN'),(34,'2025-04-06',1,2,'BGN'),(35,'2025-04-05',11,2,'BGN'),(36,'2025-04-11',14,2,'BGN'),(37,'2025-04-12',1,2,'BGN'),(38,'2025-05-03',2,2,'BGN'),(39,'2025-05-06',1,2,'BGN'),(40,'2025-04-15',8,2,'BGN'),(42,'2025-04-13',14,2,'BGN'),(43,'2025-04-27',15,2,'BGN'),(44,'2025-04-29',14,2,'BGN'),(45,'2025-04-27',2,2,'BGN'),(46,'2025-04-27',3,2,'BGN'),(47,'2025-05-02',2,2,'BGN'),(48,'2025-05-05',14,2,'BGN'),(49,'2025-05-06',9,2,'BGN'),(50,'2025-05-07',14,2,'BGN'),(54,'2025-06-13',3,2,'BGN'),(55,'2025-05-10',1,2,'BGN'),(56,'2025-05-17',1,2,'BGN'),(57,'2025-05-18',14,2,'BGN'),(58,'2025-05-20',11,2,'BGN'),(59,'2025-05-10',1,2,'BGN'),(60,'2025-06-06',16,2,'BGN'),(61,'2025-05-20',11,2,'BGN'),(62,'2025-05-21',14,2,'BGN'),(63,'2025-05-31',5,2,'BGN'),(64,'2025-03-05',18,2,'BGN'),(65,'2025-04-06',18,2,'BGN'),(66,'2025-05-05',18,2,'BGN'),(67,'2025-06-02',18,2,'BGN'),(68,'2025-06-15',14,2,'BGN'),(69,'2025-06-16',14,2,'BGN'),(70,'2025-06-15',20,2,'BGN'),(71,'2025-06-15',20,2,'BGN'),(72,'2025-06-16',2,2,'BGN'),(73,'2025-06-19',14,2,'BGN'),(74,'2025-06-20',14,2,'BGN'),(75,'2025-06-22',2,2,'BGN'),(76,'2025-06-01',1,2,'BGN'),(77,'2025-06-06',15,2,'BGN'),(78,'2025-05-24',1,2,'BGN'),(79,'2025-06-08',1,2,'BGN'),(80,'2025-05-17',2,2,'BGN'),(81,'2025-05-28',2,2,'BGN'),(82,'2025-05-30',14,2,'BGN'),(83,'2025-05-25',11,2,'BGN'),(84,'2025-06-09',14,2,'BGN'),(85,'2025-06-04',3,2,'BGN'),(86,'2025-06-07',2,2,'BGN'),(87,'2025-05-26',2,2,'BGN'),(88,'2025-06-23',14,2,'BGN'),(89,'2025-06-22',11,2,'BGN'),(90,'2025-06-15',21,2,'BGN'),(91,'2025-06-15',22,2,'BGN'),(92,'2025-06-11',24,2,'BGN'),(93,'2025-06-21',23,2,'BGN'),(94,'2025-05-29',2,2,'BGN'),(95,'2025-06-22',1,2,'BGN'),(96,'2025-06-24',24,2,'BGN'),(99,'2025-06-26',26,2,'BGN'),(100,'2025-06-19',26,2,'BGN'),(101,'2025-06-27',14,2,'BGN'),(102,'2025-06-28',14,2,'BGN'),(103,'2025-06-28',15,2,'BGN'),(104,'2025-06-27',27,2,'BGN'),(105,'2025-06-29',14,2,'BGN'),(106,'2025-06-30',28,2,'BGN'),(107,'2025-07-01',12,2,'BGN'),(108,'2025-07-02',14,2,'BGN'),(109,'2025-07-03',14,2,'BGN'),(110,'2025-07-04',4,2,'BGN'),(111,'2025-07-04',14,2,'BGN'),(112,'2025-07-04',29,2,'BGN'),(113,'2025-07-05',1,2,'BGN'),(114,'2025-07-04',18,2,'BGN'),(115,'2025-07-05',19,2,'BGN'),(116,'2025-07-10',14,2,'BGN'),(117,'2025-07-05',14,2,'BGN'),(118,'2025-07-09',4,2,'BGN'),(119,'2025-07-11',14,2,'BGN'),(120,'2025-07-10',15,2,'BGN'),(121,'2025-07-12',14,2,'BGN'),(122,'2025-07-12',3,2,'BGN'),(123,'2025-07-12',30,2,'BGN'),(124,'2025-07-13',3,2,'BGN'),(125,'2025-07-13',14,2,'BGN'),(126,'2025-03-14',35,2,'BGN'),(127,'2025-03-25',35,2,'BGN'),(128,'2025-03-28',35,2,'BGN'),(129,'2025-04-23',35,2,'BGN'),(130,'2025-04-26',35,2,'BGN'),(131,'2025-05-21',35,2,'BGN'),(132,'2025-05-30',35,2,'BGN'),(133,'2025-06-24',35,2,'BGN'),(134,'2025-06-27',35,2,'BGN'),(135,'2025-03-28',31,2,'BGN'),(136,'2025-05-01',31,2,'BGN'),(137,'2025-05-30',31,2,'BGN'),(138,'2025-06-27',31,2,'BGN'),(139,'2025-03-25',32,2,'BGN'),(140,'2025-04-26',32,2,'BGN'),(141,'2025-05-30',32,2,'BGN'),(142,'2025-06-24',32,2,'BGN'),(143,'2025-03-14',33,2,'BGN'),(144,'2025-04-23',33,2,'BGN'),(145,'2025-05-21',33,2,'BGN'),(146,'2025-06-24',33,2,'BGN'),(147,'2025-03-07',19,2,'BGN'),(148,'2025-04-10',19,2,'BGN'),(149,'2025-05-08',19,2,'BGN'),(150,'2025-06-06',19,2,'BGN'),(151,'2025-07-16',14,2,'BGN'),(152,'2025-07-16',4,2,'BGN'),(153,'2025-07-17',34,1,'BGN'),(154,'2025-07-17',34,1,'BGN'),(155,'2025-07-17',33,1,'BGN'),(156,'2025-07-17',11,1,'BGN'),(157,'2025-03-08',32,2,'BGN'),(158,'2025-03-15',33,2,'BGN'),(159,'2025-03-15',35,2,'BGN'),(160,'2025-03-20',36,2,'BGN'),(161,'2025-03-25',31,2,'BGN'),(162,'2025-03-25',32,2,'BGN'),(163,'2025-03-25',33,2,'BGN'),(164,'2025-03-25',31,2,'BGN'),(165,'2025-04-08',32,2,'BGN'),(166,'2025-04-08',32,2,'BGN'),(167,'2025-04-13',35,2,'BGN'),(168,'2025-04-16',33,2,'BGN'),(169,'2025-04-16',36,2,'BGN'),(170,'2025-04-16',33,2,'BGN'),(171,'2025-04-24',31,2,'BGN'),(172,'2025-04-24',31,2,'BGN'),(173,'2025-05-04',32,2,'BGN'),(174,'2025-05-14',35,2,'BGN'),(175,'2025-05-14',32,2,'BGN'),(176,'2025-05-20',33,2,'BGN'),(177,'2025-05-20',33,2,'BGN'),(178,'2025-05-20',36,2,'BGN'),(179,'2025-05-20',33,2,'BGN'),(180,'2025-05-22',31,2,'BGN'),(181,'2025-05-22',31,2,'BGN'),(182,'2025-06-10',32,2,'BGN'),(183,'2025-06-10',32,2,'BGN'),(184,'2025-06-11',35,2,'BGN'),(185,'2025-06-16',36,2,'BGN'),(186,'2025-06-16',33,2,'BGN'),(187,'2025-06-16',33,2,'BGN'),(188,'2025-06-29',32,2,'BGN'),(189,'2025-07-04',31,2,'BGN'),(190,'2025-07-04',31,2,'BGN'),(191,'2025-07-04',32,2,'BGN'),(192,'2025-07-11',35,2,'BGN'),(193,'2025-05-02',17,1,'BGN'),(194,'2025-07-14',37,1,'BGN'),(195,'2025-07-18',23,2,'BGN'),(196,'2025-07-18',14,1,'BGN'),(197,'2025-07-20',7,2,'BGN'),(198,'2025-07-21',20,2,'BGN'),(199,'2025-07-20',14,1,'BGN'),(200,'2025-07-21',33,1,'BGN'),(201,'2025-07-21',36,1,'BGN'),(202,'2025-07-21',33,1,'BGN'),(203,'2025-07-20',23,2,'BGN'),(204,'2025-07-22',2,1,'BGN'),(205,'2025-07-23',32,1,'BGN'),(206,'2025-07-23',35,1,'BGN'),(207,'2025-07-24',15,1,'BGN'),(208,'2025-07-25',2,1,'BGN'),(209,'2024-03-05',1,1,'EUR'),(210,'2024-04-09',1,1,'EUR'),(211,'2024-05-07',1,1,'EUR'),(212,'2024-06-04',1,1,'EUR'),(213,'2024-07-09',1,1,'EUR'),(214,'2024-08-13',1,1,'EUR');
/*!40000 ALTER TABLE `shopping_shopping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_shoppinglist`
--

DROP TABLE IF EXISTS `shopping_shoppinglist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_shoppinglist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date_generated` date NOT NULL,
  `executed` tinyint(1) NOT NULL,
  `items` json NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopping_shoppinglist_user_id_663a08ef_fk_users_customuser_id` (`user_id`),
  CONSTRAINT `shopping_shoppinglist_user_id_663a08ef_fk_users_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_shoppinglist`
--

LOCK TABLES `shopping_shoppinglist` WRITE;
/*!40000 ALTER TABLE `shopping_shoppinglist` DISABLE KEYS */;
INSERT INTO `shopping_shoppinglist` VALUES (1,'2025-05-29',0,'[\"test1\"]',1),(2,'2025-05-29',0,'[\"Бира\", \"Ябълки\"]',1),(3,'2025-05-31',0,'[\"Бира\", \"test product 2\"]',1),(4,'2025-05-31',1,'[]',1),(5,'2025-05-31',0,'[\"test1\", \"test2\"]',1),(6,'2025-06-02',1,'[\"Плодове\", \"Колбаси\", \"Бакарди\", \"шампоан\", \"Сапун\", \"Боя за коса\", \"Паста за зъби\", \"Спагети\", \"Козунак\", \"Heets\", \"Брашно\", \"Оцет\", \"Фиде\", \"Сол\", \"Босилек\", \"Пица\"]',2),(9,'2025-07-04',1,'[\"Колбаси\", \"Бакарди\", \"Веро\", \"шампоан\", \"Сапун\", \"Боя за коса\", \"Паста за зъби\", \"Вода за уста\", \"Кроасан\", \"Heets\", \"Тереа Ръсет\", \"Тереа Тийк\", \"Дъвки\", \"Брашно\", \"Оцет\", \"Фиде\", \"Босилек\"]',2),(10,'2025-07-05',1,'[\"Краве мляко\", \"Яйца\", \"Фр. сирена\", \"Крема сирене\", \"Кисело мляко\", \"Майонеза\", \"Captain Morgan\", \"Спагети\", \"Бисквити/солети\", \"Кроасан\", \"Тереа Ръсет\", \"Люти чушки\", \"Дъвки\", \"Брашно\", \"Захар\", \"Сол\", \"Босилек\", \"Бира\", \"Самобръсначка\", \"Интимен гел\", \"Безалкохолно\", \"Диня\"]',2),(11,'2025-07-12',1,'[\"Безалкохолни напитки\", \"Бира\", \"Кафе\", \"Колбаси\", \"Краве мляко\", \"Кисело мляко\", \"Спагети\", \"Бисквити/солети\", \"Хляб\", \"Кроасан\", \"Дъвки\", \"Свинско месо\", \"Сирене\", \"Лук\", \"Чушки\", \"Банани\", \"Олио\", \"Яйца\", \"Кока кола\", \"Шуменско\", \"Лаваца\"]',2),(12,'2025-07-16',1,'[\"Бира\", \"Краве мляко\", \"Фр. сирена\", \"Крема сирене\", \"Кисело мляко\", \"Майонеза\", \"шампоан\", \"Боя за коса\", \"Паста за зъби\", \"Спагети\", \"Тереа Ръсет\", \"Фъстъци\", \"Люти чушки - зелени\", \"Дъвки\", \"Семки\", \"Брашно\", \"Захар\", \"Босилек\", \"Бисквити/солети\", \"Гролш\"]',2);
/*!40000 ALTER TABLE `shopping_shoppinglist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_shoppingproduct`
--

DROP TABLE IF EXISTS `shopping_shoppingproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopping_shoppingproduct` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` decimal(10,3) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `product_id` bigint NOT NULL,
  `shopping_id` bigint NOT NULL,
  `not_for_household` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopping_shoppingpro_product_id_6af34500_fk_shopping_` (`product_id`),
  KEY `shopping_shoppingpro_shopping_id_bebd1445_fk_shopping_` (`shopping_id`),
  CONSTRAINT `shopping_shoppingpro_product_id_6af34500_fk_shopping_` FOREIGN KEY (`product_id`) REFERENCES `shopping_product` (`id`),
  CONSTRAINT `shopping_shoppingpro_shopping_id_bebd1445_fk_shopping_` FOREIGN KEY (`shopping_id`) REFERENCES `shopping_shopping` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=835 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_shoppingproduct`
--

LOCK TABLES `shopping_shoppingproduct` WRITE;
/*!40000 ALTER TABLE `shopping_shoppingproduct` DISABLE KEYS */;
INSERT INTO `shopping_shoppingproduct` VALUES (1,3.000,7.33,0.00,21.99,16,1,0),(2,1.000,6.99,0.00,6.99,46,1,0),(3,20.000,0.48,0.00,9.60,103,1,0),(4,3.126,24.90,0.00,77.84,109,1,0),(5,1.000,1.49,0.00,1.49,19,1,0),(6,1.000,0.59,0.00,0.59,11,1,0),(7,0.024,74.58,0.00,1.79,110,1,0),(8,1.000,1.79,0.00,1.79,111,1,0),(9,1.000,2.45,0.00,2.45,12,1,0),(10,1.000,1.99,0.00,1.99,27,1,0),(11,1.000,5.45,0.00,5.45,112,1,0),(12,0.300,5.97,0.00,1.79,69,1,0),(13,0.150,9.93,0.00,1.49,113,1,0),(14,1.000,2.09,0.00,2.09,17,1,0),(15,2.000,6.20,0.00,12.40,23,1,0),(16,3.000,6.20,0.00,18.60,21,1,0),(17,0.200,27.40,0.00,5.48,114,1,0),(18,1.000,1.29,0.00,1.29,115,2,0),(19,0.352,4.99,0.00,1.76,80,2,0),(20,1.000,1.49,0.00,1.49,20,2,0),(21,3.000,1.59,0.00,4.77,44,2,0),(22,6.000,1.49,0.00,8.94,62,2,0),(23,0.400,29.97,0.00,11.99,47,2,0),(24,1.000,3.29,0.00,3.29,49,2,0),(25,1.000,1.49,0.00,1.49,12,2,0),(26,10.000,6.20,6.20,55.80,21,9,0),(27,1.000,4.49,0.00,4.49,22,9,0),(28,2.000,2.39,0.00,4.78,19,9,0),(29,1.000,1.18,0.00,1.18,18,9,0),(30,2.000,6.20,0.00,12.40,23,9,0),(31,1.000,2.45,0.00,2.45,12,10,0),(32,1.000,1.99,0.00,1.99,17,10,0),(33,1.000,3.88,0.00,3.88,18,10,0),(34,3.000,1.19,0.00,3.57,15,10,0),(35,1.000,2.99,0.00,2.99,19,10,0),(36,10.000,6.20,0.00,62.00,21,10,0),(37,2.000,1.49,0.00,2.98,20,10,0),(38,1.000,3.59,0.00,3.59,24,11,0),(39,1.000,18.99,0.00,18.99,25,11,0),(40,1.198,2.89,0.00,3.46,26,11,0),(41,0.736,3.89,0.00,2.86,9,11,0),(42,1.000,1.69,0.00,1.69,27,11,0),(43,1.000,3.99,0.00,3.99,28,11,0),(44,1.000,2.19,0.00,2.19,12,11,0),(45,0.426,1.89,0.00,0.81,10,11,0),(46,1.000,6.20,0.00,6.20,23,11,0),(47,2.000,14.90,0.00,29.80,29,12,0),(48,1.000,14.80,0.00,14.80,30,12,0),(49,12.000,1.49,4.48,13.40,31,13,0),(50,2.000,3.19,1.00,5.38,32,13,0),(51,1.000,6.29,1.57,4.72,33,13,0),(52,10.000,0.65,0.00,6.50,103,13,0),(53,1.000,9.39,2.20,7.19,22,13,0),(54,1.000,2.27,0.00,2.27,12,13,0),(55,0.538,1.59,0.17,0.69,11,13,0),(56,0.504,5.99,0.25,2.77,6,13,0),(57,2.064,15.99,15.48,17.52,5,13,0),(58,0.250,13.99,0.88,2.62,8,13,0),(59,0.379,27.99,4.17,6.44,34,13,0),(60,5.000,2.15,2.80,7.95,15,13,0),(61,1.000,5.99,0.00,5.99,35,13,0),(62,1.000,3.49,0.70,2.79,35,13,0),(63,1.000,4.29,1.07,3.22,36,13,0),(64,1.000,6.49,0.00,6.49,37,13,0),(65,1.000,1.19,0.00,1.19,18,13,0),(66,1.000,1.99,0.00,1.99,13,13,0),(67,1.000,2.99,0.00,2.99,38,13,0),(68,4.000,1.75,1.75,5.25,39,13,0),(69,1.000,26.99,5.50,21.49,16,13,0),(70,1.000,3.49,0.00,3.49,40,14,0),(71,1.000,5.69,0.00,5.69,18,14,0),(72,2.000,3.39,0.00,6.78,13,14,0),(73,1.000,1.69,0.00,1.69,41,14,0),(74,1.000,10.49,0.00,10.49,42,14,0),(75,1.000,6.39,0.00,6.39,43,14,0),(76,1.000,2.05,0.00,2.05,44,15,0),(77,2.000,1.35,0.00,2.70,44,15,0),(78,0.176,45.00,0.00,7.92,45,15,0),(79,0.276,40.30,0.00,11.12,45,15,0),(80,0.196,20.00,0.00,3.92,34,15,0),(81,0.326,21.15,0.00,6.89,46,15,0),(82,0.960,12.55,0.00,12.05,47,15,0),(83,12.000,1.50,5.00,13.00,48,16,0),(84,1.000,3.99,0.00,3.99,28,16,0),(85,1.000,26.99,5.50,21.49,16,16,0),(86,1.000,3.69,0.00,3.69,49,16,0),(87,1.000,10.99,4.10,6.89,14,16,0),(88,1.000,4.29,0.00,4.29,18,16,0),(89,1.000,4.69,1.80,2.89,50,16,0),(90,5.000,1.39,1.50,5.45,15,16,0),(91,1.000,4.19,0.00,4.19,51,16,0),(92,6.000,2.29,6.24,7.50,52,16,0),(93,1.000,3.19,0.64,2.55,32,16,0),(94,2.000,3.85,2.00,5.70,24,16,0),(95,1.254,12.49,8.15,7.51,5,16,0),(96,1.000,3.59,1.10,2.49,53,16,0),(97,0.329,46.99,5.59,9.87,45,16,0),(98,0.748,5.99,1.50,2.98,6,16,0),(99,0.500,10.00,1.00,4.00,7,16,0),(100,1.000,1.69,0.00,1.69,54,16,0),(101,0.433,16.99,2.60,4.76,47,16,0),(102,0.390,1.99,0.00,0.78,10,16,0),(103,1.000,0.56,0.00,0.56,55,16,0),(104,1.000,3.69,0.00,3.69,52,16,0),(105,1.000,2.69,0.00,2.69,24,17,0),(106,1.000,3.29,0.00,3.29,32,17,0),(107,1.000,5.25,0.00,5.25,28,17,0),(108,2.000,1.98,0.00,3.96,18,17,0),(109,1.000,1.49,0.00,1.49,20,17,0),(110,1.000,2.45,0.00,2.45,12,17,0),(111,1.000,8.99,0.00,8.99,56,17,0),(112,2.000,19.90,19.89,19.91,57,18,0),(113,1.000,1.59,0.00,1.59,58,19,0),(114,1.000,1.85,0.00,1.85,44,19,0),(115,1.000,3.69,0.00,3.69,40,19,0),(116,1.000,2.27,0.00,2.27,12,20,0),(117,1.000,1.09,0.00,1.09,27,20,0),(118,0.424,3.49,0.00,1.48,59,20,0),(119,0.596,3.99,0.60,1.78,60,20,0),(120,1.000,3.49,0.00,3.49,61,20,0),(121,1.000,1.29,0.00,1.29,20,21,0),(122,6.000,1.49,0.00,8.94,62,21,0),(123,10.000,6.20,0.00,62.00,21,21,0),(124,1.000,3.19,0.96,2.23,1,22,0),(125,1.000,33.99,4.00,29.99,2,22,0),(126,10.000,1.58,4.70,11.10,3,22,0),(127,2.000,11.50,7.00,16.00,63,22,0),(128,1.000,3.69,0.70,2.99,49,22,0),(129,1.000,1.95,0.46,1.49,44,22,0),(130,1.000,3.99,1.20,2.79,64,22,0),(131,1.466,15.99,10.99,12.45,5,22,0),(132,1.000,4.99,2.30,2.69,6,22,0),(133,0.500,10.00,1.00,4.00,7,22,0),(134,0.284,14.99,1.71,2.55,8,22,0),(135,1.000,3.69,0.00,3.69,13,22,0),(136,1.000,10.99,4.10,6.89,14,22,0),(137,1.000,8.39,2.10,6.29,14,22,0),(138,0.508,3.49,0.35,1.42,9,22,0),(139,0.554,1.99,0.00,1.10,10,22,0),(140,0.362,1.59,0.08,0.50,11,22,0),(141,1.000,2.27,0.00,2.27,12,22,0),(142,3.000,1.19,0.60,2.97,15,22,0),(143,1.000,19.49,4.87,14.62,16,22,0),(144,0.269,47.69,6.41,6.42,45,22,0),(145,1.000,35.00,0.00,35.00,38,23,0),(146,2.000,1.15,0.00,2.30,31,24,0),(147,2.000,1.49,0.00,2.98,65,24,0),(148,1.000,3.99,0.00,3.99,45,24,0),(149,1.000,4.19,0.00,4.19,65,24,0),(150,1.000,4.99,0.00,4.99,18,24,0),(151,0.400,29.98,0.00,11.99,47,24,0),(152,1.000,12.44,0.00,12.44,66,25,0),(153,39.470,2.55,0.00,100.65,67,26,0),(154,1.000,62.14,0.00,62.14,68,27,0),(155,1.000,31.00,0.00,31.00,68,27,0),(156,5.000,6.20,0.00,31.00,23,28,0),(157,1.000,9.56,0.00,9.56,73,29,0),(158,2.000,19.90,19.89,19.91,57,30,0),(159,10.000,6.11,0.00,61.10,21,31,0),(160,1.000,2.30,0.00,2.30,12,32,0),(161,10.000,6.11,0.00,61.10,21,33,0),(162,10.000,6.11,0.00,61.10,23,33,0),(163,1.000,23.99,6.00,17.99,16,34,0),(164,1.000,1.69,0.00,1.69,38,34,0),(165,0.500,4.00,0.00,2.00,17,34,0),(166,1.000,2.79,0.00,2.79,77,34,0),(167,2.000,0.95,0.00,1.90,86,34,0),(168,0.400,10.73,0.00,4.29,28,34,0),(169,9.000,1.79,6.30,9.81,31,34,0),(170,1.000,4.09,0.00,4.09,18,34,0),(171,10.000,0.49,1.25,3.65,103,34,0),(172,0.200,19.95,1.50,2.49,19,34,0),(173,0.400,12.48,0.50,4.49,69,34,0),(174,0.500,4.00,0.00,2.00,87,34,0),(175,1.000,2.27,0.00,2.27,12,34,0),(176,2.000,2.59,1.20,3.98,88,34,0),(177,0.349,14.99,2.79,2.44,8,34,0),(178,0.050,17.00,0.00,0.85,89,34,0),(179,0.070,8.00,0.00,0.56,79,34,0),(180,1.000,3.79,0.30,3.49,50,34,0),(181,1.400,8.56,2.00,9.98,5,34,0),(182,5.000,1.59,2.00,5.95,15,34,0),(183,3.000,1.00,0.00,3.00,83,34,0),(184,0.200,39.95,2.30,5.69,90,34,0),(185,0.548,3.99,0.00,2.19,60,34,0),(186,0.600,2.69,0.42,1.19,26,34,0),(187,0.250,15.96,0.50,3.49,84,34,0),(188,0.250,11.96,0.70,2.29,6,34,0),(189,47.390,2.55,0.00,120.84,67,35,0),(190,0.300,4.50,0.00,1.35,6,36,0),(191,0.400,3.00,0.00,1.20,26,36,0),(192,0.200,4.00,0.00,0.80,92,36,0),(193,0.100,18.00,0.00,1.80,93,36,0),(194,0.200,2.50,0.00,0.50,11,36,0),(195,2.000,1.50,0.00,3.00,94,36,0),(196,14.000,1.75,10.64,13.86,106,37,0),(197,1.000,3.19,1.00,2.19,1,37,0),(198,2.500,0.70,0.00,1.75,39,37,0),(199,0.562,36.99,4.16,16.63,45,37,0),(200,1.000,6.09,1.10,4.99,99,37,0),(201,0.840,3.99,0.84,2.51,26,37,0),(202,0.440,10.20,1.35,3.14,104,37,0),(203,0.500,5.98,0.60,2.39,101,37,0),(204,0.862,4.99,1.72,2.58,95,37,0),(205,0.450,4.42,0.00,1.99,96,37,0),(206,1.000,3.85,0.00,3.85,97,37,0),(207,2.000,2.99,2.40,3.58,107,37,0),(208,0.306,14.99,1.53,3.06,8,37,0),(209,1.000,3.99,0.00,3.99,28,37,0),(210,1.000,4.69,0.70,3.99,107,37,0),(211,10.000,0.55,0.00,5.50,103,37,0),(212,1.000,4.09,0.00,4.09,18,37,0),(213,1.000,2.19,0.00,2.19,12,37,0),(214,1.008,5.99,0.00,6.04,100,37,0),(215,0.284,35.69,2.19,7.95,35,37,0),(216,0.164,10.99,0.00,1.80,98,37,0),(217,1.000,9.99,2.50,7.49,108,37,0),(218,0.268,7.99,0.00,2.14,81,37,0),(219,0.448,5.49,0.67,1.79,105,37,0),(220,1.000,1.89,0.00,1.89,12,38,0),(221,1.000,1.29,0.00,1.29,19,38,0),(222,12.000,1.15,0.00,13.80,3,38,0),(223,3.000,7.33,0.00,21.99,16,38,0),(224,1.000,4.29,0.00,4.29,28,38,0),(225,0.440,2.49,0.00,1.10,80,38,0),(226,1.000,1.79,0.00,1.79,113,38,0),(227,1.000,0.59,0.00,0.59,94,38,0),(228,0.974,12.99,0.00,12.65,7,38,0),(229,0.190,17.84,0.00,3.39,35,38,0),(230,1.000,3.79,0.00,3.79,49,38,0),(231,1.000,1.49,0.00,1.49,20,38,0),(232,1.000,4.29,0.00,4.29,18,39,0),(233,1.000,2.19,0.00,2.19,12,39,0),(234,1.000,3.39,1.40,1.99,49,39,0),(235,0.116,9.99,0.35,0.81,74,39,0),(236,0.500,17.98,5.00,3.99,116,39,0),(237,3.000,1.59,0.00,4.77,15,39,0),(238,2.000,18.90,8.95,28.85,57,40,0),(239,10.000,6.11,0.00,61.10,21,42,0),(240,1.000,1.60,0.00,1.60,18,42,0),(241,1.000,20.70,0.00,20.70,117,43,0),(242,11.000,6.11,0.00,67.21,21,44,0),(243,0.842,3.79,0.00,3.19,6,45,0),(244,2.500,1.80,0.00,4.50,100,45,0),(245,1.000,4.39,0.00,4.39,18,45,0),(246,0.200,19.95,0.00,3.99,93,45,0),(247,0.552,4.79,1.21,1.43,95,46,0),(248,0.314,4.49,0.63,0.78,80,46,0),(249,11.000,0.32,0.00,3.52,39,46,0),(250,12.000,0.79,0.00,9.48,118,46,0),(251,1.000,1.89,0.00,1.89,12,46,0),(252,2.000,1.09,0.00,2.18,39,46,0),(253,5.000,1.59,0.00,7.95,15,46,0),(254,1.000,6.85,0.00,6.85,14,46,0),(255,0.500,17.98,0.00,8.99,47,46,0),(256,1.000,2.69,0.00,2.69,44,46,0),(257,2.000,2.50,0.00,5.00,32,46,0),(258,0.250,15.56,0.00,3.89,104,46,0),(259,1.500,26.00,0.00,39.00,63,46,0),(260,1.000,4.99,0.00,4.99,119,46,0),(261,0.340,2.89,0.00,0.98,105,46,0),(262,0.782,2.79,0.00,2.18,26,46,0),(263,0.482,0.79,0.00,0.38,10,46,0),(264,1.000,2.39,0.00,2.39,27,46,0),(265,0.958,9.99,0.00,9.57,5,47,0),(266,1.000,2.59,0.00,2.59,77,47,0),(267,1.000,1.39,0.00,1.39,74,47,0),(268,1.000,0.59,0.00,0.59,94,47,0),(269,0.200,14.95,0.00,2.99,92,47,0),(270,1.000,1.29,0.00,1.29,27,47,0),(271,0.266,5.69,0.00,1.51,80,47,0),(272,0.508,2.59,0.00,1.32,95,47,0),(273,1.000,4.99,0.00,4.99,120,47,0),(274,1.000,11.99,0.00,11.99,121,47,0),(275,1.000,0.99,0.00,0.99,122,47,0),(276,2.000,1.99,0.00,3.98,123,48,0),(277,1.000,6.20,0.00,6.20,21,48,0),(278,1.000,4.50,0.00,4.50,124,49,0),(279,2.000,5.75,0.00,11.50,125,49,0),(280,10.000,6.11,0.00,61.10,21,50,0),(281,10.000,6.11,0.00,61.10,126,50,0),(291,2.000,3.99,2.00,5.98,38,54,0),(292,1.000,4.99,1.00,3.99,35,54,0),(293,1.000,5.99,0.00,5.99,38,54,0),(294,0.250,10.00,0.00,2.50,84,54,0),(295,2.000,0.89,0.00,1.78,15,54,0),(296,1.000,2.75,0.00,2.75,12,54,0),(297,0.768,1.99,0.00,1.53,10,55,0),(298,0.678,3.99,1.16,1.55,80,55,0),(299,0.732,7.99,2.20,3.65,132,55,0),(300,0.494,1.99,0.00,0.98,11,55,0),(301,1.000,1.29,0.00,1.29,94,55,0),(302,1.250,2.49,1.50,1.61,100,55,0),(303,0.660,4.99,0.66,2.63,6,55,0),(304,0.888,3.99,1.06,2.48,26,55,0),(305,1.000,2.49,0.00,2.49,61,55,0),(306,1.000,3.99,0.80,3.19,44,55,0),(307,0.500,15.98,2.50,5.49,90,55,0),(308,0.450,26.64,0.00,11.99,47,55,0),(309,1.000,3.69,0.00,3.69,49,55,0),(310,0.500,5.98,0.70,2.29,76,55,0),(311,5.000,1.59,2.00,5.95,15,55,0),(312,0.299,12.99,1.49,2.39,8,55,0),(313,1.000,4.29,0.00,4.29,18,55,0),(314,2.000,0.95,0.00,1.90,86,55,0),(315,1.000,3.19,0.00,3.19,32,56,0),(316,3.000,7.13,2.00,19.39,16,56,0),(317,0.554,3.99,0.83,1.38,80,56,0),(318,0.788,3.99,1.02,2.12,26,56,0),(319,1.000,1.29,0.40,0.89,94,56,0),(320,0.606,4.99,0.12,2.90,6,56,0),(321,5.000,1.39,0.00,6.95,15,56,0),(322,0.358,1.99,0.28,0.43,11,56,0),(323,1.000,2.19,0.00,2.19,12,56,0),(324,1.000,30.49,0.00,30.49,133,56,0),(325,6.000,1.49,3.96,4.98,31,56,0),(326,1.000,9.35,0.00,9.35,22,56,0),(327,1.000,9.99,3.00,6.99,44,56,0),(328,1.000,4.29,0.00,4.29,18,56,0),(329,0.294,9.99,0.88,2.06,134,56,0),(330,1.000,4.99,1.50,3.49,49,56,0),(331,0.125,23.92,0.00,2.99,135,56,0),(332,1.062,3.59,1.70,2.11,136,56,0),(333,1.000,6.69,0.00,6.69,37,56,0),(334,3.000,6.20,0.00,18.60,21,57,0),(335,1.000,2.90,0.00,2.90,32,57,0),(336,2.000,6.20,0.00,12.40,21,58,0),(337,3.000,7.13,2.00,19.39,16,59,0),(338,1.000,14.99,0.00,14.99,123,59,0),(339,1.000,3.99,0.00,3.99,137,59,0),(340,1.386,12.49,8.31,9.00,5,59,0),(341,10.000,0.53,0.00,5.30,103,59,0),(342,1.000,2.19,0.00,2.19,12,59,0),(343,1.000,8.79,3.80,4.99,46,59,0),(344,0.190,21.49,0.85,3.23,35,59,0),(345,0.456,52.99,8.66,15.50,45,59,0),(346,10.000,1.65,6.00,10.50,48,59,0),(347,47.830,2.39,0.00,114.31,67,60,0),(348,46.720,2.47,0.00,115.40,67,61,0),(349,10.000,6.11,0.00,61.10,21,62,0),(350,10.000,6.11,0.00,61.10,126,62,0),(351,1.000,0.95,0.00,0.95,138,63,0),(352,1.000,9.95,0.00,9.95,139,63,0),(353,1.000,10.50,0.00,10.50,140,63,0),(354,1.000,2.95,0.00,2.95,141,63,0),(355,1.000,9.70,0.00,9.70,142,63,0),(356,1.000,15.95,0.00,15.95,143,63,0),(357,1.000,18.00,0.00,18.00,144,63,0),(358,2.000,4.45,0.00,8.90,145,63,0),(359,1.000,13.70,0.00,13.70,140,63,0),(360,1.000,650.00,0.00,650.00,152,64,1),(361,1.000,700.00,0.00,700.00,152,65,1),(362,1.000,700.00,0.00,700.00,152,66,1),(363,1.000,700.00,0.00,700.00,152,67,1),(364,10.000,6.11,0.00,61.10,21,68,0),(365,0.450,3.00,0.00,1.35,6,69,0),(366,0.300,2.30,0.00,0.69,80,69,0),(367,1.000,3.00,0.00,3.00,100,69,0),(368,1.000,69.90,0.00,69.90,153,70,0),(369,2.000,19.99,0.00,39.98,153,70,0),(370,1.000,5.99,0.00,5.99,154,70,0),(371,2.000,2.99,0.00,5.98,145,70,0),(372,1.000,12.99,0.00,12.99,155,70,0),(373,2.000,4.90,0.00,9.80,38,70,0),(374,2.000,2.95,0.00,5.90,65,71,0),(375,2.000,24.95,0.00,49.90,156,71,0),(376,2.000,11.95,0.00,23.90,18,71,0),(377,1.000,1.99,0.00,1.99,1,72,0),(378,3.000,5.33,0.00,15.99,16,72,0),(379,9.000,1.09,0.00,9.81,31,72,0),(380,1.000,1.69,0.00,1.69,122,72,0),(381,0.400,11.97,0.00,4.79,47,72,0),(382,2.000,1.49,0.00,2.98,20,72,0),(383,0.200,8.95,0.00,1.79,157,72,0),(384,1.000,2.99,0.00,2.99,158,72,0),(385,0.496,4.99,0.00,2.48,159,72,0),(386,0.600,2.99,0.00,1.79,81,72,0),(387,0.558,5.99,0.00,3.34,161,72,0),(388,4.000,1.39,0.00,5.56,15,72,0),(389,2.500,2.00,0.00,5.00,100,73,0),(390,1.000,3.60,0.00,3.60,87,74,0),(391,3.000,6.20,0.00,18.60,21,74,0),(392,2.000,6.20,0.00,12.40,126,74,0),(393,1.000,3.70,0.00,3.70,32,74,0),(394,12.000,1.15,0.00,13.80,48,75,0),(395,5.000,1.39,0.00,6.95,15,75,0),(396,1.000,2.59,0.00,2.59,12,75,0),(397,5.000,0.71,0.89,2.66,39,76,0),(398,3.000,7.13,5.40,15.99,16,76,0),(399,1.000,3.99,0.00,3.99,44,76,0),(400,1.000,3.19,1.20,1.99,1,76,0),(401,1.000,10.99,4.14,6.85,14,76,0),(402,0.500,3.98,0.30,1.69,17,76,0),(403,35.000,0.96,12.70,20.90,162,76,0),(404,0.243,25.99,2.19,4.13,34,76,0),(405,0.750,5.72,1.30,2.99,163,76,0),(406,2.000,4.29,0.00,8.58,18,76,0),(407,1.934,6.99,3.87,9.65,164,76,0),(408,6.000,1.59,0.00,9.54,15,76,0),(409,0.250,19.96,1.50,3.49,116,76,0),(410,0.592,3.99,0.59,1.77,80,76,0),(411,0.200,64.95,3.00,9.99,45,76,0),(412,9.000,1.79,6.30,9.81,31,76,0),(413,0.824,2.99,0.57,1.89,26,76,0),(414,1.442,3.99,1.44,4.31,167,76,0),(415,1.060,2.49,1.17,1.47,100,76,0),(416,0.820,4.49,0.65,3.03,6,76,0),(417,16.000,0.88,0.09,13.99,168,76,0),(418,1.000,19.60,0.00,19.60,117,77,0),(419,1.000,35.99,0.00,35.99,169,78,0),(420,1.000,3.19,0.00,3.19,32,78,0),(421,1.000,2.59,0.00,2.59,12,78,0),(422,1.000,2.79,0.56,2.23,170,78,0),(423,0.702,2.99,0.70,1.40,26,78,0),(424,1.000,3.89,1.60,2.29,53,78,0),(425,1.000,4.09,0.00,4.09,28,78,0),(426,0.173,31.99,1.73,3.80,35,78,0),(427,1.000,1.99,0.50,1.49,61,78,0),(428,0.367,16.99,1.66,4.58,171,78,0),(429,0.500,4.10,0.76,1.29,44,78,0),(430,0.321,29.99,2.25,7.38,35,78,0),(431,0.600,17.99,2.88,7.91,8,78,0),(432,0.846,3.99,1.70,1.68,80,78,0),(433,0.630,48.39,11.60,18.89,45,78,0),(434,0.768,1.99,0.00,1.53,10,78,0),(435,1.000,15.99,3.20,12.79,47,78,0),(436,1.000,7.29,2.30,4.99,172,78,0),(437,0.500,8.98,0.00,4.49,7,78,0),(438,1.100,4.99,0.55,4.94,6,78,0),(439,1.000,3.29,0.00,3.29,173,78,0),(440,8.000,2.00,6.40,9.60,174,78,0),(441,1.456,5.99,2.91,5.81,167,78,0),(442,1.000,15.99,0.00,15.99,56,78,0),(443,0.762,15.99,5.33,6.85,5,78,0),(444,0.790,15.99,5.53,7.10,5,78,0),(445,1.000,3.19,0.96,2.23,1,79,0),(446,1.000,13.49,2.70,10.79,175,79,0),(447,0.376,22.49,3.58,4.88,47,79,0),(448,11.000,0.51,1.62,3.99,39,79,0),(449,0.259,14.99,1.29,2.59,8,79,0),(450,1.314,12.49,8.01,8.40,5,79,0),(451,10.000,0.60,0.00,6.00,103,79,0),(452,1.000,8.99,0.00,8.99,65,79,0),(453,1.000,3.39,0.00,3.39,24,79,0),(454,4.000,1.65,2.80,3.80,48,79,0),(455,1.000,2.59,1.60,0.99,88,79,0),(456,3.000,6.77,7.80,12.51,16,79,0),(457,1.000,4.99,1.00,3.99,28,79,0),(458,1.000,4.69,0.94,3.75,28,79,0),(459,0.512,50.49,10.50,15.35,45,79,0),(460,1.000,2.19,0.00,2.19,12,79,0),(462,1.122,5.49,0.00,6.16,177,79,0),(463,5.000,1.39,1.50,5.45,15,79,0),(464,0.848,4.49,0.17,3.64,6,79,0),(465,6.000,1.08,0.00,6.48,3,80,0),(466,1.000,2.45,0.00,2.45,12,80,0),(467,1.000,3.99,0.00,3.99,44,80,0),(468,0.400,29.97,0.00,11.99,47,80,0),(469,10.000,0.50,0.00,5.00,103,80,0),(470,2.000,6.20,0.00,12.40,21,80,0),(471,4.000,6.20,0.00,24.80,21,81,0),(472,10.000,6.11,0.00,61.10,21,82,0),(473,1.000,6.20,0.00,6.20,21,83,0),(474,0.250,11.16,0.00,2.79,32,83,0),(475,1.000,3.00,0.00,3.00,32,84,0),(476,1.000,2.60,0.00,2.60,12,84,0),(477,1.000,2.70,0.00,2.70,17,84,0),(478,6.000,0.83,0.00,4.98,31,85,0),(479,1.000,9.99,0.00,9.99,14,85,0),(480,2.000,2.19,0.00,4.38,123,85,0),(482,1.000,2.75,0.00,2.75,12,85,0),(483,2.000,6.20,0.00,12.40,21,85,0),(484,0.118,20.80,0.00,2.45,35,86,0),(485,1.000,6.19,0.00,6.19,123,86,0),(486,1.000,1.85,0.00,1.85,64,86,0),(487,1.000,1.99,0.00,1.99,27,86,0),(488,0.626,1.99,0.00,1.25,80,86,0),(489,1.000,1.49,0.00,1.49,20,86,0),(490,1.000,2.99,0.00,2.99,158,86,0),(491,3.000,6.20,0.00,18.60,21,86,0),(492,1.000,3.29,0.00,3.29,32,87,0),(493,1.000,2.49,0.00,2.49,24,87,0),(494,2.500,1.80,0.00,4.50,100,87,0),(495,1.000,2.59,0.00,2.59,141,87,0),(496,1.000,4.49,0.00,4.49,123,87,0),(497,6.000,0.58,0.00,3.48,103,87,0),(498,1.000,2.45,0.00,2.45,12,87,0),(499,0.314,2.99,0.00,0.94,80,87,0),(500,0.472,4.69,0.00,2.21,6,87,0),(501,0.496,2.99,0.00,1.48,26,87,0),(502,1.000,1.29,0.00,1.29,20,87,0),(503,1.000,9.99,0.00,9.99,178,87,0),(504,1.000,2.49,0.00,2.49,17,87,0),(505,4.000,6.20,0.00,24.80,21,88,0),(506,2.000,6.20,0.00,12.40,126,88,0),(507,0.500,3.58,0.00,1.79,39,89,0),(508,1.000,2.59,0.00,2.59,123,89,0),(509,1.000,2.29,0.00,2.29,123,89,0),(510,1.000,14.99,0.00,14.99,179,90,0),(511,3.000,1.33,0.00,3.99,180,91,0),(512,1.000,1.03,0.00,1.03,18,92,0),(513,2.000,1.09,0.00,2.18,106,92,0),(514,1.000,34.49,0.00,34.49,181,92,0),(515,5.000,6.20,0.00,31.00,21,92,0),(516,5.000,6.20,0.00,31.00,126,92,0),(517,1.000,12.48,0.00,12.48,182,93,0),(518,1.000,1.77,0.00,1.77,170,93,0),(519,1.000,2.19,0.00,2.19,64,93,0),(520,1.000,2.48,0.00,2.48,32,93,0),(521,0.100,25.90,0.00,2.59,35,93,0),(522,1.000,1.79,0.00,1.79,183,93,0),(523,8.000,1.57,0.00,12.56,174,93,0),(524,1.000,3.99,0.00,3.99,123,93,0),(525,2.000,2.78,0.00,5.56,44,93,0),(526,8.000,0.58,0.00,4.64,103,93,0),(527,1.000,5.39,0.00,5.39,77,93,0),(528,1.000,2.84,0.00,2.84,87,93,0),(529,0.938,14.89,0.00,13.97,47,93,0),(530,1.000,1.75,0.00,1.75,27,93,0),(531,0.112,6.99,0.00,0.78,81,93,0),(532,0.856,4.19,0.00,3.59,105,93,0),(533,0.180,5.29,0.00,0.95,184,93,0),(534,0.098,4.49,0.00,0.44,184,93,0),(535,0.532,6.24,0.00,3.32,185,93,0),(536,30.000,0.43,0.05,12.85,168,93,0),(537,2.000,4.29,0.00,8.58,28,94,0),(538,9.000,1.09,0.00,9.81,31,94,0),(539,2.000,2.19,0.00,4.38,170,94,0),(540,1.000,3.29,0.00,3.29,32,94,0),(541,1.000,2.45,0.00,2.45,12,94,0),(542,1.014,2.99,0.00,3.03,6,94,0),(543,0.272,15.99,0.00,4.35,8,94,0),(544,0.464,2.99,0.00,1.39,80,94,0),(545,1.590,9.99,0.00,15.88,5,94,0),(546,1.000,1.99,0.00,1.99,15,94,0),(547,1.000,5.99,0.00,5.99,186,94,0),(548,2.000,1.15,0.00,2.30,187,94,0),(549,1.000,4.99,0.00,4.99,183,94,0),(550,0.400,29.97,0.00,11.99,47,94,0),(551,1.000,2.39,0.00,2.39,188,94,0),(552,0.656,9.99,0.00,6.55,7,94,0),(553,0.152,4.99,0.00,0.76,76,94,0),(554,1.000,1.29,0.00,1.29,19,94,0),(555,0.560,3.19,0.00,1.79,136,94,0),(556,0.142,26.90,0.00,3.82,35,94,0),(557,0.174,24.99,0.00,4.35,35,94,0),(558,0.126,31.40,0.00,3.96,35,94,0),(559,0.200,10.00,0.00,2.00,81,94,0),(560,3.000,7.15,5.36,16.09,16,95,0),(561,1.000,3.69,0.00,3.69,13,95,0),(562,1.000,1.39,0.00,1.39,20,95,0),(563,1.000,4.79,0.00,4.79,40,95,0),(564,1.000,3.19,1.30,1.89,1,95,0),(565,1.000,19.99,10.00,9.99,130,95,0),(566,0.511,27.99,3.06,11.24,34,95,0),(567,1.000,6.99,1.75,5.24,123,95,0),(568,0.488,2.99,0.15,1.31,80,95,0),(569,0.500,8.99,1.00,3.50,104,95,0),(570,1.000,3.99,0.00,3.99,44,95,0),(571,0.288,56.99,8.20,8.21,45,95,0),(572,0.653,12.99,3.26,5.22,8,95,0),(573,0.500,9.98,1.00,3.99,7,95,0),(574,1.000,4.29,0.00,4.29,18,95,0),(575,0.930,4.49,0.47,3.71,6,95,0),(576,1.000,1.89,0.47,1.42,123,95,0),(577,1.000,6.20,0.00,6.20,21,95,0),(578,1.000,6.20,0.00,6.20,126,95,0),(579,2.000,1.09,0.00,2.18,106,96,0),(580,1.750,1.63,0.00,2.85,39,96,0),(581,1.000,1.03,0.00,1.03,18,96,0),(582,5.000,6.20,0.00,31.00,21,96,0),(587,1.000,200.00,0.00,200.00,192,99,0),(588,1.000,45.00,0.00,45.00,193,99,0),(589,1.000,96.00,0.00,96.00,194,100,0),(590,1.000,10.00,0.00,10.00,193,100,0),(591,4.000,1.19,0.00,4.76,3,101,0),(592,1.000,3.70,0.00,3.70,32,101,0),(593,10.000,6.11,0.00,61.10,21,101,0),(594,10.000,6.11,0.00,61.10,126,101,0),(595,2.000,1.59,0.00,3.18,3,102,0),(596,1.000,2.90,0.00,2.90,12,102,0),(597,1.000,2.80,0.00,2.80,28,102,0),(598,1.500,0.92,0.00,1.38,39,102,0),(599,1.000,4.80,0.00,4.80,18,102,0),(600,1.000,1.60,0.00,1.60,18,102,0),(601,4.000,0.50,0.00,2.00,195,102,0),(602,0.425,3.50,0.00,1.49,26,102,0),(603,0.410,3.99,0.00,1.64,136,102,0),(604,1.000,24.00,0.00,24.00,117,103,0),(605,2.000,92.19,0.00,184.38,196,104,0),(606,1.500,8.00,0.00,12.00,197,105,0),(607,1.000,14.00,0.00,14.00,47,105,0),(608,1.000,8.00,0.00,8.00,198,105,0),(609,1.000,8.00,0.00,8.00,51,105,0),(610,3.024,1.99,0.00,6.02,199,106,0),(611,0.332,2.79,0.00,0.93,80,106,0),(612,0.642,3.49,0.00,2.24,81,106,0),(613,1.000,2.49,0.00,2.49,12,106,0),(614,0.240,13.00,0.00,3.12,28,106,0),(615,1.000,9.45,0.00,9.45,68,107,0),(616,0.200,5.00,0.00,1.00,201,108,0),(617,5.000,0.50,0.00,2.50,103,109,0),(618,0.700,1.50,0.00,1.05,6,109,0),(619,0.740,2.70,0.00,2.00,80,109,0),(620,0.750,2.12,0.00,1.59,1,110,0),(621,6.000,1.49,0.00,8.94,204,110,0),(622,1.000,2.09,0.00,2.09,12,110,0),(623,0.400,6.72,0.00,2.69,17,110,0),(624,3.000,6.20,0.00,18.60,21,110,0),(625,2.000,2.00,0.00,4.00,199,111,0),(626,0.500,6.50,0.00,3.25,177,111,0),(627,1.000,70.00,0.00,70.00,205,112,0),(628,10.000,0.60,1.71,4.29,103,113,0),(629,0.165,25.99,1.07,3.22,35,113,0),(630,1.000,3.69,0.00,3.69,49,113,0),(631,1.000,3.99,0.00,3.99,44,113,0),(632,1.000,30.49,4.00,26.49,133,113,0),(633,5.000,1.39,1.50,5.45,15,113,0),(634,2.000,1.39,0.00,2.78,20,113,0),(635,0.400,5.00,0.01,1.99,17,113,0),(636,1.000,1.45,0.00,1.45,85,113,0),(637,5.966,1.69,5.37,4.71,199,113,0),(638,10.000,0.49,0.00,4.90,39,113,0),(639,3.000,7.15,5.46,15.99,16,113,0),(640,1.000,3.19,1.24,1.95,32,113,0),(641,1.000,4.95,2.02,2.93,207,113,0),(642,2.000,2.09,0.00,4.18,174,113,0),(643,10.000,1.75,5.60,11.90,106,113,0),(644,0.416,3.99,0.62,1.04,80,113,0),(645,3.000,2.50,0.01,7.49,208,113,0),(646,2.000,2.50,0.01,4.99,209,113,0),(647,1.000,2.39,0.48,1.91,99,113,0),(648,0.332,29.99,2.99,6.97,35,113,0),(649,1.000,5.49,0.00,5.49,210,113,0),(650,0.948,1.99,0.80,1.09,100,113,0),(651,1.000,4.29,0.00,4.29,18,113,0),(652,1.000,4.99,2.10,2.89,77,113,0),(653,1.000,4.29,1.10,3.19,64,113,0),(654,1.000,15.69,4.70,10.99,211,113,0),(655,2.000,0.89,0.40,1.38,212,113,0),(656,0.942,5.99,1.13,4.51,177,113,0),(657,1.000,700.00,0.00,700.00,152,114,1),(658,1.000,950.00,0.00,950.00,151,115,0),(659,10.000,6.20,0.00,62.00,21,116,0),(660,10.000,6.20,0.00,62.00,126,116,0),(661,9.000,6.20,0.00,55.80,21,117,0),(662,2.000,1.99,0.00,3.98,123,117,0),(663,6.000,1.49,0.00,8.94,204,118,0),(664,1.000,19.99,0.00,19.99,2,118,0),(665,1.000,1.69,0.00,1.69,12,118,0),(666,1.000,2.50,0.00,2.50,6,119,0),(667,0.250,3.00,0.00,0.75,80,119,0),(668,0.500,3.00,0.00,1.50,81,119,0),(669,0.900,5.00,0.00,4.50,177,119,0),(670,2.000,9.00,0.00,18.00,57,120,0),(671,1.500,0.88,0.00,1.32,39,121,0),(672,2.000,1.79,0.00,3.58,3,121,0),(673,1.000,2.49,0.00,2.49,18,121,0),(674,1.000,3.15,0.00,3.15,44,122,0),(675,1.000,1.89,0.00,1.89,12,122,0),(676,6.000,0.49,0.00,2.94,15,122,0),(677,1.000,1.35,0.00,1.35,20,122,0),(678,0.736,13.49,0.00,9.93,5,122,0),(679,0.400,17.48,0.00,6.99,47,122,0),(680,0.316,0.99,0.00,0.31,11,122,0),(681,0.412,2.49,0.00,1.03,81,122,0),(682,0.690,1.99,0.00,1.37,136,122,0),(683,1.000,3.29,0.00,3.29,24,122,0),(684,10.000,0.60,0.01,5.99,103,122,0),(685,2.000,2.45,0.01,4.89,32,122,0),(686,12.000,1.04,0.00,12.48,48,122,0),(687,0.500,34.00,0.00,17.00,63,122,0),(688,1.000,11.49,0.00,11.49,45,122,0),(689,1.000,84.88,0.00,84.88,215,123,1),(690,1.000,3.99,0.00,3.99,24,124,0),(691,3.000,6.66,0.00,19.98,16,124,0),(692,1.000,2.49,0.00,2.49,18,124,0),(693,1.000,1.49,0.00,1.49,12,124,0),(694,1.000,2.50,0.00,2.50,6,125,0),(695,1.120,2.80,0.00,3.14,167,125,0),(696,0.950,3.00,0.00,2.85,81,125,0),(697,1.000,107.31,0.00,107.31,216,126,0),(698,1.000,64.98,0.00,64.98,216,127,1),(699,1.000,86.98,0.00,86.98,216,128,0),(700,1.000,64.98,0.00,64.98,216,129,1),(701,1.000,88.97,0.00,88.97,216,130,0),(702,1.000,66.37,0.00,66.37,216,131,1),(703,1.000,89.70,0.00,89.70,216,132,0),(704,1.000,65.98,0.00,65.98,216,133,1),(705,1.000,90.96,0.00,90.96,216,134,0),(706,1.000,19.03,0.00,19.03,146,135,1),(707,1.000,18.44,0.00,18.44,146,136,1),(708,1.000,22.00,0.00,22.00,146,137,1),(709,1.000,22.99,0.00,22.99,146,138,1),(710,1.000,11.08,0.00,11.08,147,139,1),(711,1.000,7.87,0.00,7.87,147,140,1),(712,1.000,3.71,0.00,3.71,147,141,1),(713,1.000,7.39,0.00,7.39,147,142,1),(714,1.000,25.00,0.00,25.00,149,143,1),(715,1.000,128.19,0.00,128.19,150,143,1),(716,1.000,25.00,0.00,25.00,149,144,1),(717,1.000,117.77,0.00,117.77,150,144,1),(718,1.000,25.00,0.00,25.00,149,145,1),(719,1.000,78.95,0.00,78.95,150,145,1),(720,1.000,22.22,0.00,22.22,149,146,1),(721,1.000,950.00,0.00,950.00,151,147,0),(722,1.000,950.00,0.00,950.00,151,148,0),(723,1.000,950.00,0.00,950.00,151,149,0),(724,1.000,950.00,0.00,950.00,151,150,0),(725,0.500,3.20,0.00,1.60,80,151,0),(726,0.650,6.50,0.00,4.23,177,151,0),(727,1.000,5.99,0.00,5.99,172,152,0),(728,1.000,1.79,0.00,1.79,13,152,0),(729,3.000,6.20,0.00,18.60,21,152,0),(730,0.400,10.97,0.00,4.39,28,152,0),(731,1.000,1.39,0.00,1.39,20,152,0),(732,1.000,1.75,0.00,1.75,27,152,0),(733,0.400,6.73,0.00,2.69,17,152,0),(734,1.000,2.49,0.00,2.49,18,152,0),(735,6.000,1.49,0.00,8.94,204,152,0),(736,1.000,1.39,0.00,1.39,18,152,0),(737,1.000,2.39,0.00,2.39,18,152,0),(738,2.000,1.29,0.00,2.58,15,152,0),(739,1.000,28.99,0.00,28.99,63,152,0),(740,0.060,9.90,0.00,0.59,8,152,0),(741,1.000,66.08,0.00,66.08,216,153,0),(742,1.000,11.98,0.00,11.98,216,154,1),(743,1.000,24.90,0.00,24.90,149,155,1),(744,49.341,2.46,0.00,121.38,67,156,0),(745,1.000,36.95,0.00,36.95,147,157,1),(746,1.000,237.42,0.00,237.42,150,158,1),(747,1.000,38.78,0.00,38.78,216,159,0),(748,1.000,386.24,0.00,386.24,146,160,1),(749,1.000,22.00,0.00,22.00,146,161,0),(750,1.000,11.09,0.00,11.09,147,162,0),(751,1.000,32.73,0.00,32.73,150,163,0),(752,1.000,25.42,0.00,25.42,146,164,1),(753,1.000,36.95,0.00,36.95,147,165,1),(754,1.000,37.50,0.00,37.50,147,166,0),(755,1.000,63.54,0.00,63.54,216,167,0),(756,1.000,26.25,0.00,26.25,150,168,0),(757,1.000,124.02,0.00,124.02,146,169,1),(758,1.000,186.54,0.00,186.54,150,170,1),(759,1.000,20.27,0.00,20.27,146,171,0),(760,1.000,25.60,0.00,25.60,146,172,1),(761,1.000,36.96,0.00,36.96,147,173,1),(762,1.000,66.76,0.00,66.76,216,174,0),(763,1.000,29.56,0.00,29.56,147,175,0),(764,1.000,144.92,0.00,144.92,150,177,1),(765,1.000,79.63,0.00,79.63,146,178,1),(766,1.000,23.03,0.00,23.03,150,179,0),(767,1.000,24.37,0.00,24.37,146,180,0),(768,1.000,23.62,0.00,23.62,146,181,1),(769,1.000,29.56,0.00,29.56,147,182,0),(770,1.000,59.12,0.00,59.12,147,183,1),(771,1.000,79.96,0.00,79.96,216,184,0),(772,1.000,62.65,0.00,62.65,146,185,1),(773,1.000,2.63,0.00,2.63,150,186,0),(774,1.000,40.45,0.00,40.45,150,187,1),(775,1.000,49.56,0.00,49.56,147,188,1),(776,1.000,21.19,0.00,21.19,146,189,0),(777,1.000,30.12,0.00,30.12,146,190,1),(778,1.000,47.09,0.00,47.09,147,191,0),(779,1.000,79.96,0.00,79.96,216,192,0),(780,1.000,3751.38,0.00,3751.38,220,193,0),(781,1.000,197.30,0.00,197.30,220,193,0),(782,1.000,5000.00,0.00,5000.00,221,194,1),(783,2.300,4.40,0.00,10.12,6,195,1),(784,6.000,1.50,0.00,9.00,106,195,1),(785,2.000,2.00,0.00,4.00,222,195,1),(786,1.000,3.20,0.00,3.20,223,195,1),(787,1.000,0.95,0.00,0.95,27,195,1),(788,1.000,4.95,0.00,4.95,45,195,1),(789,1.000,1.50,0.00,1.50,12,195,1),(790,1.000,2.49,0.00,2.49,18,196,0),(791,1.000,2.89,0.00,2.89,170,196,0),(792,5.000,6.50,0.00,32.50,21,196,0),(793,0.940,12.55,0.00,11.80,47,197,0),(794,0.908,12.55,0.00,11.40,47,197,1),(795,0.456,13.70,0.00,6.25,49,197,1),(796,1.000,23.15,0.00,23.15,117,198,0),(797,10.000,6.40,0.00,64.00,126,199,0),(798,10.000,6.40,0.00,64.00,21,199,0),(799,1.000,3.70,0.00,3.70,32,199,0),(800,1.000,41.03,0.00,41.03,149,200,1),(801,1.000,53.06,0.00,53.06,146,201,1),(802,1.000,10.83,0.00,10.83,149,202,0),(803,5.000,1.40,0.00,7.00,106,203,1),(804,2.000,1.90,0.00,3.80,222,203,1),(805,0.500,2.70,0.00,1.35,77,203,1),(806,1.000,4.70,0.00,4.70,224,203,0),(807,2.000,4.60,0.00,9.20,224,203,1),(808,0.300,2.80,0.00,0.84,80,203,1),(809,0.200,3.00,0.00,0.60,76,203,1),(810,1.000,1.60,0.00,1.60,12,203,1),(811,0.200,8.45,0.00,1.69,93,204,0),(812,1.000,2.45,0.00,2.45,12,204,0),(813,3.000,1.25,0.00,3.75,15,204,0),(814,1.000,4.49,0.00,4.49,49,204,0),(815,1.000,3.29,0.00,3.29,18,204,0),(816,0.670,3.99,0.00,2.67,80,204,0),(817,2.626,1.19,0.00,3.12,199,204,0),(818,0.494,1.89,0.00,0.93,136,204,0),(819,6.000,1.09,0.00,6.54,31,204,0),(820,4.200,3.69,0.00,15.50,147,205,1),(821,1.000,65.98,0.00,65.98,216,206,1),(822,1.000,14.20,0.00,14.20,117,207,0),(823,2.000,1.29,0.00,2.58,20,208,0),(824,0.750,2.92,0.00,2.19,32,208,0),(825,0.594,2.59,0.00,1.54,81,208,0),(826,10.000,0.44,0.00,4.40,103,208,0),(827,6.000,1.33,0.00,7.98,48,208,0),(828,2.000,6.50,0.00,13.00,21,208,0),(829,1.000,1200.00,0.00,1200.00,225,209,0),(830,1.000,1800.00,0.00,1800.00,225,210,0),(831,1.000,2200.00,0.00,2200.00,225,211,0),(832,1.000,1800.00,0.00,1800.00,225,212,0),(833,1.000,2200.00,0.00,2200.00,225,213,0),(834,1.000,1650.00,0.00,1650.00,225,214,0);
/*!40000 ALTER TABLE `shopping_shoppingproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taskmanager_event`
--

DROP TABLE IF EXISTS `taskmanager_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taskmanager_event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `start_datetime` datetime(6) NOT NULL,
  `end_datetime` datetime(6) NOT NULL,
  `location` varchar(100) DEFAULT NULL,
  `all_day` tinyint(1) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taskmanager_event_user_id_e97ad431_fk_users_customuser_id` (`user_id`),
  CONSTRAINT `taskmanager_event_user_id_e97ad431_fk_users_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taskmanager_event`
--

LOCK TABLES `taskmanager_event` WRITE;
/*!40000 ALTER TABLE `taskmanager_event` DISABLE KEYS */;
INSERT INTO `taskmanager_event` VALUES (1,'Даная и Бояна','','2025-07-24 15:01:00.000000','2025-07-24 17:53:00.000000','София',0,2),(2,'Производство','Дневна среща','2025-07-18 07:00:00.000000','2025-07-18 07:45:00.000000','Етем',0,1),(3,'Проект','Проект','2025-07-18 16:00:00.000000','2025-07-18 19:00:00.000000','Home',0,1),(4,'new_post 1','ww','2025-07-18 19:00:00.000000','2025-07-18 20:00:00.000000','ss',0,1),(5,'Training','','2025-07-21 11:00:00.000000','2025-07-21 12:00:00.000000',NULL,0,1);
/*!40000 ALTER TABLE `taskmanager_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taskmanager_task`
--

DROP TABLE IF EXISTS `taskmanager_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taskmanager_task` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `due_date` date NOT NULL,
  `priority` varchar(10) NOT NULL,
  `completed` tinyint(1) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taskmanager_task_user_id_8e9042e7_fk_users_customuser_id` (`user_id`),
  CONSTRAINT `taskmanager_task_user_id_8e9042e7_fk_users_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taskmanager_task`
--

LOCK TABLES `taskmanager_task` WRITE;
/*!40000 ALTER TABLE `taskmanager_task` DISABLE KEYS */;
INSERT INTO `taskmanager_task` VALUES (1,'Предаване на проект - първа стъпка','','2025-07-25','Висок',0,2),(2,'Автомивка','','2025-07-17','Висок',1,2),(3,'Проект Софтуни 1-ви събмишън','','2025-07-28','Висок',0,1),(4,'Сашо Милушев','Обаждане в 19:00','2025-07-22','Висок',1,1),(5,'Пазаруване 2025-07-22','Списък за пазаруване, генериран от Краси и Стоян -> <a href=\"/inventory/inventory/shopping_list/1/\">Отиди на списъка</a>','2025-07-22','Нормален',1,1),(6,'Пазаруване 2025-07-22','Списък за пазаруване, генериран от Краси и Стоян -> <a href=\"/inventory/inventory/shopping_list/1/\">Отиди на списъка</a>','2025-07-22','Нормален',0,2),(7,'Търсене в Гугъл за рецепти винаги','','2025-07-23','Нормален',1,1),(8,'Цена на вода в лв.','','2025-07-23','Нормален',1,1),(9,'Създаване на администратор на форума.','','2025-07-23','Нормален',0,1),(10,'Admin panels of all models!','','2025-07-23','Нормален',0,1),(11,'Смяна на маслото Сеат','','2025-07-30','Нормален',0,1),(12,'Пазаруване 2025-07-25','Списък за пазаруване, генериран от Краси и Стоян -> <a href=\"/inventory/inventory/shopping_list/2/\">Отиди на списъка</a>','2025-07-25','Нормален',1,1),(13,'Пазаруване 2025-07-25','Списък за пазаруване, генериран от Краси и Стоян -> <a href=\"/inventory/inventory/shopping_list/2/\">Отиди на списъка</a>','2025-07-25','Нормален',0,2),(14,'Пазаруване 2025-07-26','Списък за пазаруване, генериран от Краси и Стоян -> <a href=\"/inventory/inventory/shopping_list/3/\">Отиди на списъка</a>','2025-07-26','Нормален',1,1),(15,'Пазаруване 2025-07-26','Списък за пазаруване, генериран от Краси и Стоян -> <a href=\"/inventory/inventory/shopping_list/3/\">Отиди на списъка</a>','2025-07-26','Нормален',0,2),(16,'Искане за създаване на тема от test2','Искане за създаване на тема Тест тема 3 във форума в категория Общи','2025-07-28','Нормален',0,1),(17,'Искане за създаване на тема от test2','Искане за създаване на тема Тест тема 3 във форума в категория Общи','2025-07-28','Нормален',0,2),(18,'Искане за създаване на тема от test2','Искане за създаване на тема Тест тема 4 във форума в категория Общи -> <a href=\'/forum/edit-request-thread/2/\'>Отиди на списъка</a>\'','2025-07-28','Нормален',0,1),(19,'Искане за създаване на тема от test2','Искане за създаване на тема Тест тема 4 във форума в категория Общи -> <a href=\'/forum/edit-request-thread/2/\'>Отиди на списъка</a>\'','2025-07-28','Нормален',0,2),(20,'Промяна в статус на искане за отваряне на Тест тема 4 във форума','Заявката за отваряна на тема е pending','2025-07-28','Нормален',0,4),(21,'Промяна в статус на искане за отваряне на Тест тема 4 във форума','Заявката за отваряна на тема е approved','2025-07-28','Нормален',0,4),(22,'Промяна в статус на искане за отваряне на Тест тема 4 във форума','Заявката за отваряна на тема е functools.partial(<bound method Model._get_FIELD_display of <ThreadRequest: Тест тема 4 (requested by test2@somemail.com)>>, field=<django.db.models.fields.CharField: status>)','2025-07-28','Нормален',0,4),(23,'Промяна в статус на искане за отваряне на Тест тема 4 във форума','Заявката за отваряна на тема е Отхвърлена','2025-07-28','Нормален',0,4),(24,'Искане за създаване на тема от test2','Искане за създаване на тема Фондови борси във форума в категория Пари -> <a href=\'/forum/edit-request-thread/3/\'>Отиди на искането</a>\'','2025-07-28','Нормален',0,1),(25,'Искане за създаване на тема от test2','Искане за създаване на тема Фондови борси във форума в категория Пари -> <a href=\'/forum/edit-request-thread/3/\'>Отиди на искането</a>\'','2025-07-28','Нормален',0,2),(26,'Промяна в статус на искане за отваряне на Фондови борси във форума','','2025-07-28','Нормален',1,4);
/*!40000 ALTER TABLE `taskmanager_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_customuser`
--

DROP TABLE IF EXISTS `users_customuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_customuser` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `household_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_customuser_email_6445acef_uniq` (`email`),
  KEY `users_customuser_household_id_810cf507_fk_users_household_id` (`household_id`),
  CONSTRAINT `users_customuser_household_id_810cf507_fk_users_household_id` FOREIGN KEY (`household_id`) REFERENCES `users_household` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_customuser`
--

LOCK TABLES `users_customuser` WRITE;
/*!40000 ALTER TABLE `users_customuser` DISABLE KEYS */;
INSERT INTO `users_customuser` VALUES (1,'pbkdf2_sha256$1000000$85qu7jyr3czm1CkNTQKxIZ$ePO8/AmXli2QUEmsmqMDFg3IpWbzK1BliRYFATdH1Xs=','2025-07-28 14:51:08.715961',1,'Superuser','Superuser','super@user.com',1,1,'2025-05-28 07:54:55.484925',NULL,1),(2,'pbkdf2_sha256$1000000$JxrlvSM83jCz0BbSE0Arqp$gX/odr5seCRIAhGSBIS8KqTKs1Uu5xH9m4MuSAqZBtg=','2025-07-28 15:05:38.316799',0,'StaffUser','StaffUser','staff@user.com',1,1,'2025-05-28 10:47:11.692434',NULL,1),(4,'pbkdf2_sha256$1000000$uRDmgM9g23OgDr18V7oERT$Ai2XHsFTVa595JIniMN4OezCAedKDxMzT1BiVhQR3+w=','2025-07-28 15:02:42.857144',0,'test2','test2','test2@somemail.com',0,1,'2025-07-28 11:29:32.866035',NULL,NULL);
/*!40000 ALTER TABLE `users_customuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_customuser_groups`
--

DROP TABLE IF EXISTS `users_customuser_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_customuser_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `customuser_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_customuser_groups_customuser_id_group_id_76b619e3_uniq` (`customuser_id`,`group_id`),
  KEY `users_customuser_groups_group_id_01390b14_fk_auth_group_id` (`group_id`),
  CONSTRAINT `users_customuser_gro_customuser_id_958147bf_fk_users_cus` FOREIGN KEY (`customuser_id`) REFERENCES `users_customuser` (`id`),
  CONSTRAINT `users_customuser_groups_group_id_01390b14_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_customuser_groups`
--

LOCK TABLES `users_customuser_groups` WRITE;
/*!40000 ALTER TABLE `users_customuser_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_customuser_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_customuser_user_permissions`
--

DROP TABLE IF EXISTS `users_customuser_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_customuser_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `customuser_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_customuser_user_pe_customuser_id_permission_7a7debf6_uniq` (`customuser_id`,`permission_id`),
  KEY `users_customuser_use_permission_id_baaa2f74_fk_auth_perm` (`permission_id`),
  CONSTRAINT `users_customuser_use_customuser_id_5771478b_fk_users_cus` FOREIGN KEY (`customuser_id`) REFERENCES `users_customuser` (`id`),
  CONSTRAINT `users_customuser_use_permission_id_baaa2f74_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_customuser_user_permissions`
--

LOCK TABLES `users_customuser_user_permissions` WRITE;
/*!40000 ALTER TABLE `users_customuser_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_customuser_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_household`
--

DROP TABLE IF EXISTS `users_household`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_household` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `owner_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nickname` (`nickname`),
  KEY `users_household_owner_id_46cd83ee_fk_users_customuser_id` (`owner_id`),
  CONSTRAINT `users_household_owner_id_46cd83ee_fk_users_customuser_id` FOREIGN KEY (`owner_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_household`
--

LOCK TABLES `users_household` WRITE;
/*!40000 ALTER TABLE `users_household` DISABLE KEYS */;
INSERT INTO `users_household` VALUES (1,'Краси и Стоян','krasi_stoyan','София',1);
/*!40000 ALTER TABLE `users_household` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_householdmembership`
--

DROP TABLE IF EXISTS `users_householdmembership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_householdmembership` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `status` varchar(10) NOT NULL,
  `requested_at` datetime(6) NOT NULL,
  `household_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_householdmembership_user_id_household_id_1b5951cf_uniq` (`user_id`,`household_id`),
  KEY `users_householdmembe_household_id_28379e69_fk_users_hou` (`household_id`),
  CONSTRAINT `users_householdmembe_household_id_28379e69_fk_users_hou` FOREIGN KEY (`household_id`) REFERENCES `users_household` (`id`),
  CONSTRAINT `users_householdmembe_user_id_aea4eaf8_fk_users_cus` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_householdmembership`
--

LOCK TABLES `users_householdmembership` WRITE;
/*!40000 ALTER TABLE `users_householdmembership` DISABLE KEYS */;
INSERT INTO `users_householdmembership` VALUES (1,'approved','2025-07-17 20:24:13.060723',1,2);
/*!40000 ALTER TABLE `users_householdmembership` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-28 18:42:36
